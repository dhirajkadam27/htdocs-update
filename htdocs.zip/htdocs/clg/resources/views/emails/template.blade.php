<!DOCTYPE html>
<html>
<head>
    <title>Bulk Email Sender</title>
</head>
<body>
    <p>{!! $mailData['body'] !!}</p>
</body>
</html>