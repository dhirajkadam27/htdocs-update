<div class="az-footer ht-40">
    <div class="container ht-100p pd-t-0-f">
      <span class="text-muted h6 d-block text-center text-sm-left d-sm-inline-block">Copyright © <a href="https://facebook.com/arafathossain000"
          target="_blank">Arafat Hossain Ar</a> {{ date('Y') }}</span>
      <span class="float-none h6 float-sm-right d-block mt-1 mt-sm-0 text-center">
        Find me
        <a class="h5 text-primary" href="https://facebook.com/arafathossain000" target="_blank"><i class="typcn typcn-social-facebook-circular"></i></a>
        <a class="h5 text-primary" href="https://instagram.com/arafathossain000" target="_blank"><i class="typcn typcn-social-instagram-circular"></i></a>
        <a class="h5 text-primary" href="https://github.com/arafat-web" target="_blank"><i class="typcn typcn-social-github-circular"></i></a>
        </span>
    </div><!-- container -->
  </div><!-- az-footer -->
