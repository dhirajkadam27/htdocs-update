<?php

// Include database connection
include 'config.php';

function generateAlphanumericToken($length) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; // Define the character set
    $token = ''; // Initialize the token variable
    
    // Loop to generate random characters
    for ($i = 0; $i < $length; $i++) {
        $token .= $characters[rand(0, strlen($characters) - 1)]; // Append a random character from the character set
    }
    
    return $token;
}

function generateCode() {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'; // Define the character set
    $code = ''; // Initialize the code variable
    
    // Loop to generate 6 random characters
    for ($i = 0; $i < 6; $i++) {
        $code .= $characters[rand(0, strlen($characters) - 1)]; // Append a random character from the character set
    }
    
    return $code;
}

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the email address from the request

    $postData = file_get_contents("php://input");

    // Decode the JSON data
    $requestData = json_decode($postData, true);

    if(isset($requestData['email']) && isset($requestData['provider'])){

        $email = $requestData['email'];
        $provider = $requestData['provider'];
        $token = generateAlphanumericToken(10);
        $code = generateCode();

        
         // Check if the email exists in the user_emails table
    $query = "SELECT * FROM useremail WHERE emailaddress = '$email'";
    $result = mysqli_query($connection, $query);

    if(mysqli_num_rows($result) > 0) {
        // Email already exists

        
        while ($row = mysqli_fetch_assoc($result)) {
            $userid = $row['userid'];
        }
        


        
        // Insert the email address with the user ID
        $query = "INSERT INTO emailverificationtoken (token, email, code,userid) VALUES ('$token', '$email', '$code','$userid')";
        mysqli_query($connection, $query);

           // Check if the name is filled or not in the user table
    $user_query = "SELECT * FROM user WHERE name = '' AND userid=$userid";
    $user_result = mysqli_query($connection, $user_query);


    if(mysqli_num_rows($user_result) > 0) {

         // Prepare response
         $response = array('status' => 'success', 'message' => 'created', 'token' => $token);
         echo json_encode($response);

    }else{  
        $response = array('status' => 'success', 'message' => 'already', 'token' => $token);
        echo json_encode($response);
    }

      
    } else {
        // Email does not exist, create a new user
        $query = "INSERT INTO user (name) VALUES ('')";
        mysqli_query($connection, $query);

        // Get the user ID of the newly created user
        $user_id = mysqli_insert_id($connection);

        // Insert the email address with the user ID
        $query = "INSERT INTO useremail (userid, emailaddress, serviceprovider) VALUES ('$user_id', '$email', '$provider')";
        mysqli_query($connection, $query);

        
        // Insert the email address with the user ID
        $query = "INSERT INTO emailverificationtoken (token, email, code,userid) VALUES ('$token', '$email', '$code','$user_id')";
        mysqli_query($connection, $query);

        // Prepare response
        $response = array('status' => 'success', 'message' => 'created', 'token' => $token);
        echo json_encode($response);
    }
    }else{
        echo json_encode(array('status' => 'error', 'message' => 'Please provide an email address.'));
    }
} else {
    // Method not allowed
    http_response_code(405); // Method Not Allowed
    echo json_encode(array('status' => 'error', 'message' => 'Oops! Something went wrong.'));
}

// Close database connection
mysqli_close($connection);

?>
