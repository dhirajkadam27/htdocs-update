<?php

// Database connection parameters
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'togglev2';

// Connect to MySQL database
$connection = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

?>
