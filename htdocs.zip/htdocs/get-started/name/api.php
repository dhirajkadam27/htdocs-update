<?php
session_start();
$userid = $_SESSION['userid'];

// Include database connection
include '../config.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if a file is uploaded
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === 0) {
        // Check if the file is an image
        $file_type = exif_imagetype($_FILES['photo']['tmp_name']);
        if ($file_type === false) {
            $response = array('status' => 'error', 'message' => 'Please upload a valid image file.');
           echo json_encode($response);

            exit;
        }

        // Prepare the photo for insertion into the database
        $photo_data = file_get_contents($_FILES['photo']['tmp_name']);
        $photo_data = mysqli_real_escape_string($connection, $photo_data);
    } else {
        // No photo uploaded, set default value
        $photo_data = null;
    }

    // Sanitize the name
    $name = mysqli_real_escape_string($connection, $_POST['name']);

    // Insert the data into the database
    $query =  "UPDATE `user` SET `name`='$name',`photo`='$photo_data' WHERE userid = '$userid'";
    $result = mysqli_query($connection, $query);

    if ($result) {
        $response = array('status' => 'success', 'message' => 'added');
       echo json_encode($response);
    } else {
        $response = array('status' => 'error', 'message' => 'Failed to upload data. Please try again later.');
       echo json_encode($response);
    }

    // Close the database connection
    mysqli_close($connection);
} else {
    echo json_encode(array('status' => 'error', 'message' => 'Oops! Something went wrong.'));
}
?>
