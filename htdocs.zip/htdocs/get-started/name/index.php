<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle.work</title>

    <!-- outfit font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&display=swap" rel="stylesheet">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <title>Bootstrap Example</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


    <style>
        :root {
            --orange-color: #FF6B00;
            --black-color: #1c1c1c;
            --white-button-hover: #e0e0e0;
            --orange-button-hover: #ff7b1c;
            --grey-color: rgb(135, 135, 135);
            --light-grey-color: rgb(165, 165, 165);
            --font-weight: 600;
            --font-size: 18px;
        }

        button {
            font-family: "Outfit", sans-serif;
            font-weight: var(--font-weight);
            font-size: var(--font-size);
            font-style: normal;
            color: var(--black-color);
            cursor: pointer;
        }

        input{
    font-size: 15px;
    font-weight: 400 !important;
    color: var(--black-color);
    font-family: "Outfit", sans-serif;
            font-size: var(--font-size);
            font-style: normal;
}
input::placeholder{
    color: #919191;
    font-weight: 400 !important;
}

        body {
            margin: 0;
            padding: 0;
            font-family: "Outfit", sans-serif;
            font-optical-sizing: auto;
            font-weight: var(--font-weight);
            font-size: var(--font-size);
            font-style: normal;
            color: var(--black-color);
        }

        .logo {
            font-size: 30px;
            font-weight: 800;
            margin-top: 80px;
            text-align: center;
        }


        .title {
    font-size: 35px;
    text-align: center;
    margin-top: 30px;
}

.subtitle {
    font-size: 18px;
    font-weight: 400;
    text-align: left;
    margin-top: 30px !important;
    width: 300px;
    display: block;
    margin: 10px auto;
}


input[type="text"] {
    display: block;
    margin: 15px auto;
    width: 280px;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #919191;
    margin-top: 10px;
}


button {
    width: 320px;
    padding: 10px 25px;
    border: none;
    background: var(--orange-color);
    border-radius: 5px;
    font-size: 15px;
    font-weight: 600;
    color: white;
    display: block;
    margin: 10px auto;
}

.width {
    width: 300px;
    display: block;
    margin: 0px auto;
}
.icon {
    width: 80px;
    height: 80px;
    background: #8554ff;
    border-radius: 5px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 30px;
    color: white;
    font-weight: 500;
}

button.edit-btn {
    width: max-content;
    font-size: 15px;
    background: none;
    color: var(--black-color);
    border: 1px solid var(--black-color);
    display: flex;
    margin: 0;
    margin-top: 15px;
    margin-bottom: 30px;
    padding: 5px 15px;
}

.modal-content {
    border: none;
}

.modal-nav {
    display: flex;
    align-items: center;
    justify-content: end;
}

.modal-nav button {
    margin: 20px;
}

.modal-title {
    font-size: 15px;
    font-weight: 400;
    text-align: center;
    width: 80%;
    margin: 10px auto;
}

.modal-img {
    display: flex;
    align-items: center;
    justify-content: center;
}

.modal-img img {
    height: 30px;
    margin: 15px 20px;
    margin-bottom: 40px;
}
    </style>
</head>

<body>
    <button id="errorpopupbtn" style="display: none;" type="button" data-bs-toggle="modal" data-bs-target="#errorpopup" >emailpopup</button>

        <div class="logo">Toggle</div>
        <div class="title">What's your name?</div>
        <form action="api.php" method="post" enctype="multipart/form-data">
        <div class="subtitle">Your name</div>
        <input type="text" id="nameInput" required placeholder="ABCDEF" name="name">
        <div class="subtitle">Your profile photo</div>
        <div class="width">
            <div id="icon" class="icon">T</div>
            <img id="preview" class="icon" src="#" alt="Preview" style="display: none;">
            <button id="filebtn" class="edit-btn">Edit Photo</button>
    <input style="display: none;" type="file" name="photo" id="photoInput" accept="image/*">
        </div>
        <button id="submitButton">Next</button>
        </form>


        <div class="modal fade" id="errorpopup" tabindex="-1" style="display: none;">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-nav">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div id="errorpopuptxt" class="modal-title">...</div>
                <div class="modal-img">
                    <img src="../error.png">
                </div>
              </div>
            </div>
          </div>
    
    

<script>
function displayPhoto(event) {
    const preview = document.getElementById('preview');
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = function() {
        preview.src = reader.result;
        preview.style.display = 'block';
    }

    reader.readAsDataURL(file);
    document.getElementById('icon').style.display = "none";
}
document.getElementById('photoInput').addEventListener('change', displayPhoto);

  
document.getElementById('filebtn').addEventListener('click', function(event) {
    event.preventDefault(); // Prevent form submission
    var filebtn = document.getElementById('photoInput');
    filebtn.click();
});

document.getElementById('submitButton').addEventListener('click', function(event) {
    event.preventDefault(); // Prevent form submission
    const name = document.getElementById('nameInput').value;
    const photo = document.getElementById('photoInput').files[0];
  
    var errorpopup = document.getElementById('errorpopupbtn');
    var errorpopuptxt = document.getElementById('errorpopuptxt');

    const formData = new FormData();

// Append form fields to the FormData object
formData.append('name', name);
formData.append('photo', photo);


fetch('./api.php', {
  method: 'POST',
  body: formData 
})
.then(response => {
  if (!response.ok) {
    throw new Error('Network response was not ok');
    errorpopuptxt.innerHTML = "Oops! Something went wrong with the network response.";
    errorpopup.click();
  }
  return response.json();
})
.then(data => {
  console.log('Response:', data);
  if(data.status=="error"){
    errorpopuptxt.innerHTML = data.message;
    errorpopup.click();
  }else{
    window.location.href = '../connectemail';
  }
})
.catch(error => {
  console.error('There was a problem with the fetch operation:', error);
    errorpopuptxt.innerHTML = "Uh oh! We encountered an issue with the fetch operation.";
    errorpopup.click();
});

});

</script>

</body>

</html>