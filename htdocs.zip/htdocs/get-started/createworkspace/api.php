<?php
session_start();
$userid = $_SESSION['userid'];
// Include database connection
include '../config.php';

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the email address from the request

    $postData = file_get_contents("php://input");

    // Decode the JSON data
    $requestData = json_decode($postData, true);

    if(isset($requestData['name'])){

        $name = $requestData['name'];
        
        // Insert the email address with the user ID
        $query = "INSERT INTO workspace ( name) VALUES ('$name')";
$result = mysqli_query($connection, $query);


        // Get the user ID of the newly created user
        $workspaceid = mysqli_insert_id($connection);


        // Insert the email address with the user ID
        $query = "INSERT INTO workspaceuser (userid, workspaceid) VALUES ('$userid', '$workspaceid')";
$result = mysqli_query($connection, $query);

if ($result) {
    
    $response = array('status' => 'success', 'message' => 'already');
    echo json_encode($response);
} else {
   
    $response = array('status' => 'error', 'message' => 'Failed to create workspace. Please try again later.');
    echo json_encode($response);
}

   
    }else{
        echo json_encode(array('status' => 'error', 'message' => 'Please provide an email address.'));
    }
} else {
    // Method not allowed
    http_response_code(405); // Method Not Allowed
    echo json_encode(array('status' => 'error', 'message' => 'Oops! Something went wrong.'));
}

// Close database connection
mysqli_close($connection);

?>
