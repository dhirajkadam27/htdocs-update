<?php
$file_name = $_GET['file_name'];

// Replace these with your MySQL database credentials
$host = "localhost";
$username = "root";
$password = "";
$database = "elearn";

// Establish a database connection
$connection = mysqli_connect($host, $username, $password, $database);

if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Retrieve the file data from the database
$query = "SELECT file FROM file WHERE filename = '$file_name'";
$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) == 1) {
    $row = mysqli_fetch_assoc($result);
    $file_data = $row['file'];

    // Display the file data (you may need to set the appropriate content type)
    header("Content-Type: application/pdf"); // Modify the content type for different file types (e.g., "application/pdf" for PDF files)
    echo $file_data;
} else {
    echo "File not found.";
}

// Close the database connection
mysqli_close($connection);
?>
