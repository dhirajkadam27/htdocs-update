<?php
session_start();
$login = false;
if (isset($_SESSION["email"])) {
    $email = $_SESSION['email'];
    $login = true;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home | E-Learning DYPCET</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>

body {
    margin: 0;
    padding: 0;
    background: rgb(238, 238, 238);
    font-family: 'Poppins', sans-serif;
}
.main_logo {
    width: 100%;
    background: #103d74;
    text-align: center;
    padding: 50px 0px;
}

.main_logo img {
    width: 50%;
}


.nav {
    width: 100%;
    height: 40px;
    background: #103d74;
    text-align: center;
    border-top: 1px solid #093264;
    display: flex;
    justify-content: center;
}

.nav a {
    color: white;
    height: 40px;
    padding: 0px 20px;
    text-decoration: none;
    display: flex;
    align-items: center;
}
.nav a:hover {
    background: #0c3362;
}

.slider {
    width: 100%;
    display: flex;
    justify-content: center;
    position: relative;
    margin-top: 40px;
}

.slider_txt_bold {
    position: absolute;
    z-index: 10;
    top: 170px;
    font-size: 50px;
    font-weight: bold;
    color: #103d74;
}

.slider_txt_light {
    position: absolute;
    z-index: 10;
    top: 235px;
    font-size: 25px;
    color: #103d74;
}

.slider img {filter: opacity(0.8);}
.img_flex {
    width: 90%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 50px auto;
    padding: 0px 5%;
    background: #103d74;
}

.img_flex img {
    width: 48%;
    margin: 50px 0px;
}

.schedule {
    width: 90%;
    padding: 0px 5%;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.schedule_1 {
    width: 50%;
}

.schedule_big_txt {
    font-size: 50px;
    font-weight: bold;
}

.schedule_small_txt {
    font-size: 15px;
}

.schedule button {background: #103d74;color: white;padding: 4px 15px;}

.schedule_boxes {
    width: 90%;
    padding: 0px 5%;
    display: flex;
    margin-top:10px
}

.schedule_box {
    width: 20%;
    margin-top: 20px;
    text-align: center;
    padding:10px 0px;
    color: #103d74;
    background:white
}
.schedule_box:nth-child(odd) {
background:#103d74;
    color: white;
}

.schedule_round {
    width: 50px;
    height: 50px;
    margin: 10px auto;
    background: #103d74;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    border-radius: 100px;
}
.schedule_box:nth-child(odd) .schedule_round {
background:white;
    color: #103d74;
}

.schedule_title {
    font-size: 20px;
    font-weight: 600;
}

.schedule_data {
    font-size: 15px;
    margin-top: 5px;
}

.footer {width: 90%;margin: 50px 0px;padding: 0px 5%;background: #103d74;padding-bottom: 30px;}

.footer_title {
    font-size: 30px;
    padding-top: 20px;
    color: white;
    font-weight: bold;
    margin-bottom: 5px;
}

.footer_subtitle {
    font-size: 15px;
    color: white;
    margin-bottom: 5px;
}

.additional_boxes {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 25px 0px;
}

.additional_box {
    width: 23%;
    height: 100px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: white;
    font-size: 15px;
}

.part {
    display: flex;
}

.part_1 img {
    width: 100%;
}

.part_1 {
    width: 50%;
}

.part_2_txt1 {
    font-size: 25px;
    font-weight: 600;
    color: white;
}

.part_2 {
    width: 48%;
    margin-left: 2%;
    margin-top: 30px;
}

.part_2_txt2 {
    font-size: 15px;
    color: white;
    margin-top: 10px;
}

.part_2_txt3 {
    font-size: 25px;
    font-weight: 600;
    color: white;
    margin-top: 15px;
}

.part_2_txt4 {
    font-size: 15px;
    color: white;
    margin-top: 10px;
    margin-bottom: 20px;
}

.divide {
    width: 100%;
    display: flex;
    margin-bottom: 14px;
}

input {
    width: 95%;
    padding: 5px 10px;
    margin-right: 10px;
}

.divide input {
    width: 45%;
    padding: 5px 10px;
    margin-right: 10px;
}



.part_2 button {
    margin-top: 20px;
    padding: 5px 15px;
}

    /* Styles for the chatbot button */
    .chatbot-button {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
        border-radius: 5px;
        position: fixed;
    right: 30px;
    bottom: 30px;
    }

    /* Styles for the popup container */
    .popup-container {
        display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: #f1f1f1;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        z-index: 9999;
    }

    /* Styles for the close button */
    .close-btn {
        position: absolute;
        top: 10px;
        right: 10px;
        cursor: pointer;
    }

    /* Styles for the iframe */
    .chatbot-iframe {
        width: 100%;
        height: 400px;
        border: none;
    }
    </style>
</head>
<body>
    <div class="main_logo">
        <a href="/"><img src="https://coek.dypgroup.edu.in/wp-content/uploads/2017/06/STRIP.png-2.png" alt="College Logo"></a>
    </div>
    <div class="nav">
        <a href="/elearn/parent.php">Info for parents</a>
        
        <a href="/elearn/learning.php">Learning Materials</a>
        <a href="/elearn/video.php">Video</a>
        <a href="/elearn/call.php">Call</a>
        <a href="/elearn/test.php">Test</a>
        <a href="#contact">Contact</a>
        <?php
        if($login){
            echo '<a href="/elearn/logout.php">Logout</a>';
            echo '<a href="#">'.$email.'</a>';
        }else{
            echo '<a href="/elearn/login.php">Login</a>';
        }
        ?>
    </div>
    <div class="slider">
        <div class="slider_txt_bold">
Welcome to E-Learning Material DYPCET
        </div>
        <div class="slider_txt_light">
            Efficient and Engaging Learning Experiences
        </div>
        <img src="https://coek.dypgroup.edu.in/wp-content/uploads/2017/06/t1538554792_OJmiiK8OlI-1.jpg" alt="College Building Photo">
    </div>
    <div class="img_flex">
        <img src="https://coek.dypgroup.edu.in/wp-content/uploads/2020/03/IMG_3920.jpg" alt="">
        <img src="https://coek.dypgroup.edu.in/wp-content/uploads/2020/03/IMG_3963.jpg" alt="">
    </div>
    <div class="schedule">
        <div class="schedule_1">
            <div class="schedule_big_txt">Schedule</div>
            <div class="schedule_small_txt">E-Learning Material DYPCET provides a flexible schedule that allows you to learn at your own pace and convenience. Our courses are available 24/7, so you can access them anytime, anywhere.</div>
        </div>
        <button>View</button>
    </div>
    <div class="schedule_boxes">
        <div class="schedule_box">
            <div class="schedule_round">M</div>
            <div class="schedule_title">Mondays</div>
            <div class="schedule_data">
                10am - Introduction to E-Commerce<br>
12pm - Marketing Strategies<br>
2pm - Financial Management<br>
            </div>
        </div>
        <div class="schedule_box">
            <div class="schedule_round">T</div>
            <div class="schedule_title">Tuesdays</div>
            <div class="schedule_data">10am - E-Commerce Platforms<br>
                12pm - Supply Chain Management<br>
                2pm - Web Development<br>
            </div>
        </div>
        <div class="schedule_box">
            <div class="schedule_round">W</div>
            <div class="schedule_title">Wednesdays</div>
            <div class="schedule_data">10am - Customer Service<br>
                12pm - Search Engine Optimization<br>
                2pm - Social Media Marketing<br>
            </div>
        </div>
        <div class="schedule_box">
            <div class="schedule_round">T</div>
            <div class="schedule_title">Thursdays</div>
            <div class="schedule_data">10am - Inventory Management<br>
                12pm - Payment Processing<br>
                2pm - Cybersecurity<br>
            </div>
        </div>
        <div class="schedule_box">
            <div class="schedule_round">F</div>
            <div class="schedule_title">Fridays</div>
            <div class="schedule_data">10am - Digital Analytics<br>
                12pm - Mobile Commerce<br>
                2pm - Emerging Technologies<br>
            </div>
        </div>
    </div>
    <div class="footer">
      
        <div class="part">
            <div class="part_1">
                <img src="https://coek.dypgroup.edu.in/wp-content/uploads/2020/03/IMG_3920.jpg" alt="">
            </div>
            <div class="part_2">
                <div class="part_2_txt1">Need Assistance? Let Us Know</div>
                <div class="part_2_txt2">I am happy to answer any questions you may have regarding our syllabus materials and how they can benefit you in your studies. Please feel free to contact me anytime.</div>
                <div class="part_2_txt3">Contact</div>
                <div class="part_2_txt4">By phone: 1234567890<br>
                    By email: teacher.info@dypcet.com<br>
                </div>
                <section id="contact"></section>
                <form action="/elearn/contactUs.php" method="post">
    <div class="divide">
        <input type="text" name="first_name" placeholder="First Name">
        <input type="text" name="last_name" placeholder="Last Name">
    </div>
    <div class="divide">
        <input type="email" name="email" placeholder="Email">
        <input type="text" name="subject" placeholder="Subject">
    </div>
    <textarea name="message" placeholder="Leave me a message..."></textarea>
    <button type="submit">Submit</button>
</form>
            </div>
        </div>
    </div>


    <!-- Chatbot button -->
<button class="chatbot-button" onclick="openPopup()">Open Chatbot</button>

<!-- Popup container -->
<div id="popup" class="popup-container">
    <!-- Close button -->
    <span class="close-btn" onclick="closePopup()">&times;</span>
    <!-- Chatbot iframe -->
    <iframe class="chatbot-iframe" src="http://127.0.0.1:5000/"></iframe>
</div>



<script>
    // Function to open the popup
    function openPopup() {
        document.getElementById("popup").style.display = "block";
    }

    // Function to close the popup
    function closePopup() {
        document.getElementById("popup").style.display = "none";
    }
</script>

</body>
</html>