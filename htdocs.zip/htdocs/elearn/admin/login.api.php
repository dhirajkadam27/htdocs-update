<?php
// Replace these with your MySQL database credentials
$host = "localhost";
$username = "root";
$password = "";
$database = "elearn";


session_start();


// Establish a database connection
$connection = mysqli_connect($host, $username, $password, $database);

if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Get user data from the GET parameters
$email = $_GET['email'];
$password = $_GET['password'];

// Query the database to check if the login credentials are valid
$query = "SELECT * FROM teachers WHERE email='$email' AND pass='$password'";

$result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) == 1) {
    $_SESSION["email"] = $email;

    header("Location: http://localhost/elearn/admin");
exit; // Ensure that no other code is executed after the redirect
} else {
    echo "Login failed. Please check your email and password.";
    echo "<button onclick='history.back()'>Retry</button>";
}

// Close the database connection
mysqli_close($connection);
?>
