<?php
// DB
session_start();
if (!isset($_SESSION["email"])) {
    header("location: ./login.php");
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "elearn";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM feedback_table";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    $feedbacks = [];
    while ($row = $result->fetch_assoc()) {
        $feedbacks[] = $row;
    }
} else {
    $feedbacks = [];
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedbacks</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            margin-top: 20px;
        }

        table {
            width: 50%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px; 
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4b83c1;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        input[type=text] {
            align-items: center;
            margin-left:400px;
            width: 50%;
            padding: 8px;
          
            box-sizing: border-box;
            border: 1px solid black;
            border-radius: 4px;
        }

        input[type=text]:focus {
            outline: none;
            border-color: dodgerblue;
        }


        /* for the sidebar*/
        .sidebar {
      position: fixed;
      left: 0;
      top: 0;
      width: 250px;
      height: 100%;
      background-color: #333;
      padding-top: 20px;
    }

    .sidebar ul {
      list-style-type: none;
      padding: 0;
      margin: 0;
    }

    .sidebar li {
      padding: 10px 20px;
      color: #fff;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .sidebar li:hover {
      background-color: #555;
    }

    .content {
      margin-left: 250px;
      padding: 20px;
    }

    </style>
</head>
<body>
<div class="sidebar">
  <ul>
    <li><a href="index.php">Users</a></li>
    <li><a href="file.php">Files</a></li>
    <li><a href="feedback_fetch.php">Feedback</a></li>
    
  </ul>
</div>

<h2>Feedbacks</h2>

<input type="text" id="searchInput" onkeyup="search()" placeholder="Search for feedbacks..">

<table>
    <tr>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Subject</th>
        <th>Message</th>
    </tr>
    <?php foreach ($feedbacks as $feedback): ?>
        <tr>
            <td><?= $feedback['first_name'] ?></td>
            <td><?= $feedback['last_name'] ?></td>
            <td><?= $feedback['email'] ?></td>
            <td><?= $feedback['subject'] ?></td>
            <td><?= $feedback['message'] ?></td>
        </tr>
    <?php endforeach; ?>
</table>

<script>
    function search() {
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("searchInput");
        filter = input.value.toUpperCase();
        table = document.querySelector("table");
        tr = table.getElementsByTagName("tr");

        for (i = 1; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td");
            let found = false;
            for (let j = 0; j < td.length; j++) {
                if (td[j]) {
                    txtValue = td[j].textContent || td[j].innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        found = true;
                        break;
                    }
                }
            }
            if (found) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
</script>

</body>
</html>
