<?php
// DB
session_start();
if (!isset($_SESSION["email"])) {
    header("location: ./login.php");
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "elearn";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

   // Handle file deletion
   if (isset($_GET['delete'])) {
    $file_id = $_GET['delete'];

    // Query to delete the file record
    $delete_query = "DELETE FROM file WHERE id = $file_id";

    if (mysqli_query($conn, $delete_query)) {
        echo "File deleted successfully.";
    } else {
        echo "Error deleting file: " . mysqli_error($conn);
    }
}

$sql = "SELECT * FROM file";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    $feedbacks = [];
    while ($row = $result->fetch_assoc()) {
        $feedbacks[] = $row;
    }
} else {
    $feedbacks = [];
}

// Close connection
$conn->close();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedbacks</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            margin-top: 20px;
        }

        table {
            width: 50%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px; 
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4b83c1;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        #searchInput {
            align-items: center;
            margin-left:400px;
            width: 50%;
            padding: 8px;
          
            box-sizing: border-box;
            border: 1px solid black;
            border-radius: 4px;
        }

        #searchInput {
            outline: none;
            border-color: dodgerblue;
        }


        /* for the sidebar*/
        .sidebar {
      position: fixed;
      left: 0;
      top: 0;
      width: 250px;
      height: 100%;
      background-color: #333;
      padding-top: 20px;
    }

    .sidebar ul {
      list-style-type: none;
      padding: 0;
      margin: 0;
    }

    .sidebar li {
      padding: 10px 20px;
      color: #fff;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .sidebar li:hover {
      background-color: #555;
    }

    .content {
      margin-left: 250px;
      padding: 20px;
    }


    .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 300px;
            padding: 20px;
            background-color: #f1f1f1;
            border: 1px solid #ddd;
        }
    </style>
</head>
<body>
<div class="sidebar">
  <ul>
    <li><a href="index.php">Users</a></li>
    <li><a href="file.php">Files</a></li>
    <li><a href="feedback_fetch.php">Feedback</a></li>
    
  </ul>
</div>

<h2>Files</h2>

<input type="text" id="searchInput" onkeyup="search()" placeholder="Search for Files..">


<button onclick="openPopup()" class="upload">Upload File</button>

<div id="filePopup" class="popup">
        <h3>Upload a File</h3>
        <form id="fileForm" method="post" enctype="multipart/form-data">
            <input type="text" name="file_name" placeholder="File Name"><br>
            <input type="file" name="file" accept=".txt, .pdf, .doc"><br>
            <input type="button" value="Upload" onclick="uploadFile()">
        </form>
        <br>
        <input type="button" value="Close" onclick="closePopup()">
    </div>

<script>
        function openPopup() {
            var popup = document.getElementById("filePopup");
            popup.style.display = "block";
        }
    
        function uploadFile() {
            var form = document.getElementById("fileForm");
            var formData = new FormData(form);
    
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "../file.api.php", true);
    
            xhr.onload = function () {
                if (xhr.status === 200) {
                    alert("File uploaded successfully!");
                    closePopup();
                } else {
                    alert("File upload failed. Please try again.");
                }
            };
    
            xhr.send(formData);
        }
    
        function closePopup() {
            var popup = document.getElementById("filePopup");
            popup.style.display = "none";
        }
    </script>
<table>
    <tr>
        <th>File</th>
        <th>Action</th>
    </tr>
    <?php foreach ($feedbacks as $feedback): ?>
        <tr>
            <td><?= $feedback['filename'] ?></td>
            <td><a href='?delete="<?= $feedback['id'] ?>"'>Delete</a></td>
        </tr>
    <?php endforeach; ?>
</table>

<script>
    function search() {
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("searchInput");
        filter = input.value.toUpperCase();
        table = document.querySelector("table");
        tr = table.getElementsByTagName("tr");

        for (i = 1; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td");
            let found = false;
            for (let j = 0; j < td.length; j++) {
                if (td[j]) {
                    txtValue = td[j].textContent || td[j].innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        found = true;
                        break;
                    }
                }
            }
            if (found) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
</script>

</body>
</html>
