<?php
if (isset($_GET['id']) && isset($_POST['download']) && isset($_POST['upload'])) {
    $user_id = $_GET['id'];
    $download = isset($_POST['download']) ? 1 : 0;
    $upload = isset($_POST['upload']) ? 1 : 0;

    // Connect to your MySQL database
    $conn = mysqli_connect("localhost", "root", "", "elearn");

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Update the user's "download" and "upload" values in the database
    $sql = "UPDATE users SET download = $download, upload = $upload WHERE id = $user_id";
    if (mysqli_query($conn, $sql)) {
        echo "User updated successfully!";
    } else {
        echo "Error updating user: " . mysqli_error($conn);
    }

    // Close the database connection
    mysqli_close($conn);
} else {
    echo "Invalid request.";
}
?>
