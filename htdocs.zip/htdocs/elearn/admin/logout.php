<?php
   session_start();
   
   session_destroy();
   
   echo "<button onclick='history.back()'>Go Back to Home</button>";
   ?>