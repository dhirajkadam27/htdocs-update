<!DOCTYPE html>
<html>
<head>
    <title>User Management</title>
</head>
<body>
    <h1>User Management</h1>

    <?php
    session_start();
    if (!isset($_SESSION["email"])) {
        header("location: ./login.php");
    }
    
    // Connect to your MySQL database
    $conn = mysqli_connect("localhost", "root", "", "elearn");

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Handle form submissions for updating the values
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $user_id = $_POST['user_id'];
        $download = isset($_POST['download']) ? 1 : 0;
        $upload = isset($_POST['upload']) ? 1 : 0;

        // Update the user's "download" and "upload" values in the database
        $sql = "UPDATE users SET download = $download, upload = $upload WHERE id = $user_id";
        if (mysqli_query($conn, $sql)) {
            echo "User updated successfully!";
        } else {
            echo "Error updating user: " . mysqli_error($conn);
        }
    }

    // Fetch user data from the database
    $sql = "SELECT * FROM users";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<form method='post' action=''>";
            echo "<input type='hidden' name='user_id' value='" . $row['id'] . "'>";
            echo "<p>Name: " . $row['name'] . "</p>";
            echo "<p>Email: " . $row['email'] . "</p>";
            echo "<label for='download'>Download: </label>";
            echo "<input type='checkbox' name='download' value='1' " . ($row['download'] ? 'checked' : '') . ">";
            echo "<br>";
            echo "<label for='upload'>Upload: </label>";
            echo "<input type='checkbox' name='upload' value='1' " . ($row['upload'] ? 'checked' : '') . ">";
            echo "<br>";
            echo "<input type='submit' name='submit' value='Update'>";
            echo "</form>";
        }
    } else {
        echo "No users found.";
    }

    // Close the database connection
    mysqli_close($conn);
    ?>
</body>
</html>
