<?php
session_start();
$login = false;
if (isset($_SESSION["email"])) {
    $email = $_SESSION['email'];
    $login = true;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home | E-Learning DYPCET</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>

body {
    margin: 0;
    padding: 0;
    background: rgb(238, 238, 238);
    font-family: 'Poppins', sans-serif;
}
.main_logo {
    width: 100%;
    background: #103d74;
    text-align: center;
    padding: 50px 0px;
}

.main_logo img {
    width: 50%;
}


.nav {
    width: 100%;
    height: 40px;
    background: #103d74;
    text-align: center;
    border-top: 1px solid #093264;
    display: flex;
    justify-content: center;
}

.nav a {
    color: white;
    height: 40px;
    padding: 0px 20px;
    text-decoration: none;
    display: flex;
    align-items: center;
}
.nav a:hover {
    background: #0c3362;
}

.title {
    font-size: 40px;
    margin: 0px 5%;
    margin-top: 35px;
}

.subtitle {
    font-size: 15px;
    margin: 0px 5%;
    margin-top: 10px;
}

.footer {width: 90%;margin: 50px 0px;padding: 0px 5%;background: #103d74;padding-bottom: 30px;}

.footer_title {
    font-size: 30px;
    padding-top: 20px;
    color: white;
    font-weight: bold;
    margin-bottom: 5px;
}

.footer_subtitle {
    font-size: 15px;
    color: white;
    margin-bottom: 5px;
}

.additional_boxes {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 25px 0px;
}

.additional_box {
    width: 23%;
    height: 100px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: white;
    font-size: 15px;
}

.part {
    display: flex;
}

.part_1 img {
    width: 100%;
}

.part_1 {
    width: 50%;
}

.part_2_txt1 {
    font-size: 25px;
    font-weight: 600;
    color: white;
}

.part_2 {
    width: 48%;
    margin-left: 2%;
    margin-top: 30px;
}

.part_2_txt2 {
    font-size: 15px;
    color: white;
    margin-top: 10px;
}

.part_2_txt3 {
    font-size: 25px;
    font-weight: 600;
    color: white;
    margin-top: 15px;
}

.part_2_txt4 {
    font-size: 15px;
    color: white;
    margin-top: 10px;
    margin-bottom: 20px;
}

.divide {
    width: 100%;
    display: flex;
    margin-bottom: 14px;
}

input {
    width: 95%;
    padding: 5px 10px;
    margin-right: 10px;
}

.divide input {
    width: 45%;
    padding: 5px 10px;
    margin-right: 10px;
}



.part_2 button {
    margin-top: 20px;
    padding: 5px 15px;
}
.api input {
    width: 250px;
    display: block;
    padding: 5px 10px;
    margin-right: 10px;
    margin-left: 5%;
    margin-top: 10px;
}
.api button {
    margin-right: 10px;
    margin-left: 5%;
    margin-top: 10px;
    background: #103d74;
    color: white;
    border: none;
    padding: 4px 10px;
}

  /* Styles for the chatbot button */
  .chatbot-button {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
        border-radius: 5px;
        position: fixed;
    right: 30px;
    bottom: 30px;
    }

    /* Styles for the popup container */
    .popup-container {
        display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: #f1f1f1;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        z-index: 9999;
    }

    /* Styles for the close button */
    .close-btn {
        position: absolute;
        top: 10px;
        right: 10px;
        cursor: pointer;
    }

    /* Styles for the iframe */
    .chatbot-iframe {
        width: 100%;
        height: 400px;
        border: none;
    }
    </style>
</head>
<body>
    <div class="main_logo">
       <a href="/"><img src="https://coek.dypgroup.edu.in/wp-content/uploads/2017/06/STRIP.png-2.png" alt="College Logo"></a>
    </div>
    <div class="nav">
        <a href="/elearn/parent.php">Info for parents</a>
        
        <a href="/elearn/learning.php">Learning Materials</a>
        <a href="/elearn/video.php">Video</a>
        <a href="/elearn/call.php">Call</a>
        <a href="/elearn/test.php">Test</a>
        <a href="#contact">Contact</a>
        <?php
        if($login){
            echo '<a href="/elearn/logout.php">Logout</a>';
            echo '<a href="#">'.$email.'</a>';
        }else{
            echo '<a href="/elearn/login.php">Login</a>';
        }
        ?>
    </div>
 

    <div class="title">
        Sign Up
    </div>
    <div class="subtitle">
        Already a member?<a href="/elearn/login.php">Log In</a>
    </div>

    <form action="/elearn/signup.api.php" method="get" class="api">
        <input name="name" required placeholder="Name">
        <input name="email" required placeholder="Email">
        <input name="password" required placeholder="Password">
        <button>Create Account</button>
    </form>

    <div class="footer">
      
        <div class="part">
            <div class="part_1">
                <img src="https://coek.dypgroup.edu.in/wp-content/uploads/2020/03/IMG_3920.jpg" alt="">
            </div>
            <div class="part_2">
                <div class="part_2_txt1">Need Assistance? Let Us Know</div>
                <div class="part_2_txt2">I am happy to answer any questions you may have regarding our syllabus materials and how they can benefit you in your studies. Please feel free to contact me anytime.</div>
                <div class="part_2_txt3">Contact</div>
                <div class="part_2_txt4">By phone: 1234567890<br>
                    By email: teacher.info@dypcet.com<br>
                </div>
                <section id="contact"></section>
                <form action="">
                    <div class="divide">
                        <input placeholder="First Name">
                        <input placeholder="Last Name">
                    </div>
                    <div class="divide">
                        <input placeholder="Email">
                        <input placeholder="Subject">
                    </div>
                    <input placeholder="Leave me a message...">
                    <button>Submit</button>
                </form>
            </div>
        </div>
    </div>

        <!-- Chatbot button -->
<button class="chatbot-button" onclick="openPopup()">Open Chatbot</button>

<!-- Popup container -->
<div id="popup" class="popup-container">
    <!-- Close button -->
    <span class="close-btn" onclick="closePopup()">&times;</span>
    <!-- Chatbot iframe -->
    <iframe class="chatbot-iframe" src="http://127.0.0.1:5000/"></iframe>
</div>



<script>
    // Function to open the popup
    function openPopup() {
        document.getElementById("popup").style.display = "block";
    }

    // Function to close the popup
    function closePopup() {
        document.getElementById("popup").style.display = "none";
    }
</script>

</body>
</html>