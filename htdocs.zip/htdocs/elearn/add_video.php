<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add YouTube Videos</title>
</head>
<body>
    <h1>Add YouTube Videos</h1>
    <form action="save_video.php" method="post">
        <label for="video_url">YouTube Video URL:</label><br>
        <input type="text" id="video_url" name="video_url" required><br><br>
        <input type="submit" value="Add Video">
    </form>
</body>
</html>
