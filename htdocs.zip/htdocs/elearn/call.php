<html>

<head>
    <style>
        #root {
            width: 100vw;
            height: 100vh;
        }

        #joinLink {
            position: fixed;
            top: 20px;
            left: 20px;
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        #joinLink:hover {
            background-color: #0056b3;
        }
    </style>
</head>


<body>
    <!-- <div id="root"></div>
    <button id="joinLink">Join Video Call</button> Added Join Link button -->
</body>
<script src="https://unpkg.com/@zegocloud/zego-uikit-prebuilt/zego-uikit-prebuilt.js"></script>
<script>
    window.onload = function () {
        function getUrlParams(url) {
            let urlStr = url.split('?')[1];
            const urlSearchParams = new URLSearchParams(urlStr);
            const result = Object.fromEntries(urlSearchParams.entries());
            return result;
        }

        const roomID = getUrlParams(window.location.href)['roomID'] || (Math.floor(Math.random() * 10000) + "");
        const userID = Math.floor(Math.random() * 10000) + "";
        const userName = "userName" + userID;
        const appID = 1254139318;
        const serverSecret = "5b6ce3152791a1acdadd78576e478674";
        const kitToken = ZegoUIKitPrebuilt.generateKitTokenForTest(appID, serverSecret, roomID, userID, userName);

        const zp = ZegoUIKitPrebuilt.create(kitToken);
        zp.joinRoom({
            container: document.querySelector("#root"),
            sharedLinks: [{
                name: 'Meeting link',
                url: window.location.protocol + '//' + window.location.host + window.location.pathname + '?roomID=' + roomID,
            }],
            scenario: {
                mode: ZegoUIKitPrebuilt.VideoConference,
            },

            turnOnMicrophoneWhenJoining: true,
            turnOnCameraWhenJoining: true,
            showMyCameraToggleButton: true,
            showMyMicrophoneToggleButton: true,
            showAudioVideoSettingsButton: true,
            showScreenSharingButton: true,
            showTextChat: true,
            showUserList: true,
            maxUsers: 50,
            layout: "Sidebar",
            showLayoutButton: true,

        });

        // Get the join link button element
        const joinLinkButton = document.getElementById("joinLink");

        // Add click event listener to the join link button
        joinLinkButton.addEventListener("click", function () {
            // Open the join link in a new tab when the button is clicked
            window.open(window.location.href);
        });
    }
</script>

</html>
