<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "elearn";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM quiz_questions";
$result = $conn->query($sql);

$questions = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $questions[] = $row;
    }
}

$conn->close();
?>




<?php
session_start();
$login = false;
if (isset($_SESSION["email"])) {
    $email = $_SESSION['email'];
    $login = true;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home | E-Learning DYPCET</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>

body {
    margin: 0;
    padding: 0;
    background: rgb(238, 238, 238);
    font-family: 'Poppins', sans-serif;
}
.main_logo {
    width: 100%;
    background: #103d74;
    text-align: center;
    padding: 50px 0px;
}

.main_logo img {
    width: 50%;
}


.nav {
    width: 100%;
    height: 40px;
    background: #103d74;
    text-align: center;
    border-top: 1px solid #093264;
    display: flex;
    justify-content: center;
}

.nav a {
    color: white;
    height: 40px;
    padding: 0px 20px;
    text-decoration: none;
    display: flex;
    align-items: center;
}
.nav a:hover {
    background: #0c3362;
}

h2.title {
    font-size: 20px;
    text-align: center;
    margin-top: 30px;
}

form {
    width: 300px;
    margin: 20px auto;
}

h2 {
    text-align: center;
    font-size: 20px;
    margin-top: 50px;
    font-weight: 400;
}


iframe {display: block;margin: 10px auto;}

p {
    font-size: 15px;
    text-align: center;
    margin-bottom: 40px;
    margin-top: -5px;
}


  /* Styles for the chatbot button */
  .chatbot-button {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
        border-radius: 5px;
        position: fixed;
    right: 30px;
    bottom: 30px;
    }

    /* Styles for the popup container */
    .popup-container {
        display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: #f1f1f1;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        z-index: 9999;
    }

    /* Styles for the close button */
    .close-btn {
        position: absolute;
        top: 10px;
        right: 10px;
        cursor: pointer;
    }

    /* Styles for the iframe */
    .chatbot-iframe {
        width: 100%;
        height: 400px;
        border: none;
    }


    
    .content {
            margin-left: 250px;
            padding: 20px;
        }

        .content h3 {
            margin-bottom: 10px;
        }

        .content form {
            margin-bottom: 20px;
            margin:0px
        }

        .content input[type='submit'] {
            margin-top: 10px;
            padding: 5px 15px;
            background-color: #103d74;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .content input[type='submit']:hover {
            background-color: #103d74;
        }

        .content hr {
            margin-top: 20px;
        }



        .quiz-container {
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-family: Arial, sans-serif; 
        background-color: #f9f9f9;
    }
    .question {
        margin-bottom: 15px;
    }
    .question p {
        font-size: 15px;
    text-align: left;
    margin-bottom: 10px;
    margin-top: 36px;
    font-weight:600;
    }
    .options label {
        display: block;
        margin-bottom: 10px;
    }
    .submit-btn {
        display: block;
        margin-top: 20px;
        padding: 10px 20px;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    .result-container {
        margin-top: 20px;
    }
    .chart-container {
        margin-top: 20px;
    }

    </style>
</head>
<body>
    <div class="main_logo">
       <a href="/"><img src="https://coek.dypgroup.edu.in/wp-content/uploads/2017/06/STRIP.png-2.png" alt="College Logo"></a>
    </div>
    <div class="nav">
        <a href="/elearn/parent.php">Info for parents</a>
        
        <a href="/elearn/learning.php">Learning Materials</a>
        <a href="/elearn/video.php">Video</a>
        <a href="/elearn/call.php">Call</a>
        <a href="/elearn/test.php">Test</a>
        <a href="#contact">Contact</a>
        <?php
        if($login){
            echo '<a href="/elearn/logout.php">Logout</a>';
            echo '<a href="#">'.$email.'</a>';
        }else{
            echo '<a href="/elearn/login.php">Login</a>';
        }
        ?>
    </div>
 


<div class="quiz-container">
    <h1>Test</h1>
    <form id="quiz-form">
        <div class="question">
            <p>1. What does HTML stand for?</p>
            <div class="options">
                <label><input type="radio" name="q1" value="Hypertext Markup Language"> Hypertext Markup Language</label>
                <label><input type="radio" name="q1" value="Hyperlink and Text Markup Language"> Hyperlink and Text Markup Language</label>
                <label><input type="radio" name="q1" value="Home Tool Markup Language"> Home Tool Markup Language</label>
            </div>
        </div>
        <!-- More questions go here -->
        <div class="question">
            <p>2. Which of the following is NOT a programming language?</p>
            <div class="options">
                <label><input type="radio" name="q2" value="Java"> Java</label>
                <label><input type="radio" name="q2" value="CSS"> CSS</label>
                <label><input type="radio" name="q2" value="Python"> Python</label>
            </div>
        </div>
        <div class="question">
            <p>3. What does CSS stand for?</p>
            <div class="options">
                <label><input type="radio" name="q3" value="Cascading Style Sheets"> Cascading Style Sheets</label>
                <label><input type="radio" name="q3" value="Creative Style Sheets"> Creative Style Sheets</label>
                <label><input type="radio" name="q3" value="Computer Style Sheets"> Computer Style Sheets</label>
            </div>
        </div>
        <!-- Repeat the structure for each question -->
        
        <button type="submit" class="submit-btn">Submit Answers</button>
    </form>

    <div class="result-container" style="display: none;">
        <h2>Results</h2>
        <div id="results"></div>
        <div class="chart-container">
            <canvas id="chart"></canvas>
        </div>
    </div>
</div>

<script>
    document.getElementById('quiz-form').addEventListener('submit', function(event) {
        event.preventDefault();

        // Questions and Answers
        const correctAnswers = {
            q1: 'Hypertext Markup Language',
            q2: 'CSS',
            q3: 'Cascading Style Sheets'
            // Add more questions and answers here
        };

        const explanations = {
            q1: 'HTML is a markup language used for creating web pages.',
            q2: 'CSS stands for Cascading Style Sheets, which is used for styling web pages.',
            q3: 'CSS stands for Cascading Style Sheets, which is used for styling web pages.'
            // Add more explanations here
        };

        let userAnswers = {};
        let correctCount = 0;
        let incorrectCount = 0;
        let resultsHTML = '';

        // Get user answers
        const formData = new FormData(event.target);
        for (const entry of formData.entries()) {
            const question = entry[0];
            const answer = entry[1];
            userAnswers[question] = answer;
            if (correctAnswers[question] === answer) {
                correctCount++;
                resultsHTML += `<p>${question}: Correct!</p>`;
            } else {
                incorrectCount++;
                resultsHTML += `<p>${question}: Incorrect. Correct answer: ${correctAnswers[question]}</p>`;
                if (explanations[question]) {
                    resultsHTML += `<p>${explanations[question]}</p>`;
                }
            }
        }

        // Display results
        const resultContainer = document.querySelector('.result-container');
        const resultsElement = document.getElementById('results');
        resultsElement.innerHTML = resultsHTML;
        resultContainer.style.display = 'block';

        // Chart
        const ctx = document.getElementById('chart').getContext('2d');
        const chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Correct', 'Incorrect'],
                datasets: [{
                    label: 'Performance',
                    data: [correctCount, incorrectCount],
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.5)',
                        'rgba(255, 99, 132, 0.5)'
                    ],
                    borderColor: [
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 99, 132, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>



    <!-- Chatbot button -->
    <button class="chatbot-button" onclick="openPopup()">Open Chatbot</button>

<!-- Popup container -->
<div id="popup" class="popup-container">
    <!-- Close button -->
    <span class="close-btn" onclick="closePopup()">&times;</span>
    <!-- Chatbot iframe -->
    <iframe class="chatbot-iframe" src="http://127.0.0.1:5000/"></iframe>
</div>



<script>
    // Function to open the popup
    function openPopup() {
        document.getElementById("popup").style.display = "block";
    }

    // Function to close the popup
    function closePopup() {
        document.getElementById("popup").style.display = "none";
    }
</script>
  
</body>
</html>