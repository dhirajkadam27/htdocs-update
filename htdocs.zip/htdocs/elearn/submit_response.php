<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "elearn"; // Replace "elearn" with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve user response from the form submission
$question_id = $_POST['question_id'];
$selected_option = $_POST['option'];

// Retrieve correct option from the database
$sql = "SELECT correct_option FROM quiz_questions WHERE id = $question_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $correct_option = $row['correct_option'];

    // Check if user response matches the correct option
    if ($selected_option == $correct_option) {
        echo "You are correct!"; // Display message for correct answer

        // Update user's score in the database
        // For example, you can have a users table with a column for their score
        // Here, we'll just increment the score by 1 for demonstration purposes
        // $update_sql = "UPDATE users SET score = score + 1 WHERE user_id = 'user_id_here'";
        // Replace 'user_id_here' with the actual user ID whose score you want to update

        // if ($conn->query($update_sql) === TRUE) {
        //     echo " Your score has been updated.";
        // } else {
        //     echo " Error updating score: " . $conn->error;
        // }
    } else {
        echo "Try again!"; // Display message for incorrect answer
    }
} else {
    echo "Question not found.";
}

$conn->close();
?>
