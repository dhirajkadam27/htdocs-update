<?php
// Replace these with your MySQL database credentials

session_start();

$host = "localhost";
$username = "root";
$password = "";
$database = "elearn";

// Establish a database connection
$connection = mysqli_connect($host, $username, $password, $database);

if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Get user data from the GET parameters
$name = $_GET['name'];
$email = $_GET['email'];
$password = $_GET['password'];

// Insert user data into the database
$query = "INSERT INTO users (name, email, pass,download ,upload) VALUES ('$name', '$email', '$password', 'yes', 'yes')";

if (mysqli_query($connection, $query)) {
    $_SESSION["email"] = $email;
    header("Location: http://localhost/elearn/");
exit; // Ensure that no other code is executed after the redirect
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($connection);
    echo "<button onclick='history.back()'>Retry</button>";
}

// Close the database connection
mysqli_close($connection);
?>
