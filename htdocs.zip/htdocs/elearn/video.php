<?php
session_start();
$login = false;
if (isset($_SESSION["email"])) {
    $email = $_SESSION['email'];
    $login = true;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home | E-Learning DYPCET</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <style>

body {
    margin: 0;
    padding: 0;
    background: rgb(238, 238, 238);
    font-family: 'Poppins', sans-serif;
}
.main_logo {
    width: 100%;
    background: #103d74;
    text-align: center;
    padding: 50px 0px;
}

.main_logo img {
    width: 50%;
}


.nav {
    width: 100%;
    height: 40px;
    background: #103d74;
    text-align: center;
    border-top: 1px solid #093264;
    display: flex;
    justify-content: center;
}

.nav a {
    color: white;
    height: 40px;
    padding: 0px 20px;
    text-decoration: none;
    display: flex;
    align-items: center;
}
.nav a:hover {
    background: #0c3362;
}

h2.title {
    font-size: 20px;
    text-align: center;
    margin-top: 30px;
}

form {
    width: 300px;
    margin: 20px auto;
}

h2 {
    text-align: center;
    font-size: 20px;
    margin-top: 50px;
    font-weight: 400;
}


iframe {display: block;margin: 10px auto;}

p {
    font-size: 15px;
    text-align: center;
    margin-bottom: 40px;
    margin-top: -5px;
}


  /* Styles for the chatbot button */
  .chatbot-button {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
        border-radius: 5px;
        position: fixed;
    right: 30px;
    bottom: 30px;
    }

    /* Styles for the popup container */
    .popup-container {
        display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: #f1f1f1;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        z-index: 9999;
    }

    /* Styles for the close button */
    .close-btn {
        position: absolute;
        top: 10px;
        right: 10px;
        cursor: pointer;
    }

    /* Styles for the iframe */
    .chatbot-iframe {
        width: 100%;
        height: 400px;
        border: none;
    }

    </style>
</head>
<body>
    <div class="main_logo">
       <a href="/"><img src="https://coek.dypgroup.edu.in/wp-content/uploads/2017/06/STRIP.png-2.png" alt="College Logo"></a>
    </div>
    <div class="nav">
        <a href="/elearn/parent.php">Info for parents</a>
        
        <a href="/elearn/learning.php">Learning Materials</a>
        <a href="/elearn/video.php">Video</a>
        <a href="/elearn/call.php">Call</a>
        <a href="/elearn/test.php">Test</a>
        <a href="#contact">Contact</a>
        <?php
        if($login){
            echo '<a href="/elearn/logout.php">Logout</a>';
            echo '<a href="#">'.$email.'</a>';
        }else{
            echo '<a href="/elearn/login.php">Login</a>';
        }
        ?>
    </div>
 

    <h2 class="title">Select a Course and Level</h2>
    <form method="POST" action="video.php">
        <label for="course">Select Course:</label>
        <select name="course" id="course">
            <option value="python">Python</option>
            <option value="c">C</option>
            <option value="cpp">C++</option>
        </select>
        <br>
        <label for="level">Select Level:</label>
        <select name="level" id="level">
            <option value="beginner">Beginner</option>
            <option value="intermediate">Intermediate</option>
            <option value="advance">Advanced</option>
        </select>
        <br>
        <input type="submit" value="Scrape Videos">
    </form>


    
<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $course = $_POST["course"];
    $level = $_POST["level"];
    
    // Use YouTube Data API to fetch related videos
    $apiKey = "YOUR_YOUTUBE_API_KEY";
    $query = "$course $level tutorial"; // Example query
    
    $url = "https://www.googleapis.com/youtube/v3/search?key=AIzaSyAnApNNZ7Wv6k8X6ocMg70bXZAvndVwmOc&part=snippet&type=video&q=" . urlencode($query) . "&maxResults=5";

    $response = file_get_contents($url);
    $data = json_decode($response, true);

    // Display the videos
    if (isset($data['items'])) {
        echo "<h2>Top 5 Related Videos for $course $level:</h2>";
        foreach ($data['items'] as $item) {
            $title = $item['snippet']['title'];
            $videoId = $item['id']['videoId'];
            // Embed the video
            echo "<iframe width='560' height='315' src='https://www.youtube.com/embed/$videoId' frameborder='0' allowfullscreen></iframe>";
            echo "<p>$title</p>";
        }
    } else {
        echo "<p>No videos found</p>";
    }
}

?>


    <!-- Chatbot button -->
    <button class="chatbot-button" onclick="openPopup()">Open Chatbot</button>

<!-- Popup container -->
<div id="popup" class="popup-container">
    <!-- Close button -->
    <span class="close-btn" onclick="closePopup()">&times;</span>
    <!-- Chatbot iframe -->
    <iframe class="chatbot-iframe" src="http://127.0.0.1:5000/"></iframe>
</div>



<script>
    // Function to open the popup
    function openPopup() {
        document.getElementById("popup").style.display = "block";
    }

    // Function to close the popup
    function closePopup() {
        document.getElementById("popup").style.display = "none";
    }
</script>
  
</body>
</html>