<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle.work</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    
    <!-- inter font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=Outfit:wght@100..900&display=swap"
        rel="stylesheet">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


    <link rel="stylesheet" href="https://dbrekalo.github.io/fastselect/dist/fastselect.min.css">
        <script src="https://dbrekalo.github.io/fastselect/dist/fastselect.standalone.js"></script>


    <style>
    :root {
        --orange-color: #FF6B00;
        --bg: #ca5500;
        --black: rgb(30, 30, 30);

    }

    body {
        margin: 0;
        padding: 0;
        font-family: "Inter", sans-serif;
        color: var(--black-color);
        background: var(--bg);
        width: 100%;
        height: 100vh;
    }

    input {
        font-family: "Inter", sans-serif;
        color: var(--black);
        outline: none;
    }

    button {
        font-family: "Inter", sans-serif;
        color: var(--black);
        cursor: pointer;
    }

    input::placeholder {
        color: var(--black);
    }

    .nav {
        width: 100%;
        height: 50px;
        display: flex;
        align-items: center;
    }

    .nav-left {
        width: 400px;
    }

    .nav-right {
        width: calc(100% - 400px);
        display: flex;
        align-items: center;
        justify-content: end;
    }

    .nav-right input {
        border: none;
        background: #ffffffb3;
        font-size: 13px;
        font-weight: 500;
        padding: 7px 10px;
        border-radius: 5px;
        width: 500px;
        color: black;
    }

    .nav-right img {
        height: 25px;
        margin-right: 15px;
    }

    .nav-right-users {
        display: flex;
        align-items: center;
        justify-content: center;
        border: 2px solid white;
        padding: 2px 3px;
        border-radius: 8px;
        margin-right: 20px;
    }

    .nav-right-users-txt {
        font-size: 13px;
        font-weight: 500;
        color: white;
        margin-right: 3px;
    }

    img.nav-right-logo {
        width: 20px;
        height: 20px;
        border-radius: 5px;
        margin-right: 10px;
    }

    .main {
        width: 100%;
        height: calc(100vh - 55px);
        display: flex;
    }

    .main-left-1 {
        width: 100px;
        height: 100%;
        background: none;
        text-align: center;
    }

    .main-left-2 {
        width: 300px;
        height: 100%;
        background: #f7f7f7;
        border-radius: 7px 0px 0px 7px;
        box-shadow: -4px -4px 16px #00000017;
        border: 1px solid lightgrey;
        border-right: 0px;
    }

    .main-right {
        width: calc(100% - 405px);
        height: 100%;
        background: white;
        border-radius: 0px 7px 7px 0px;
        box-shadow: -4px -4px 16px #00000017;
        border: 1px solid lightgrey;
        overflow: auto;
    }

    .main-left-1 button {
        width: 60px;
        height: 60px;
        text-align: center;
        font-size: 10px;
        font-weight: 600;
        margin: 0px auto;
        margin-top: 20px;
        border: none;
        background: none;
        color: white;
        border-radius: 10px;
        display: block !important;
    }


    svg.be {
        stroke: #007AFF;
    }

    .main-left-1 .active {
        background: #ff8126;
    }

    .main-left-1 button:hover {
        background: #e56101;
    }


    .main-left-1 button img {
        width: 25px;
        margin-bottom: 5px;
    }

    .dropdown_bottom {
        position: absolute;
        bottom: 20px;
        left: 20px;
    }

    .dropdown-profile {
        display: flex;
        align-items: center;
    }

    .dropdown-profile .icon {
        width: 40px;
        height: 40px;
        background: #FF6B00;
        border-radius: 5px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        color: white;
        font-weight: 500;
        margin: 10px 15px;
    }

    .dropdown-profile-info .name {
        font-size: 15px;
        font-weight: 500;
    }

    .dropdown-profile-info .workspaces {
        font-size: 13px;
        font-weight: 400;
        margin-top: 5px;
        color: #999999;
    }

    .dropdown-profile-info .workspace {
        font-size: 15px;
        font-weight: 500;
    }

    ul.dropdown-menu.show {
        width: 260px;
        transform: translate3d(55px, -30px, 0px) !important;
    }

    ul.create-dropdown.show {
        width: 260px;
        transform: translate3d(90px, -23px, 0px) !important;
    }

    ul.create-dropdown a {
        padding: 10px 20px;
    }

    .dropdown a:hover {
        background: #007AFF;
        color: white;
    }

    .create_box {
        display: flex;
        align-items: center;
    }

    .create_box_img {
        width: 50px;
        height: 50px;
        background: #e3e3e3;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .create_box_img img {
        margin: 0;
        width: 25px;
    }


    .create_box_txt {
        margin-left: 10px;
    }

    .create_box_txt1 {
        font-size: 12px;
        font-weight: 600;
    }

    .create_box_txt2 {
        font-size: 12px;
        font-weight: 400;
    }

    .main-left-1-logo {
        width: 50px;
        height: 50px;
        display: flex;
        align-items: center;
        justify-content: center;
        border: 2px solid white;
        background: #ff6b00;
        border-radius: 10px;
        font-size: 25px;
        font-weight: 500;
        color: white;
        cursor: pointer;
    }

    .main-left-2 button {
        width: 90%;
        margin: 0px auto;
        border: none;
        margin-top: 15px;
        padding: 5px 10px;
        text-align: left;
        font-size: 11px;
        font-weight: 600;
        display: flex;
        align-items: center;
        background: none;
        border-radius: 5px;
        color: #313131;
    }

    .main-left-2 button:hover {
        background: #e2e2e2;
    }

    .main-left-2-title {
        font-size: 13px;
        font-weight: 600;
        margin-left: 15px;
        margin-top: 10px;
        margin-bottom: 15px;
    }

    .main-left-2 button img {
        width: 18px;
        margin-right: 15px;
    }

    .main-left-2 .active {
        background: #343434 !important;
        color: white;
    }

    .main-left-2 .active img {
        filter: invert(1);
    }

    .seperate {
        margin: 15px 0px;
        width: 100%;
        height: 1px;
        background: lightgrey;
    }

    .email_flex {
    display: flex;
    align-items: center;
    justify-content: space-evenly;
    margin-bottom: 20px;
}

.email_flex_box {
    padding: 15px 25px;
    margin: 20px;
    text-align: center;
    border: 2px dashed #dbdbdb;
    border-radius: 15px;
    cursor: pointer;
}

.email_flex_box img {
    width: 30px;
}

.email_flex_box_txt {
    font-size: 15px;
    font-weight: 400;
    margin-top: 15px;
}



    <?php echo $style;
    ?>
    </style>
</head>

<body>

<!-- Modal -->
<div class="modal fade" id="mail_create" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <div class="modal_title">Email Type</div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      
      <div class="email_flex">
        <div class="email_flex_box" onclick="window.location.href='/app/mail/create/raw/'">
        <img src="/app/asset/img/draft.svg">
        <div class="email_flex_box_txt">Simple Mail</div>
        </div>
        <div class="email_flex_box" onclick="window.location.href='/app/mail/create/html/'">
        <img src="/app/asset/img/draft.svg">
        <div class="email_flex_box_txt">Design Mail</div>
        </div>
      </div>
    
    </div>
  </div>
</div>


<!-- Modal -->
<div class="modal fade" id="template_create" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <div class="modal_title">Template Type</div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      
      <div class="email_flex">
        <div class="email_flex_box" onclick="window.location.href='/app/mail/create/raw/'">
        <img src="/app/asset/img/draft.svg">
        <div class="email_flex_box_txt">Simple Mail</div>
        </div>
        <div class="email_flex_box" onclick="window.location.href='/app/mail/create/html/'">
        <img src="/app/asset/img/draft.svg">
        <div class="email_flex_box_txt">Design Mail</div>
        </div>
      </div>
    
    </div>
  </div>
</div>



    <div class="nav">
        <div class="nav-left"></div>
        <div class="nav-right">
            <input placeholder="search toggle">
            <div class="nav-right">
                <div class="nav-right-users">
                    <img class="nav-right-logo" src="/app/asset/img/yellow_profile.svg">
                    <div class="nav-right-users-txt">2</div>
                </div>
                <img class="nav-right-dark" src="/app/asset/img/darkmode.svg">
            </div>
        </div>
    </div>
    <div class="main">
        <div class="main-left-1">
            <div class="dropdown">
                <button data-bs-toggle="dropdown">
                    <img src="/app/asset/img/create.svg">
                    <div class="text">Create</div>
                </button>
                <ul class="dropdown-menu create-dropdown">
                    <li><a class="dropdown-item" data-bs-toggle="offcanvas" href="#offcanvasprofile">
                            <div class="create_box" data-bs-toggle="modal" data-bs-target="#mail_create">
                                <div class="create_box_img"><img src="/app/asset/img/draft.svg"></div>
                                <div class="create_box_txt">
                                    <div class="create_box_txt1">Mail</div>
                                    <div class="create_box_txt2">Create and send mail</div>
                                </div>
                            </div>
                        </a></li>
                    <li><a class="dropdown-item" data-bs-toggle="offcanvas" href="#offcanvasemail">
                            <div class="create_box">
                                <div class="create_box_img"><img src="/app/asset/img/draft.svg"></div>
                                <div class="create_box_txt">
                                    <div class="create_box_txt1">Campaign</div>
                                    <div class="create_box_txt2">Design and run campaign</div>
                                </div>
                            </div>
</a>
                    </li>
                    <li><a class="dropdown-item" data-bs-toggle="offcanvas" href="#offcanvasworkspace">
                            <div class="create_box" onclick="window.location.href='/app/contact/add/contact'">
                                <div class="create_box_img"><img src="/app/asset/img/draft.svg"></div>
                                <div class="create_box_txt">
                                    <div class="create_box_txt1">Contact</div>
                                    <div class="create_box_txt2">Create new contact</div>
                                </div>
                            </div>
</a>
                    </li>
                    <li><a class="dropdown-item" data-bs-toggle="offcanvas" href="#offcanvasworkspace">
                            <div class="create_box" data-bs-toggle="modal" data-bs-target="#template_create">
                                <div class="create_box_img"><img src="/app/asset/img/draft.svg"></div>
                                <div class="create_box_txt">
                                    <div class="create_box_txt1">Template</div>
                                    <div class="create_box_txt2">Design new template</div>
                                </div>
                            </div>
</a>
                    </li>
                </ul>
            </div>
            <button onclick="window.location.href='/app/'" class="<?php if($main_left_1=='mail'){ echo 'active'; }?>">
                <img src="/app/asset/img/mailopen.svg">
                <div class="text">Mail</div>
            </button>
            <button onclick="window.location.href='/app/campaign'"
                class="<?php if($main_left_1=='campaign'){ echo 'active'; }?>">
                <img src="/app/asset/img/campaign.svg">
                <div class="text">Campaign</div>
            </button>
            <button onclick="window.location.href='/app/contact'"
                class="<?php if($main_left_1=='contact'){ echo 'active'; }?>">
                <img src="/app/asset/img/contact.svg">
                <div class="text">Contact</div>
            </button>
            <button onclick="window.location.href='/app/automation'"
                class="<?php if($main_left_1=='automation'){ echo 'active'; }?>">
                <img src="/app/asset/img/bot.svg">
                <div class="text">Automation</div>
            </button>

            <div class="dropdown_bottom dropdown">
                <div class="main-left-1-logo" data-bs-toggle="dropdown">
                    D
                </div>
                <ul class="dropdown-menu">
                    <div class="dropdown-profile">
                        <div class="icon">D</div>
                        <div class="dropdown-profile-info">
                            <div class="name">Dhiraj Kadam</div>
                            <div class="workspaces">2 Workspaces</div>
                        </div>
                    </div>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li><a class="dropdown-item" data-bs-toggle="offcanvas" href="#offcanvasprofile">Profile</a></li>
                    <li><a class="dropdown-item" data-bs-toggle="offcanvas" href="#offcanvasemail">Emails</a></li>
                    <li><a class="dropdown-item" data-bs-toggle="offcanvas" href="#offcanvasworkspace">Workspaces</a>
                    </li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li><a class="dropdown-item" href="#">Sign Out</a></li>
                </ul>
            </div>


        </div>
        <div class="main-left-2">

            <?php echo $main_left_2; ?>

        </div>
        <div class="main-right">

            <?php echo $main_right; ?>

        </div>
    </div>
</body>

</html>