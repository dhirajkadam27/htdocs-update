<?php

$main_left_1 = "mail";
$main_left_2 = <<<'HTML'
<div class="main-left-2-title">Mailboxes</div>
<button>
    <img src="/app/asset/img/inbox.svg">
    Inbox
</button>
<button>
    <img src="/app/asset/img/star.svg">
    VIPs
</button>
<button>
    <img src="/app/asset/img/flag.svg">
    Flagged
</button>
<button>
    <img src="/app/asset/img/draft.svg">
    Drafts
</button>
<button>
    <img src="/app/asset/img/sent.svg">
    Sent
</button>
<button>
    <img src="/app/asset/img/junk.svg">
    Junks
</button>
<button>
    <img src="/app/asset/img/trash.svg">
    Trash
</button>

<div class="seperate"></div>


<button>
    <img src="/app/asset/img/today.svg">
    Today
</button>
<button>
    <img src="/app/asset/img/remindme.svg">
    Remind Me
</button>
<button>
    <img src="/app/asset/img/sendlater.svg">
    Send Later
</button>
<button>
    <img src="/app/asset/img/template.svg">
    Template
</button>
HTML;

$main_right = <<<'HTML'
 <div class="top_functions">
    <img src="/app/asset/img/back.svg">
 </div>

 <div class="email_profile_info">
    <div class="email_profile_pic">D</div>
    <div class="email_profile_info_txts">
        <div class="email_profile_info_txt1">Dhiraj <span>< dhirajkadam.official@gmail.com><span></div>
        <div class="email_profile_info_txt2">to dhirajkadam@outlook</div>
    </div>
 </div>

 <iframe src="./frame.php" class="mail_preview_frame"></iframe>

HTML;


$style = <<<'CSS'
  
  .top_functions {
    display: flex;
    align-items: center;
}

.top_functions img {
    width: 25px;
    margin: 10px 20px;
}

.email_profile_info {
    display: flex;
    align-items: center;
    padding: 10px 20px;
}

.email_profile_pic {
    width: 40px;
    height: 40px;
    background: #f2c744;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    font-weight: 500;
    color: white;
    border-radius: 100px;
    margin-right: 15px;
}

.email_profile_info_txt1 {
    font-size: 15px;
    font-weight: 600;
}
.email_profile_info_txt1 span {
    font-size: 12px;
    font-weight: 400;
}

.email_profile_info_txt2 {
    font-size: 12px;
    font-weight: 400;
    color: #797979;
}

iframe.mail_preview_frame {
    width: 100%;
    margin-top: 20px;
    height: -webkit-fill-available;
}

CSS;
include '../../component/frame/index.php';
?>