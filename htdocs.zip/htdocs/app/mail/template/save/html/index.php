<?php

$main_left_1 = "mail";
$main_left_2 = <<<'HTML'
<div class="main-left-2-title">Mailboxes</div>
<button class="active">
    <img src="/app/asset/img/inbox.svg">
    Inbox
</button>
<button>
    <img src="/app/asset/img/star.svg">
    VIPs
</button>
<button>
    <img src="/app/asset/img/flag.svg">
    Flagged
</button>
<button>
    <img src="/app/asset/img/draft.svg">
    Drafts
</button>
<button>
    <img src="/app/asset/img/sent.svg">
    Sent
</button>
<button>
    <img src="/app/asset/img/junk.svg">
    Junks
</button>
<button>
    <img src="/app/asset/img/trash.svg">
    Trash
</button>

<div class="seperate"></div>


<button>
    <img src="/app/asset/img/today.svg">
    Today
</button>
<button>
    <img src="/app/asset/img/remindme.svg">
    Remind Me
</button>
<button>
    <img src="/app/asset/img/sendlater.svg">
    Send Later
</button>
<button>
    <img src="/app/asset/img/template.svg">
    Template
</button>
HTML;

$main_right = <<<'HTML'
  <div class="toolbar">
                <input type="checkbox">
                <div class="show">
                    <button><img src="/app/asset/img/inbox.svg">View</button>
                    <button><img src="/app/asset/img/inbox.svg">Sort by</button>
                </div>
                <div class="hide">
                    <button><img src="/app/asset/img/inbox.svg">Delete</button>
                    <button><img src="/app/asset/img/inbox.svg">Make Junk</button>
                    <button><img src="/app/asset/img/inbox.svg">Snooze</button>
                    <button><img src="/app/asset/img/inbox.svg">Mark as unread</button>
                    <button><img src="/app/asset/img/inbox.svg">Mark as read</button>
                    <button><img src="/app/asset/img/inbox.svg">Flag as</button>
                </div>
            </div>
            <div class="mail-date-set">Today</div>


            <div class="mail_split">

            <div class="mail_split_left">

<div class="mailbox">
    <div class="mailbox-left">
        <div class="mailbox-profile">D</div>
    </div>
    <div class="mailbox-middle">
        <div class="mailbox-middle-top"> <div class="mailbox-middle-top-name">Dhiraj Kadam</div><img src="/app/asset/img/flag.svg"><img src="/app/asset/img/star.svg"> </div>
        <div class="mailbox-middle-bottom"> <div class="mailbox-middle-bottom-subject">Dhiraj kadam official subject</div> <div class="mailbox-middle-bottom-email"> <img src="/get-started/confirmemail/outlook.svg"> Dhirajkadam.official@gmail.com</div></div>
    </div>
    <div class="mailbox-right">
        <div class="mailbox-right-top"><div class="mailbox-right-top-date">12 Jan</div> </div>
        <div class="mailbox-right-bottom"><div class="mailbox-right-bottom-count">New</div></div>
    </div>
</div>
<div class="mailbox">
    <div class="mailbox-left">
        <div class="mailbox-profile">D</div>
    </div>
    <div class="mailbox-middle">
        <div class="mailbox-middle-top"> <div class="mailbox-middle-top-name">Dhiraj Kadam</div><img src="/app/asset/img/flag.svg"><img src="/app/asset/img/star.svg"> </div>
        <div class="mailbox-middle-bottom"> <div class="mailbox-middle-bottom-subject">Dhiraj kadam official subject</div> <div class="mailbox-middle-bottom-email"> <img src="/get-started/confirmemail/gmail.svg"> Dhirajkadam.official@gmail.com</div></div>
    </div>
    <div class="mailbox-right">
        <div class="mailbox-right-top"><img src="/app/asset/img/attach.svg"><div class="mailbox-right-top-date">12 Jan</div> </div>
        <div class="mailbox-right-bottom"><div class="mailbox-right-bottom-count">New</div></div>
    </div>
</div>
<div class="mailbox">
    <div class="mailbox-left">
        <div class="mailbox-profile">D</div>
    </div>
    <div class="mailbox-middle">
        <div class="mailbox-middle-top"> <div class="mailbox-middle-top-name">Dhiraj Kadam</div><img src="/app/asset/img/flag.svg"><img src="/app/asset/img/star.svg"> </div>
        <div class="mailbox-middle-bottom"> <div class="mailbox-middle-bottom-subject">Dhiraj kadam official subject</div> <div class="mailbox-middle-bottom-email"> <img src="/get-started/confirmemail/outlook.svg"> Dhirajkadam.official@gmail.com</div></div>
    </div>
    <div class="mailbox-right">
        <div class="mailbox-right-top"><div class="mailbox-right-top-date">12 Jan</div> </div>
        <div class="mailbox-right-bottom"><div class="mailbox-right-bottom-count">New</div></div>
    </div>
</div>
<div class="mailbox">
    <div class="mailbox-left">
        <div class="mailbox-profile">D</div>
    </div>
    <div class="mailbox-middle">
        <div class="mailbox-middle-top"> <div class="mailbox-middle-top-name">Dhiraj Kadam</div><img src="/app/asset/img/flag.svg"><img src="/app/asset/img/star.svg"> </div>
        <div class="mailbox-middle-bottom"> <div class="mailbox-middle-bottom-subject">Dhiraj kadam official subject</div> <div class="mailbox-middle-bottom-email"> <img src="/get-started/confirmemail/gmail.svg"> Dhirajkadam.official@gmail.com</div></div>
    </div>
    <div class="mailbox-right">
        <div class="mailbox-right-top"><img src="/app/asset/img/attach.svg"><div class="mailbox-right-top-date">12 Jan</div> </div>
        <div class="mailbox-right-bottom"><div class="mailbox-right-bottom-count">New</div></div>
    </div>
</div>

</div>
<div class="mail_split_right">
    <div class="label">Subject</div>
    <input type="text" class="Subject">
    <!-- <textarea cols="30" rows="10"></textarea> -->
    <iframe src="./iframe.php"></iframe>
    <div class="bottom_email_functions">
        <button>Save</button>
    </div>
</div>

            </div>
         

            


HTML;


$style = <<<'CSS'
   .toolbar {
            display: flex;
            height: 35px;
            align-items: center;
            border-bottom: 1px solid lightgrey;
            padding: 0px 10px;
        }

        .toolbar input {
            width: 20px;
            margin-right: 10px;
        }

        .toolbar button {
            margin-right: 15px;
            font-size: 12px;
            font-weight: 500;
            border: none;
            background: none;
            padding: 3px 10px;
            border-radius: 3px;
            display: flex;
            align-items: center;
        }

        .toolbar button:hover {
            background: #f2f2f2;
        }

        .show {
            display: flex;
            align-items: center;
        }

        .toolbar button img {
            height: 12px;
            margin-right: 5px;
        }

        .hide {
            display: flex;
            align-items: center;
            display: none;
        }

        .mail-date-set {
            display: flex;
            background: #f2f2f2;
            padding: 5px 20px;
            font-size: 12px;
            font-weight: 500;
    border-bottom: 1px solid lightgrey;
        }

        .mailbox {
            width: 100%;
    height: 75px;
    display: flex;
    background: none;
    align-items: center;
    padding: 10px;
    border-bottom: 1px solid lightgrey;
    cursor: pointer;
}

.mailbox:hover{
    background: #f2f2f2;
}

.mailbox-left {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 60px;
}

.mailbox-profile {
    width: 35px;
    height: 35px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #8bbcff;
    border-radius: 100px;
}

.mailbox-middle {
    width: calc(100% - 200px);
}


.mailbox-middle-top {
    display: flex;
    align-items: center;
}

.mailbox-middle-top-name {
    font-size: 13px;
    font-weight: 500;
}

.mailbox-middle-top img {
    height: 15px;
    margin-left: 15px;
    display: none;
}

.mailbox:hover .mailbox-middle-top img {
    display: flex;
}


.mailbox-middle-bottom {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-top: 5px;
}

.mailbox-middle-bottom-subject {
    font-size: 13px;
    font-weight: 500;
}

.mailbox-middle-bottom-email {
    font-size: 12px;
    font-weight: 400;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #ffeadb;
    padding: 3px 10px;
    border-radius: 5px;
}
.mailbox-middle-bottom-email img {
    width: 15px;
    margin-right: 5px;
}

.mailbox-right-top {display: flex;align-items: center;}

.mailbox-right-bottom {
    background: #007aff;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #ffffff;
    font-size: 10px;
    border-radius: 5px;
    margin-left: auto;
    margin-top: 5px;
    width: fit-content;
    padding: 5px 4px;
}

.mailbox-right-top img {
    height: 15px;
    margin-right: 12px;
}

.mailbox-right-top-date {
    font-size: 13px;
    font-weight: 500;
    color: #007AFF;
}

.mailbox-right {
    text-align: right;
    display: block;
    margin-left: auto;
    margin-right: 10px;
}

.mail_split {
    display: flex;
    height: -webkit-fill-available;
}

.mail_split_left {
    width: 50%;
}

.mail_split_right {
    width: 50%;
    border-left: 1px solid lightgrey;
    padding:20px
}


.mail_split_right .label {font-size: 12px;font-weight: 400;}

.mail_split_right select {
    font-size: 15px;
    font-weight: 500;
    padding: 5px 15px;
    border: 1px solid #e1e1e1;
    border-radius: 5px;
    margin-bottom: 15px;
}

.mail_split_right input {
    width: 90%;
    font-size: 15px;
    font-weight: 500;
    padding: 5px 15px;
    border: 1px solid #e1e1e1;
    border-radius: 5px;
    margin-bottom: 15px;
}

.mail_split_right textarea {
    width: 90%;
    font-size: 15px;
    font-weight: 500;
    padding: 5px 15px;
    border: 1px solid #e1e1e1;
    border-radius: 5px;
    margin-bottom: 15px;
}

.mail_split_right iframe {
    width: 100%;
    height: -webkit-fill-available;
}

.bottom_email_functions {
    display: flex;
    align-items: center;
    padding-bottom: 15px;
}

.bottom_email_functions button {
    border: none;
    padding: 5px 20px;
    border-radius: 100px;
    background: #007aff;
    color: white;
}


CSS;
include '../../../../component/frame/index.php';
?>