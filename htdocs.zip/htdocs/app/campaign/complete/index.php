
<?php

$main_left_1 = "campaign";
$main_left_2 = <<<'HTML'
  <div class="main-left-2-title">Campaign</div>
            <button onclick="window.location.href='/app/campaign/'">
                <img src="/app/asset/img/inbox.svg">
                All
            </button>
            <button onclick="window.location.href='/app/campaign/ongoing'">
                <img src="/app/asset/img/star.svg">
                Ongoing
            </button>
            <button onclick="window.location.href='/app/campaign/draft'">
                <img src="/app/asset/img/flag.svg">
                Draft
            </button>
            <button onclick="window.location.href='/app/campaign/complete'" class="active">
                <img src="/app/asset/img/draft.svg">
                Complete
            </button>
HTML;

$main_right = <<<'HTML'
       <div class="toolbar">
                <input type="checkbox">
                <div class="show">
                    <button><img src="/app/asset/img/inbox.svg">View</button>
                    <button><img src="/app/asset/img/inbox.svg">Sort by</button>
                </div>
                <div class="hide">
                    <button><img src="/app/asset/img/inbox.svg">Delete</button>
                    <button><img src="/app/asset/img/inbox.svg">Make Junk</button>
                    <button><img src="/app/asset/img/inbox.svg">Snooze</button>
                    <button><img src="/app/asset/img/inbox.svg">Mark as unread</button>
                    <button><img src="/app/asset/img/inbox.svg">Mark as read</button>
                    <button><img src="/app/asset/img/inbox.svg">Flag as</button>
                </div>
            </div>
            <div class="mail-date-set">Today</div>
            
            <div class="campaignbox" onclick="window.location.href='/app/campaign/report/'">
                <div class="campaignbox-left">
                    <div class="campaignbox-left-top">
                        <div class="campaignbox-left-top-name">Campaign Name</div>
                        <div class="campaignbox-left-top-tag">Draft</div>
                    </div>
                    <div class="campaignbox-left-bottom">
                        <div class="campaignbox-left-bottom-date">Edited Sat, March 2nd 12:19 PM by you</div>
                    </div>
                </div>
                <div class="campaignbox-middle">
                    <div class="campaignbox-middle-box">
                        <div class="campaignbox-middle-box-num">10</div>
                        <div class="campaignbox-middle-box-name">Open</div>
                    </div>
                    <div class="campaignbox-middle-box">
                        <div class="campaignbox-middle-box-num">10</div>
                        <div class="campaignbox-middle-box-name">Click</div>
                    </div>
                    <div class="campaignbox-middle-box">
                        <div class="campaignbox-middle-box-num">10</div>
                        <div class="campaignbox-middle-box-name">Sent</div>
                    </div>
                </div>
                <div class="campaignbox-right">
                    <button>Continue</button>
                    <div class="campaignbox-right-email">dhirajkadam.official@gmail.com</div>
                </div>
            </div>
            <div class="campaignbox" onclick="window.location.href='/app/campaign/report/'">
                <div class="campaignbox-left">
                    <div class="campaignbox-left-top">
                        <div class="campaignbox-left-top-name">Campaign Name</div>
                        <div class="campaignbox-left-top-tag">Draft</div>
                    </div>
                    <div class="campaignbox-left-bottom">
                        <div class="campaignbox-left-bottom-date">Edited Sat, March 2nd 12:19 PM by you</div>
                    </div>
                </div>
                <div class="campaignbox-middle">
                    <div class="campaignbox-middle-box">
                        <div class="campaignbox-middle-box-num">10</div>
                        <div class="campaignbox-middle-box-name">Open</div>
                    </div>
                    <div class="campaignbox-middle-box">
                        <div class="campaignbox-middle-box-num">10</div>
                        <div class="campaignbox-middle-box-name">Click</div>
                    </div>
                    <div class="campaignbox-middle-box">
                        <div class="campaignbox-middle-box-num">10</div>
                        <div class="campaignbox-middle-box-name">Sent</div>
                    </div>
                </div>
                <div class="campaignbox-right">
                    <button>Continue</button>
                    <div class="campaignbox-right-email">dhirajkadam.official@gmail.com</div>
                </div>
            </div>
            <div class="campaignbox" onclick="window.location.href='/app/campaign/report/'">
                <div class="campaignbox-left">
                    <div class="campaignbox-left-top">
                        <div class="campaignbox-left-top-name">Campaign Name</div>
                        <div class="campaignbox-left-top-tag">Draft</div>
                    </div>
                    <div class="campaignbox-left-bottom">
                        <div class="campaignbox-left-bottom-date">Edited Sat, March 2nd 12:19 PM by you</div>
                    </div>
                </div>
                <div class="campaignbox-middle">
                    <div class="campaignbox-middle-box">
                        <div class="campaignbox-middle-box-num">10</div>
                        <div class="campaignbox-middle-box-name">Open</div>
                    </div>
                    <div class="campaignbox-middle-box">
                        <div class="campaignbox-middle-box-num">10</div>
                        <div class="campaignbox-middle-box-name">Click</div>
                    </div>
                    <div class="campaignbox-middle-box">
                        <div class="campaignbox-middle-box-num">10</div>
                        <div class="campaignbox-middle-box-name">Sent</div>
                    </div>
                </div>
                <div class="campaignbox-right">
                    <button>Continue</button>
                    <div class="campaignbox-right-email">dhirajkadam.official@gmail.com</div>
                </div>
            </div>
HTML;


$style = <<<'CSS'
 .toolbar {
            display: flex;
            height: 35px;
            align-items: center;
            border-bottom: 1px solid lightgrey;
            padding: 0px 10px;
        }

        .toolbar input {
            width: 20px;
            margin-right: 10px;
        }

        .toolbar button {
            margin-right: 15px;
            font-size: 12px;
            font-weight: 500;
            border: none;
            background: none;
            padding: 3px 10px;
            border-radius: 3px;
            display: flex;
            align-items: center;
        }

        .toolbar button:hover {
            background: #f2f2f2;
        }

        .show {
            display: flex;
            align-items: center;
        }

        .toolbar button img {
            height: 12px;
            margin-right: 5px;
        }

        .hide {
            display: flex;
            align-items: center;
            display: none;
        }

        .mail-date-set {
            display: flex;
            background: #f2f2f2;
            padding: 5px 20px;
            font-size: 12px;
            font-weight: 500;
    border-bottom: 1px solid lightgrey;
        }

        .campaignbox {
            width: calc(100% - 30px);
    height: 70px;
    display: flex;
    background: none;
    align-items: center;
    justify-content: space-between;
    padding: 10px 15px;

    border-bottom: 1px solid lightgrey;
    cursor: pointer;
}
.campaignbox:hover{
        background: whitesmoke;
}

.campaignbox-left {
    display: block;
}

.campaignbox-left-top {
    display: flex;
    align-items: center;
}

.campaignbox-left-top-name {
    font-size: 13px;
    font-weight: 500;
}

.campaignbox-left-top-tag {
    margin-left: 12px;
    font-size: 13px;
    font-weight: 500;
    background: #e0e0e0;
    padding: 2px 10px;
    border-radius: 3px;
}

.campaignbox-left-bottom {
    display: flex;
    align-items: center;
}

.campaignbox-left-bottom-date {
    font-size: 13px;
    font-weight: 500;
    margin-top: 15px;
}

.campaignbox-middle {
    display: flex;
    align-items: center;
}

.campaignbox-middle-box {
    text-align: center;
    margin: 0px 10px;
}

.campaignbox-middle-box-num {font-size: 20px;font-weight: 500;}

.campaignbox-middle-box-name {
    font-size: 10px;
    font-weight: 500;
    margin-top: 10px;
    color: #8d8d8d;
}

.campaignbox-right {text-align: right;}

.campaignbox-right button {
    padding: 5px 10px;
    border: none;
    font-size: 13px;
    font-weight: 500;
    background: #343434;
    border-radius: 5px;
    color: white;
}

.campaignbox-right-email {
    font-size: 12px;
    font-weight: 500;
    color: #007AFF;
    margin-top: 15px;
}
CSS;
include '../../component/frame/index.php';
?>
