<?php

$main_left_1 = "campaign";
$main_left_2 = <<<'HTML'
  <div class="main-left-2-title">Campaign</div>
            <button onclick="window.location.href='/app/campaign/'">
                <img src="/app/asset/img/inbox.svg">
                All
            </button>
            <button onclick="window.location.href='/app/campaign/ongoing'">
                <img src="/app/asset/img/star.svg">
                Ongoing
            </button>
            <button onclick="window.location.href='/app/campaign/draft'">
                <img src="/app/asset/img/flag.svg">
                Draft
            </button>
            <button onclick="window.location.href='/app/campaign/complete'">
                <img src="/app/asset/img/draft.svg">
                Complete
            </button>
HTML;

$main_right = <<<'HTML'
<div class="report_nav_title">Campaign name</div>
  <table class="report_table">
    <tr>
        <td>Campiagn URL</td>
        <td>https://mailchi.mp/f4fcb7a3556c/hello-world</td>
    </tr>
    <tr>
        <td>Delivery date & time</td>
        <td>Wed, Jan 10, 2024 12:34 pm</td>
    </tr>
    <tr>
      <td>From name</td>
      <td>ABC Inc.</td>
    </tr>
    <tr>
      <td>From email</td>
      <td>abc@axy.com</td>
    </tr>
    <tr>
      <td>Subject line</td>
      <td>Marketing mail</td>
    </tr>
    <tr>
      <td>Preview text</td>
      <td>Marketing mail</td>
    </tr>
    <tr>
      <td>Recipients</td>
      <td>10</td>
    </tr>
    <!-- <tr>
      <td>Deliveries</td>
      <td>10</td>
    </tr>
    <tr>
      <td>bounces</td>
      <td>10</td>
    </tr>
    <tr>
      <td>complaints</td>
      <td>10</td>
    </tr>
    <tr>
      <td>rejects</td>
      <td>10</td>
    </tr> -->
  </table>
  <div class="total_email_sent_number">16</div>
  <div class="total_email_sent_txt">Total Emails Sent</div>
  <div class="report_delivered_rate">100% Delivered</div>
  <div class="report_bar"><div class="report_bar_green"></div><div class="report_bar_red"></div><div class="report_bar_yellow"></div></div>
  <div class="report_bar_scales">
    <div class="report_bar_scale_box">
      <div class="report_bar_scale_box_color_green"></div>
      <div class="report_bar_scale_box_txts">
        <div class="report_bar_scale_box_txt1">Delievered 100%</div>
        <div class="report_bar_scale_box_txt2">16 contacts</div>
      </div>
    </div>
    <div class="report_bar_scale_box">
      <div class="report_bar_scale_box_color_bounce"></div>
      <div class="report_bar_scale_box_txts">
        <div class="report_bar_scale_box_txt1">Bounces 00%</div>
        <div class="report_bar_scale_box_txt2">0 contacts</div>
      </div>
    </div>
    <div class="report_bar_scale_box">
      <div class="report_bar_scale_box_color_unsent"></div>
      <div class="report_bar_scale_box_txts">
        <div class="report_bar_scale_box_txt1">Unsent 00%</div>
        <div class="report_bar_scale_box_txt2">0 contacts</div>
      </div>
    </div>
  </div>
HTML;


$style = <<<'CSS'
.report_nav_title {
    font-size: 20px;
    font-weight: 500;
    margin: 30px;
}
.report_table {
    border-collapse: collapse;
    width: calc(100% - 60px);
    margin: 30px;
    border:1px solid #ebebeb
}

.report_table tr:nth-child(even) {
  background-color: #f7f7f7;
}

.report_table td, th {
  text-align: left;
  padding: 15px 8px;
}

.total_email_sent_number {
    font-size: 25px;
    font-weight: 500;
    margin: 10px auto;
    text-align: center;
    margin-top: 50px;
}

.total_email_sent_txt {
    font-size: 13px;
    font-weight: 400;
    text-align: center;
}

.report_delivered_rate {
    width: 500px;
    margin: 10px auto;
    text-align: right;
    margin-top: 30px;
    font-size: 12px;
    font-weight: 500;
}

.report_bar {
    width: 500px;
    height: 40px;
    margin: 10px auto;
    border-radius: 5px;
    overflow: hidden;
    display: flex;
    align-items: center;
    margin-top: 30px;
}

.report_bar_green {
    width: 300px;
    height: 40px;
    background: #50b96b;
}

.report_bar_red {
    width: 100px;
    height: 40px;
    background: #ff5656;
}

.report_bar_yellow {
    width: 100px;
    height: 40px;
    background: #f0cc48;
}

.report_bar_scales {
    width: 500px;
    display: flex;
    justify-content: space-between;
    margin: 10px auto;
}

.report_bar_scale_box {
    display: flex;
}

.report_bar_scale_box_color_green {
    width: 25px;
    height: 25px;
    background: #50b96b;
    border-radius: 4px;
    margin-right: 10px;
}

.report_bar_scale_box_txt1 {
    font-size: 13px;
    font-weight: 400;
}

.report_bar_scale_box_txt2 {
    font-size: 13px;
    font-weight: 500;
}

.report_bar_scale_box_color_bounce {
    width: 25px;
    height: 25px;
    background: #ff5656;
    border-radius: 4px;
    margin-right: 10px;
}

.report_bar_scale_box_color_unsent {
    width: 25px;
    height: 25px;
    background: #f0cc48;
    border-radius: 4px;
    margin-right: 10px;
}

CSS;
include '../../component/frame/index.php';
?>
