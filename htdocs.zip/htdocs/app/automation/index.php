
<?php

$main_left_1 = "automation";
$main_left_2 = <<<'HTML'
  <div class="main-left-2-title">Automations</div>
HTML;

$main_right = <<<'HTML'
<div class="coming_soon">Coming soon</div>
HTML;


$style = <<<'CSS'
 .coming_soon {
    display: block;
    text-align: center;
    margin-top: 100px;
    font-size: 30px;
}

CSS;
include '../component/frame/index.php';
?>