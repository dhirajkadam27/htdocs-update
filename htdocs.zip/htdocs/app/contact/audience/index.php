
<?php

$main_left_1 = "contact";
$main_left_2 = <<<'HTML'
     <div class="main-left-2-title">Contact</div>
            <button onclick="window.location.href='/app/contact/'">
                <img src="/app/asset/img/inbox.svg">
                All
            </button>
            <button onclick="window.location.href='/app/contact/audience'" class="active">
                <img src="/app/asset/img/star.svg">
                Audience
            </button>
            <button onclick="window.location.href='/app/contact/tags'">
                <img src="/app/asset/img/flag.svg">
                Tags
            </button>
HTML;

$main_right = <<<'HTML'
    <div class="toolbar">
                <input type="checkbox">
                <div class="show">
                    <button><img src="/app/asset/img/inbox.svg">View</button>
                    <button><img src="/app/asset/img/inbox.svg">Sort by</button>
                </div>
                <div class="hide">
                    <button><img src="/app/asset/img/inbox.svg">Delete</button>
                    <button><img src="/app/asset/img/inbox.svg">Make Junk</button>
                    <button><img src="/app/asset/img/inbox.svg">Snooze</button>
                    <button><img src="/app/asset/img/inbox.svg">Mark as unread</button>
                    <button><img src="/app/asset/img/inbox.svg">Mark as read</button>
                    <button><img src="/app/asset/img/inbox.svg">Flag as</button>
                </div>
            </div>
            <div class="mail-date-set">Today</div>

            <div class="audiencebox">
                <div class="audiencebox_txt">Adult Audience</div>
                <div class="audiencebox_contacts">Contacts: 1</div>
            </div>
            <div class="audiencebox">
                <div class="audiencebox_txt">Adult Audience</div>
                <div class="audiencebox_contacts">Contacts: 1</div>
            </div>
            <div class="audiencebox">
                <div class="audiencebox_txt">Adult Audience</div>
                <div class="audiencebox_contacts">Contacts: 1</div>
            </div>
HTML;


$style = <<<'CSS'
 .toolbar {
            display: flex;
            height: 35px;
            align-items: center;
            border-bottom: 1px solid lightgrey;
            padding: 0px 10px;
        }

        .toolbar input {
            width: 20px;
            margin-right: 10px;
        }

        .toolbar button {
            margin-right: 15px;
            font-size: 12px;
            font-weight: 500;
            border: none;
            background: none;
            padding: 3px 10px;
            border-radius: 3px;
            display: flex;
            align-items: center;
        }

        .toolbar button:hover {
            background: #f2f2f2;
        }

        .show {
            display: flex;
            align-items: center;
        }

        .toolbar button img {
            height: 12px;
            margin-right: 5px;
        }

        .hide {
            display: flex;
            align-items: center;
            display: none;
        }

        .mail-date-set {
            display: flex;
            background: #f2f2f2;
            padding: 5px 20px;
            font-size: 12px;
            font-weight: 500;
    border-bottom: 1px solid lightgrey;
        }

        .audiencebox {
    width: calc(100% - 20px);
    height: 50px;
    display: flex;
    background: none;
    align-items: center;
    padding: 10px;
    border-bottom: 1px solid lightgrey;
    cursor: pointer;
}
.audiencebox:hover{
    background: #f2f2f2;
}

.audiencebox_txt {
    font-size: 15px;
    font-weight: 500;
    margin-right: 20px;
    margin-left: 30px;
    color: #007aff;
    text-decoration: underline;
}

.audiencebox_contacts {
    font-size: 13px;
    font-weight: 400;
    margin-left: 30px;
}
CSS;
include '../../component/frame/index.php';
?>
