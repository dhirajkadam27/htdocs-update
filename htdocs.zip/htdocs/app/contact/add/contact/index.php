
<?php

$main_left_1 = "contact";
$main_left_2 = <<<'HTML'
     <div class="main-left-2-title">Contact</div>
            <button onclick="window.location.href='/app/contact/'" class="active">
                <img src="/app/asset/img/inbox.svg">
                All
            </button>
            <button onclick="window.location.href='/app/contact/audience'">
                <img src="/app/asset/img/star.svg">
                Audience
            </button>
            <button onclick="window.location.href='/app/contact/tags'">
                <img src="/app/asset/img/flag.svg">
                Tags
            </button>
HTML;

$main_right = <<<'HTML'
<div class="add_contact_title">Add Contact</div>
<div class="add_contact_contents">
    <label>Email Address</label>
    <input type="text">
    <label>First Name</label>
    <input type="text">
    <label>Last Name</label>
    <input type="text">
    <label>Phone Number</label>
    <input type="text">
    <label>Add Audience</label>
    <input
    type="text"
    multiple
    class="tagsInput"
    data-user-option-allowed="true"
    data-url="json.php"
    data-load-once="true"
    name="language"/>
    <label>Add Tags</label>
    <input
    type="text"
    multiple
    class="tagsInput"
    data-user-option-allowed="true"
    data-url="json.php"
    data-load-once="true"
    name="language"/>
    <button>Add</button>
</div>
<script>

    // .fstUserOption
                $('.tagsInput').fastselect();
            </script>
HTML;


$style = <<<'CSS'
.main-right {
    padding: 15px 20px;
}
.add_contact_title {
    font-size: 25px;
    font-weight: 500;
    margin-bottom: 30px;
}

.add_contact_contents {
    display: block;
}

.add_contact_contents label {
    display: block;
    font-size: 15px;
    font-weight: 400;
    margin-bottom: 5px;
}

.add_contact_contents input {
    width: 400px;
    font-size: 15px;
    font-weight: 500;
    padding: 5px 15px;
    border: 1px solid #e1e1e1;
    border-radius: 5px;
    margin-bottom: 15px;
}

.add_contact_contents button {
    display: block;
    margin-top: 15px;
    border: none;
    padding: 5px 20px;
    border-radius: 100px;
    background: #007aff;
    color: white;
}
input.fstQueryInput.fstQueryInputExpanded {
    font-size: 12px;
}
span.fstResultItem {
    font-size: 15px;
}
p.fstNoResults {
    font-size: 15px;
}

CSS;
include '../../../component/frame/index.php';
?>
