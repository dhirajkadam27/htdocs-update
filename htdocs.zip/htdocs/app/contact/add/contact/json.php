<?php
header('Content-Type: application/json');

echo '[
	{"text": "Afghanistan", "value": "aa"},
	{"text": "Albania", "value": "Albania"},
	{"text": "Algeria", "value": "Algeria"},
	{"text": "Angola", "value": "Angola"}
]'
?>