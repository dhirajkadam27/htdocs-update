<?php
session_start();

include 'config.php';

if(isset($_SESSION['userid'])){
    $userid = $_SESSION['userid'];
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle.work</title>

    <!-- outfit font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&display=swap" rel="stylesheet">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


    <style>
        :root {
            --orange-color: #FF6B00;
            --black-color: #1c1c1c;
            --white-button-hover: #e0e0e0;
            --orange-button-hover: #ff7b1c;
            --grey-color: rgb(135, 135, 135);
            --light-grey-color: rgb(165, 165, 165);
            --font-weight: 600;
            --font-size: 18px;
        }

        button {
            font-family: "Outfit", sans-serif;
            font-weight: var(--font-weight);
            font-size: var(--font-size);
            font-style: normal;
            color: var(--black-color);
            cursor: pointer;
        }

        input{
    font-size: 15px;
    font-weight: 400 !important;
    color: var(--black-color);
    font-family: "Outfit", sans-serif;
            font-size: var(--font-size);
            font-style: normal;
}
input::placeholder{
    color: #919191;
    font-weight: 400 !important;
}

        body {
            margin: 0;
            padding: 0;
            font-family: "Outfit", sans-serif;
            font-optical-sizing: auto;
            font-weight: var(--font-weight);
            font-size: var(--font-size);
            font-style: normal;
            color: var(--black-color);
        }

.nav{
    display: flex;
    align-items: center;
    justify-content: end;
}
.profile {
    border: none;
    background: none;
    margin: 30px;
}

.profile .icon {
    width: 40px;
    height: 40px;
    background: #FF6B00;
    border-radius: 5px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    color: white;
    font-weight: 500;
}

.title {
    width: 400px;
    font-size: 20px;
    font-weight: 500;
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 10px auto;
    margin-bottom: 30px;
}

.title button {
    padding: 7px 20px;
    border: none;
    background: var(--orange-color);
    border-radius: 5px;
    font-size: 14px;
    font-weight: 400;
    color: white;
    display: flex;
    align-items: center;
}
.title button img {
    height: 11px;
    margin-right: 8px;
}
.workspace {
    width: 400px;
    display: flex;
    margin: 20px auto;
    align-items: center;
    border: 1px solid #eaeaea;
    border-radius: 10px;
    cursor: pointer;
}
.workspace:hover{
    background: #fafafa;
}

.workspace .left {
    width: 80px;
    height: 80px;
    display: flex;
    align-items: center;
    justify-content: center;
}
.workspace .left .icon {
    width: 50px;
    height: 50px;
    background: #FF6B00;
    border-radius: 5px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    color: white;
    font-weight: 500;
}

.workspace .top {
    font-size: 15px;
    font-weight: 500;
}

.workspace .bottom {
    font-size: 13px;
    font-weight: 400;
    margin-top: 5px;
    color: #999999;
}

.workspace .right {
    margin-left: auto;
}

.workspace .right img {
    margin: 20px;
    height: 20px;
}


.dropdown-profile {
    display: flex;
    align-items: center;
}

.dropdown-profile .icon {
    width: 40px;
    height: 40px;
    background: #FF6B00;
    border-radius: 5px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    color: white;
    font-weight: 500;
    margin: 10px 15px;
}

.dropdown-profile-info .name {
    font-size: 15px;
    font-weight: 500;
}

.dropdown-profile-info .workspaces{
    font-size: 13px;
    font-weight: 400;
    margin-top: 5px;
    color: #999999;
}

.dropdown-profile-info .workspace {
    font-size: 15px;
    font-weight: 500;
}

ul.dropdown-menu.show {
    width: 260px;
}

h5.offcanvas-title {
    font-size: 18px;
    font-weight: 500;
}

.offcanvas-header button {
    font-size: 15px;
}

.offcanvas-photo {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 25px;
}

.offcanvas-photo .icon {
    width: 150px;
    height: 150px;
    background: #FF6B00;
    border-radius: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 50px;
    color: white;
    font-weight: 500;
}

.offcanvas-flex {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 10px 20px;
}
.offcanvas-name {
    font-size: 15px;
    font-weight: 600;
}

.offcanvas-flex button {
    border: none;
    background: white;
    font-size: 15px;
    color: #1264a3;
}

.offcanvas-seperate {
    width: 100%;
    height: 0.4px;
    margin: 25px auto;
    background: #dadada;
}

.offcanvas-flex-title {
    font-size: 12px;
    font-weight: 500;
}

.offcanvas-email {
    display: flex;
    align-items: center;
    border: 1px solid #eaeaea;
    border-radius: 10px;
    margin: 10px 20px;
    cursor: pointer;
}
.offcanvas-email:hover{
    background: #fafafa;
}
.offcanvas-email-space {
    margin-top: 25px;
}

.offcanvas-email img {
    height: 30px;
    margin: 20px;
}

.offcanvas-address {
    font-size: 15px;
    font-weight: 500;
}
.offcanvas .workspace{
    width: auto;
    margin: 10px 20px;
}
div#offcanvasprofile {
    border: none;
}

.offcanvas-body {
    padding: 0;
}
    </style>
</head>

<body>
    <div class="nav">
    <div class="dropdown">
      <button class="profile" data-bs-toggle="dropdown">
                <div class="icon">D</div>
            </button>
            <ul class="dropdown-menu">
                <div class="dropdown-profile">
                    <div class="icon">D</div>
                    <div class="dropdown-profile-info">
                        <div class="name">Dhiraj Kadam</div>
                        <div class="workspaces">2 Workspaces</div>
                    </div>
                </div>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" data-bs-toggle="offcanvas" href="#offcanvasprofile">Profile</a></li>
                <li><a class="dropdown-item" data-bs-toggle="offcanvas" href="#offcanvasemail">Emails</a></li>
                <li><a class="dropdown-item" data-bs-toggle="offcanvas" href="#offcanvasworkspace">Workspaces</a></li>
                <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="#">Sign Out</a></li>
            </ul>
          </div>
    </div>
      
      <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasprofile">
        <div class="offcanvas-header">
          <h5 class="offcanvas-title">Profile</h5>
          <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <div class="offcanvas-photo">
                <div class="icon">D</div>
            </div>
            <div class="offcanvas-flex">
                <div class="offcanvas-name">Dhiraj Kadam</div>
                <button>Edit</button>
            </div>
            <div class="offcanvas-seperate"></div>
            <div class="offcanvas-flex">
                <div class="offcanvas-flex-title">Your emails</div>
                <button>Add</button>
            </div>
            <div class="offcanvas-email-space"></div>
            <div class="offcanvas-email"><img src="../get-started/confirmemail/gmail.svg"> <div class="offcanvas-address">dhirajkadam@gmail.com</div></div>
            <div class="offcanvas-email"><img src="../get-started/confirmemail/gmail.svg"> <div class="offcanvas-address">dhirajkadam@gmail.com</div></div>
            <div class="offcanvas-seperate"></div>
            <div class="offcanvas-flex">
                <div class="offcanvas-flex-title">Your Workspaces</div>
                <button>Add</button>
            </div>
            <div class="workspace">
                <div class="left">
                    <div class="icon">W</div>
                </div>
                <div class="middle">
                    <div class="top">Workspace name</div>
                    <div class="bottom">2 members</div>
                </div>
                <div class="right">
                    <img src="./next.svg">
                </div>
             </div>
             <div class="workspace">
                <div class="left">
                    <div class="icon">W</div>
                </div>
                <div class="middle">
                    <div class="top">Workspace name</div>
                    <div class="bottom">2 members</div>
                </div>
                <div class="right">
                    <img src="./next.svg">
                </div>
             </div>
        </div>
      </div>

      <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasemail">
        <div class="offcanvas-header">
          <h5 class="offcanvas-title">Emails</h5>
          <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <div class="offcanvas-flex">
                <div class="offcanvas-flex-title">Your emails</div>
                <button>Add</button>
            </div>
            <div class="offcanvas-email-space"></div>
            <div class="offcanvas-email"><img src="../get-started/confirmemail/gmail.svg"> <div class="offcanvas-address">dhirajkadam@gmail.com</div></div>
            <div class="offcanvas-email"><img src="../get-started/confirmemail/gmail.svg"> <div class="offcanvas-address">dhirajkadam@gmail.com</div></div>
        </div>
      </div>

      <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasworkspace">
        <div class="offcanvas-header">
          <h5 class="offcanvas-title">Workspaces</h5>
          <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <div class="offcanvas-flex">
                <div class="offcanvas-flex-title">Your Workspaces</div>
                <button>Add</button>
            </div>
            <div class="workspace">
                <div class="left">
                    <div class="icon">W</div>
                </div>
                <div class="middle">
                    <div class="top">Workspace name</div>
                    <div class="bottom">2 members</div>
                </div>
                <div class="right">
                    <img src="./next.svg">
                </div>
             </div>
             <div class="workspace">
                <div class="left">
                    <div class="icon">W</div>
                </div>
                <div class="middle">
                    <div class="top">Workspace name</div>
                    <div class="bottom">2 members</div>
                </div>
                <div class="right">
                    <img src="./next.svg">
                </div>
             </div>
        </div>
      </div>



 <div class="title"> <div class="txt">Open a workspace</div> <button onclick="window.location.href='/get-started/createworkspace/'"> <img src="./add.svg"> Create</button></div>

<?php

$query = "SELECT * FROM workspaceuser WHERE userid = '$userid'";
$result = mysqli_query($connection, $query);

if(mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $workspaceid = $row['workspaceid'];
        $name_query = "SELECT * FROM workspace WHERE workspaceid = '$workspaceid'";
$name_result = mysqli_query($connection, $name_query);
if(mysqli_num_rows($name_result) > 0) {
    while ($name_row = mysqli_fetch_assoc($name_result)) {
        
        echo ' <div class="workspace">
        <div class="left">
            <div class="icon">'.$name_row['name'][0].'</div>
        </div>
        <div class="middle">
            <div class="top">'.$name_row['name'].'</div>
            <div class="bottom">2 members</div>
        </div>
        <div class="right">
            <img src="./next.svg">
        </div>
     </div>';
    }
}else{

    }


    }
}else{
    echo "Not Workspace created";
}

?>

</body>

</html>