<?php


// Include database connection
include '../config.php';

if(isset($_GET['token'])){
    $token = $_GET['token'];

      // Query the database to fetch email and user ID associated with the token
      $query = "SELECT * FROM emailverificationtoken WHERE token = '$token'"; // Modify the query as per your database schema
      $result = mysqli_query($connection, $query);
  
      if ($result && mysqli_num_rows($result) > 0) {
          // Token found, fetch email and user ID
          $row = mysqli_fetch_assoc($result);
          $email = $row['email'];
  
      } else {
        header("Location: ../");
         exit; // Make sure to stop executing the script after the redirect
      }

}else{
    header("Location: ../");
exit; // Make sure to stop executing the script after the redirect
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle.work</title>

    <!-- outfit font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&display=swap" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <title>Bootstrap Example</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


    <style>
        :root {
            --orange-color: #FF6B00;
            --black-color: #1c1c1c;
            --white-button-hover: #e0e0e0;
            --orange-button-hover: #ff7b1c;
            --grey-color: rgb(135, 135, 135);
            --light-grey-color: rgb(165, 165, 165);
            --font-weight: 600;
            --font-size: 18px;
        }

        button {
            font-family: "Outfit", sans-serif;
            font-weight: var(--font-weight);
            font-size: var(--font-size);
            font-style: normal;
            color: var(--black-color);
            cursor: pointer;
        }

        input{
    font-size: 15px;
    font-weight: 400 !important;
    color: var(--black-color);
    font-family: "Outfit", sans-serif;
            font-size: var(--font-size);
            font-style: normal;
}
input::placeholder{
    color: #919191;
    font-weight: 400 !important;
}

        body {
            margin: 0;
            padding: 0;
            font-family: "Outfit", sans-serif;
            font-optical-sizing: auto;
            font-weight: var(--font-weight);
            font-size: var(--font-size);
            font-style: normal;
            color: var(--black-color);
        }

        .logo {
            font-size: 30px;
            font-weight: 800;
            margin-top: 80px;
            text-align: center;
        }


        .title {
    font-size: 35px;
    text-align: center;
    margin-top: 30px;
}

.subtitle {
    font-size: 18px;
    font-weight: 400;
    text-align: center;
    margin-top: 10px;
    width: 40%;
    display: block;
    margin: 10px auto;
}


input[type="text"] {
    display: block;
    margin: 15px auto;
    width: 300px;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #919191;
    margin-top: 40px;
}


button {
    width: 320px;
    padding: 10px 25px;
    border: none;
    background: var(--orange-color);
    border-radius: 5px;
    font-size: 15px;
    font-weight: 600;
    color: white;
    display: block;
    margin: 10px auto;
}
button:disabled{
    filter: brightness(0.8);
}

.mail-btn {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 400px;
    margin: 0px auto;
    margin-top: 35px;
}

.mail-btn button {
    display: flex;
    width: max-content;
    font-size: 13px;
    font-weight: 400;
    padding: 10px;
    background: none;
    color: var(--black-color);
}

.mail-btn button img {
    width: 25px;
    margin-right: 10px;
}
.line-1 {
    font-size: 15px;
    font-weight: 400;
    text-align: center;
    margin-top: 50px;
}


footer {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 60px;
    margin-top: 100px;
}

.footer-links {
    display: flex;
    align-items: center;
}

.footer-links a {
    text-decoration: none;
    color: var(--black-color);
    font-size: 15px;
    font-weight: 400;
    margin-left: 20px;
}


.modal-content {
    border: none;
}

.modal-nav {
    display: flex;
    align-items: center;
    justify-content: end;
}

.modal-nav button {
    margin: 20px;
}

.modal-title {
    font-size: 15px;
    font-weight: 400;
    text-align: center;
    width: 80%;
    margin: 10px auto;
}

.modal-img {
    display: flex;
    align-items: center;
    justify-content: center;
}

.modal-img img {
    height: 30px;
    margin: 15px 20px;
    margin-bottom: 40px;
}

    </style>
</head>

<body>

<button id="errorpopupbtn" style="display: none;" type="button" data-bs-toggle="modal" data-bs-target="#errorpopup" >emailpopup</button>


        <div class="logo">Toggle</div>
        <div class="title">Check your email for a code</div>
        <div class="subtitle">We’ve sent a 6-character code to <b><?php echo $email ?></b>. The code expires shortly, so please enter it soon.</div>
        <input id="code" type="text" onkeyup="checkcode(this)" maxlength="6 placeholder="ABCDEF" name="email">
        <button id="codebutton" onclick="sendcode()" disabled>Continue</button>
        <div class="mail-btn">
            <button><img src="./gmail.svg"> Open Gmail</button>
            <button><img src="./outlook.svg"> Open Outlook</button>
        </div>
        <div class="line-1">Can’t find your code? Check your spam folder!</div>
        <footer>
            <div class="footer-links">
                <a href="#">Privacy</a>
                <a href="#">Terms</a>
            </div>
        </footer>

        <div class="modal fade" id="errorpopup" tabindex="-1" style="display: none;">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-nav">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div id="errorpopuptxt" class="modal-title">...</div>
            <div class="modal-img">
                <img src="../error.png">
            </div>
          </div>
        </div>
      </div>


      <script>

function checkcode(div){
            var codebutton = document.getElementById('codebutton');
    if(div.value.length==6){
        codebutton.removeAttribute("disabled");
    }else{
        codebutton.setAttribute("disabled", "disabled");
    }
}

function sendcode() {

    var errorpopup = document.getElementById('errorpopupbtn');
    var errorpopuptxt = document.getElementById('errorpopuptxt');
    var code = document.getElementById('code').value;

fetch('./api.php', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
  },
  body: JSON.stringify({ token: '<?php echo $token ?>', code: code}),
})
.then(response => {
  if (!response.ok) {
    throw new Error('Network response was not ok');
    errorpopuptxt.innerHTML = "Oops! Something went wrong with the network response.";
    errorpopup.click();
  }
  return response.json();
})
.then(data => {
  console.log('Response:', data);
  if(data.status=="error"){
    errorpopuptxt.innerHTML = data.message;
    errorpopup.click();
  }else{
    if(data.status=="wrong"){
    errorpopuptxt.innerHTML = data.message;
    errorpopup.click();
    }else{
        window.location.href = "../../workspace/";
    }
  }
})
.catch(error => {
  console.error('There was a problem with the fetch operation:', error);
    errorpopuptxt.innerHTML = "Uh oh! We encountered an issue with the fetch operation.";
    errorpopup.click();
});

}

      </script>

</body>

</html>