<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "toggle";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$userid = $_SESSION['userid'];
$firstname = "";
$lastname = "";
$username = "";
$email = "";
$user_sql = "SELECT firstname, lastname,email,username FROM user WHERE userid='$userid'";
$user_result = $conn->query($user_sql);

if ($user_result->num_rows > 0) {
    // output data of each row
        while ($user_row = $user_result->fetch_assoc()) {
          $firstname = $user_row['firstname'];
          $lastname = $user_row['lastname'];
          $username = $user_row['username'];
          $email = $user_row['email'];
        }
      }else{
        echo "user not found";
      }

      
$recordid = $_SESSION['recordid'];

      $users_sql = "SELECT role, status FROM users WHERE recordid='$recordid'";
$users_result = $conn->query($users_sql);

if ($users_result->num_rows > 0) {
    // output data of each row
        while ($users_row = $users_result->fetch_assoc()) {
          $role = $users_row['role'];
          $status = $users_row['status'];
        }
      }else{
        echo "record not found";
      }

      $companyid = $_SESSION['companyid'];

      $company_sql = "SELECT name,phone FROM company WHERE companyid='$companyid'";
$company_result = $conn->query($company_sql);

if ($company_result->num_rows > 0) {
    // output data of each row
        while ($company_row = $company_result->fetch_assoc()) {
          $companyname = $company_row['name'];
          $companyphone = $company_row['phone'];
        }
      }else{
        echo "company not found";
      }
?>

<div class="nav">
        <div class="logo">Toggle</div>
        <div class="nav_dropdown" data-bs-toggle="dropdown">
        <button>
            <div class="left">
                <div class="name"><?php echo $firstname." ".$lastname; ?></div>
                <div class="subdata"><?php echo $role; ?> &nbsp; &middot; &nbsp; <?php echo $companyname; ?></div>
            </div>
            <i class="bi bi-arrow-down-short"></i>
        </button>
        <ul class="dropdown-menu">
            <li><a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#switchcompany">Switch Company</a></li>
            <li><a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#addcompany">Add New Company</a></li>
            <li><a class="dropdown-item" onclick="window.location.href='/new/app/account/'">Settings</a></li>
            <li><a class="dropdown-item" href="#">Sign out</a></li>
          </ul>
        </div>

    </div>

  
  <!-- Modal -->
  <div class="modal fade" id="switchcompany" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="header">
            <div class="title">Switch company</div>
            <button data-bs-dismiss="modal"><i class="bi bi-x-lg"></i></button>
        </div>

        <div class="page_btns">
            <button onclick="window.location.href='./add'">
                <div class="page_btn_title">Grey</div>
                <div class="page_btn_subtitle">Owner</div>
            </button>
            
            <button onclick="window.location.href='./paste'">
                <div class="page_btn_title">Aadharpay</div>
                <div class="page_btn_subtitle">Manager</div>
            </button>
  
      
        </div>

      </div>
    </div>
  </div>

    
  <!-- Modal -->
  <div class="modal fade" id="addcompany" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="header">
            <div class="title">Add company</div>
            <button data-bs-dismiss="modal"><i class="bi bi-x-lg"></i></button>
        </div>

      
        <div class="modal_form">
          <label>Company name</label>
          <input type="text">
          <button><span class="material-symbols-outlined">lock</span>Create now</button>
  
        </div>
    

      </div>
    </div>
  </div>