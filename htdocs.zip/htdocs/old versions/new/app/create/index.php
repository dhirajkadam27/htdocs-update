<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle | Email Marketing Software</title>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,300,0,0" />


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">


<link rel="stylesheet" href="../components/nav/index.css">
<link rel="stylesheet" href="../components/menu/index.css">

    <style>
        body{
            margin: 0;
            padding: 0;
            font-family: "Outfit", sans-serif;
            font-optical-sizing: auto;
            font-weight: 400;
            font-style: normal;
            color: #1c1c1c;
        }


button {
    border: none;
    font-family: "Outfit", sans-serif;
    background: #f8f5f2;
    font-size: 15px;
    font-weight: 500;
    cursor: pointer;
}

.menu button:nth-child(1){
    background-color: #0a80800a;
    border-right: 3px solid #0a8080;
    color: #0a8080;
}

.main {
    display: flex;
    height: calc(100vh - 80px);
    margin-top: 80px;
}
.page{
    width: calc(100% - 300px);
    overflow: scroll;
    padding: 40px 40px;
}


.page_title {
    font-size: 32px;
    font-weight: 500;
}

.page_subtitle {
    font-size: 16px;
    font-weight: 400;
    color: #525257;
    margin-bottom: 30px;
}

.page_btns {
    display: flex;
    width: 100%;
    flex-wrap: wrap;
}

.page_btns button {
    border: 1px solid #dcdcdc;
    border-radius: 4px;
    box-shadow: 0 0 2px rgba(28,28,28,.1), 0 4px 6px rgba(28,28,28,.04), 0 8px 16px rgba(28,28,28,.04), 0 10px 20px 2px rgba(28,28,28,.02);
    background: white;
    margin-right: 40px;
    margin-bottom: 50px;
}
.page_btns button:hover{
    border: 1px solid #0a8080;
}

.page_btns button img {width: 300px;height: 200px;}

.page_btns button .page_btn_title {
    padding: 10px 0px;
}




    </style>
</head>
<body>
<?php
  include '../components/nav/index.php';
?>
    <div class="main">
        <?php
        include '../components/menu/index.html';
      ?>
    <div class="page">

        <div class="page_title">Create something new</div>
        <div class="page_subtitle">Add a contact, build an email from a template, or try something brand new.</div>
    
        <div class="page_btns">
            <button data-bs-toggle="modal" data-bs-target="#createcampaign">
                <img src="https://cdn-images.mailchimp.com/product/front-door/redesign/recommendations-email.png">
                <div class="page_btn_title">Create New Campaign</div>
            </button>
            
            <button onclick="window.location.href='http://localhost/new/app/create/automation/name'">
                <img src="https://cdn-images.mailchimp.com/product/front-door/redesign/recommendations-automation.png">
                <div class="page_btn_title">Create New Automation</div>
            </button>
            
            <button onclick="window.location.href='http://localhost/new/app/create/contacts'">
                <img src="https://static.ctctcdn.com/asset/d323ddd9f0ce0be27c9b.png">
                <div class="page_btn_title">Create New Contacts</div>
            </button>
        
            
            <button onclick="window.location.href='http://localhost/new/app/create/email/templates'">
                <img src="https://digitalasset.intuit.com/render/content/dam/intuit/mc-fe/en_us/images/language-agnostic-assets/in-app-pages/create/automations/customerJourneys.png">
                <div class="page_btn_title">Create New Template</div>
            </button>
        </div>

    </div>
 
    </div>

      <!-- Modal -->
  <div class="modal fade" id="createcampaign" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="header">
            <div class="title">Create Campaign</div>
            <button data-bs-dismiss="modal"><i class="bi bi-x-lg"></i></button>
        </div>

      
        <div class="modal_form">
          <label>Campaign name</label>
          <form id="createcampaignform" action="./email/create.php" method="POST">
          <input type="text" name="name" required>
          <button><span class="material-symbols-outlined">lock</span>Create now</button>
          </form>
        </div>
    

      </div>
    </div>
  </div>

  <script>
    document.getElementById("createcampaignform").addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent the form from submitting traditionally

        var formData = new FormData(this); // Get the form data

        // Create a new XMLHttpRequest object
        var xhr = new XMLHttpRequest();

        // Configure the request
        xhr.open("POST", "./email/create.php", true);

        // Set up a handler for when the request finishes
        xhr.onload = function() {
            if (xhr.status >= 200 && xhr.status < 300) {
                // Request was successful
                window.location.href='http://localhost/new/app/create/email?id='+xhr.responseText;
            } else {
                // Request failed
                console.error(xhr.statusText);
            }
        };

        // Set up a handler for network errors
        xhr.onerror = function() {
            console.error("Request failed");
        };

        // Send the request
        xhr.send(formData);
    });
</script>

</body>
</html>