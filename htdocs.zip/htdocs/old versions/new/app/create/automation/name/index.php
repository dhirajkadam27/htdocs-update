<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle | Email Marketing Software</title>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,300,0,0" />


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">


<link rel="stylesheet" href="../../../components/nav/index.css">
<link rel="stylesheet" href="../../../components/menu/index.css">


    <style>
        body{
            margin: 0;
            padding: 0;
            font-family: "Outfit", sans-serif;
            font-optical-sizing: auto;
            font-weight: 400;
            font-style: normal;
            color: #1c1c1c;
        }


button {
    border: none;
    font-family: "Outfit", sans-serif;
    background: #f8f5f2;
    font-size: 15px;
    font-weight: 500;
    cursor: pointer;
}


.menu button:nth-child(1){
    background-color: #0a80800a;
    border-right: 3px solid #0a8080;
    color: #0a8080;
}

.main {
    display: flex;
    height: calc(100vh - 80px);
    margin-top: 80px;
}
.page{
    width: calc(100% - 300px);
    overflow: scroll;
    padding: 40px 40px;
}

.page img {
    width: 100px;
    margin: 20px auto;
    display: block;
}

.page_title {
    font-size: 32px;
    font-weight: 500;
    text-align: center;
    width: 500px;
    margin: 10px auto;
}

.page_subtitle {
    font-size: 16px;
    font-weight: 400;
    color: #525257;
    width: 500px;
    margin: 10px auto;
    text-align: center;
}

.name_container {
    display: block;
    width: 500px;
    box-shadow: 0 4px 25px rgba(0,0,0,.1);
    border: 1px solid #dcdcdc;
    padding: 50px 40px;
    background: white;
    margin: 10px auto;
    margin-top: 30px;
}

.name_container label {
    display: block;
    font-size: 15px;
    font-weight: 500;
    margin-bottom: 5px;
}

.name_container input {
    background: #f4f4f3;
    font-size: 18px;
    font-weight: 400;
    width: calc(100% - 30px);
    font-family: "Outfit", sans-serif;
    padding: 7px 15px;
    border-radius: 5px;
    border: 1px solid #e5e5e5;
    outline-color: #0a8080;
}

.name_container button {
    background: #0a8080;
    color: white;
    padding: 10px 15px;
    width: 60%;
    margin: 10px auto;
    margin-top: 20px;
    border-radius: 5px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 17px;
    font-weight: 500;
}


button.page_back {
    background: none;
    margin-bottom: 20px;
    font-size: 20px;
    display: flex;
    justify-content: center;
    color: #525257;
}

button.page_back i {
    margin-right: 10px;
}


    </style>
</head>
<body>
    <?php
  include '../../../components/nav/index.php';
?>
    <div class="main">
        <?php
        include '../../../components/menu/index.html';
      ?>


    <div class="page">

    
    <button onclick="history.back()" class="page_back"><i class="bi bi-arrow-left"></i>back</button>

        <img src="https://cdn-images.mailchimp.com/automations/journey-builder/Customer-Journey_Animation.gif">
        <div class="page_title">Create a map of your contact's journey</div>
        <div class="page_subtitle">Put your contacts on a path that’s right for them. With a customer journey, you can always be there for your contacts when they need you most.</div>
        <div class="name_container">
            <label>Name</label>
            <input type="text">
            <button>Start Building</button>
        </div>
    

    </div>

    </div>
 
</body>
</html>