<?php

session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "toggle";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$companyid = $_SESSION['companyid'];
$userid = $_SESSION['userid'];

if(isset($_POST['mail']) && !empty($_POST['mail']) && isset($_POST['tag_id']) && !empty($_POST['tag_id']) && isset($_POST['auidence_id']) && !empty($_POST['auidence_id'])){
    $mail = $_POST['mail'];
    $tag_id = $_POST['tag_id'];
    $auidence_id = $_POST['auidence_id'];
    
      // Prepare and execute the SQL query to insert the name
      $sql = "INSERT INTO contacts (mail,tag_id,auidence_id,userid,companyid) VALUES ('$mail','$tag_id','$auidence_id','$userid','$companyid')";
      if ($conn->query($sql) === TRUE) {
          // Name inserted successfully, retrieve the ID
          $lastInsertId = $conn->insert_id;
          echo $lastInsertId;
      } else {
          // Set HTTP response code 500 (Internal Server Error) for database error
          http_response_code(500);
      }

}
else{
    http_response_code(400);
    die("Please fill out all fields.");
}

        // Close connection
        $conn->close();
?>