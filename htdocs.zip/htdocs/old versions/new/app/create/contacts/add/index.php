<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle | Email Marketing Software</title>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,300,0,0" />


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">


<link rel="stylesheet" href="../../../components/nav/index.css">
<link rel="stylesheet" href="../../../components/menu/index.css">


    <style>
        body{
            margin: 0;
            padding: 0;
            font-family: "Outfit", sans-serif;
            font-optical-sizing: auto;
            font-weight: 400;
            font-style: normal;
            color: #1c1c1c;
        }


button {
    border: none;
    font-family: "Outfit", sans-serif;
    background: #f8f5f2;
    font-size: 15px;
    font-weight: 500;
    cursor: pointer;
}

.menu button:nth-child(1){
    background-color: #0a80800a;
    border-right: 3px solid #0a8080;
    color: #0a8080;
}

.main {
    display: flex;
    height: calc(100vh - 80px);
    margin-top: 80px;
}
.page{
    width: calc(100% - 300px);
    overflow: scroll;
    padding: 40px 40px;
}

.page_title {
    font-size: 32px;
    font-weight: 500;
}

.page_subtitle {
    font-size: 16px;
    font-weight: 400;
    color: #525257;
    margin-bottom: 30px;
}

.page_btns {
    display: flex;
    width: 100%;
    flex-wrap: wrap;
}

.page_btns button {
    border: 1px solid #dcdcdc;
    border-radius: 4px;
    box-shadow: 0 0 2px rgba(28,28,28,.1), 0 4px 6px rgba(28,28,28,.04), 0 8px 16px rgba(28,28,28,.04), 0 10px 20px 2px rgba(28,28,28,.02);
    background: white;
    margin-right: 40px;
    margin-bottom: 20px;
    padding: 15px 20px;
    text-align: left;
    width: 310px;
}
.page_btns button:hover{
    border: 1px solid #0a8080;
}

.page_btns button .page_btn_title {
    padding: 10px 0px;
    font-size: 15px;
    font-weight: 500;
}
.page_btns button .page_btn_subtitle {
    font-size: 12px;
    font-weight: 400;
    color: #525257;
}

.page label {
    display: block;
    font-size: 15px;
    font-weight: 500;
    margin-top: 20px;
    margin-bottom: 5px;
}

.page input {
    background: #f4f4f3;
    font-size: 18px;
    font-weight: 400;
    width: 300px;
    font-family: "Outfit", sans-serif;
    padding: 7px 15px;
    border-radius: 5px;
    border: 1px solid #e5e5e5;
    outline-color: #0a8080;
}

.page .btns_line{
    width: 300px;
    display: flex;
    align-items: center;
    justify-content: start;
}
.page .btns_line button {
    padding: 5px 15px;
    width: 40%;
    margin-top: 20px;
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 17px;
    font-weight: 400;
    margin-right: 15px;
    background: #f8f5f2;
}
.page .btns_line button:hover{
    background-color: #005961;
}
.page .btns_line button:nth-child(1):hover{
    background-color: #dfdedd;
}
.page .btns_line button:nth-child(2){
    background: #0a8080;
    color: white;
}


button.page_back {
    background: none;
    margin-bottom: 20px;
    font-size: 20px;
    display: flex;
    justify-content: center;
    color: #525257;
}

button.page_back i {
    margin-right: 10px;
}

    </style>
</head>
<body>
    <?php
  include '../../../components/nav/index.php';
?>
    <div class="main">
        <?php
        include '../../../components/menu/index.html';
      ?>

    <div class="page">

    
    <button onclick="history.back()" class="page_back"><i class="bi bi-arrow-left"></i>back</button>

        <div class="page_title">Add Contacts</div>
        <div class="page_subtitle">Enter contacts one at a time. Include name, email, and other details.</div>
        <form id="addnewcontact" action="./from.php" method="POST">

        <label>Select Audience</label>
        <select name="auidence_id">
            <option>Default</option>
            <option>Create new</option>
</select>
<label>Select Tag</label>
        <select name="tag_id">
            <option>Default</option>
            <option>Create new</option>
</select>
        <label>Email Address</label>
        <input name="mail" type="text">
        <div class="btns_line">
            <button onclick="event.preventDefault()">Cancel</button><button>Add</button>
        </div>

    </form>

    </div>
    </div>

    <script>

document.getElementById("addnewcontact").addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent the form from submitting traditionally

        var formData = new FormData(this); // Get the form data

        // Create a new XMLHttpRequest object
        var xhr = new XMLHttpRequest();

        // Configure the request
        xhr.open("POST", "./api.php", true);

        // Set up a handler for when the request finishes
        xhr.onload = function() {
            if (xhr.status >= 200 && xhr.status < 300) {
                // Request was successful
                alert("done");
            } else {
                // Request failed
                console.error(xhr.statusText);
            }
        };

        // Set up a handler for network errors
        xhr.onerror = function() {
            console.error("Request failed");
        };

        // Send the request
        xhr.send(formData);
    });
    </script>

 
</body>
</html>