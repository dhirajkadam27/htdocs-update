<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle | Email Marketing Software</title>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,300,0,0" />


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">


<link rel="stylesheet" href="../../components/nav/index.css">
<link rel="stylesheet" href="../../components/menu/index.css">

    <style>
        body{
            margin: 0;
            padding: 0;
            font-family: "Outfit", sans-serif;
            font-optical-sizing: auto;
            font-weight: 400;
            font-style: normal;
            color: #1c1c1c;
        }


button {
    border: none;
    font-family: "Outfit", sans-serif;
    background: #f8f5f2;
    font-size: 15px;
    font-weight: 500;
    cursor: pointer;
}


.menu button:nth-child(1){
    background-color: #0a80800a;
    border-right: 3px solid #0a8080;
    color: #0a8080;
}
.main {
    display: flex;
    height: calc(100vh - 80px);
    margin-top: 80px;
}
.page{
    width: calc(100% - 300px);
    overflow: scroll;
    padding: 40px 40px;
}   

.page_title {
    font-size: 32px;
    font-weight: 500;
}

.page_subtitle {
    font-size: 16px;
    font-weight: 400;
    color: #525257;
    margin-bottom: 30px;
}

.page_btns {
    display: flex;
    width: 100%;
    flex-wrap: wrap;
}

.page_btns button {
    border: 1px solid #dcdcdc;
    border-radius: 4px;
    box-shadow: 0 0 2px rgba(28,28,28,.1), 0 4px 6px rgba(28,28,28,.04), 0 8px 16px rgba(28,28,28,.04), 0 10px 20px 2px rgba(28,28,28,.02);
    background: white;
    margin-right: 40px;
    margin-bottom: 20px;
    padding: 15px 20px;
    text-align: left;
    width: 310px;
}
.page_btns button:hover{
    border: 1px solid #0a8080;
}

.page_btns button .page_btn_title {
    padding: 10px 0px;
    font-size: 15px;
    font-weight: 500;
}
.page_btns button .page_btn_subtitle {
    font-size: 12px;
    font-weight: 400;
    color: #525257;
}


button.page_back {
    background: none;
    margin-bottom: 20px;
    font-size: 20px;
    display: flex;
    justify-content: center;
    color: #525257;
}

button.page_back i {
    margin-right: 10px;
}


    </style>
</head>
<body>
<?php
  include '../../components/nav/index.php';
?>
    <div class="main">
        <?php
        include '../../components/menu/index.html';
      ?>

    <div class="page">

    
    <button onclick="history.back()" class="page_back"><i class="bi bi-arrow-left"></i>back</button>

        <div class="page_title">Add or import contacts</div>
        <div class="page_subtitle">One at a time, a few at once, or a whole file upload - you have options.</div>
    
        <div class="page_btns">
            <button onclick="window.location.href='./add'">
                <div class="page_btn_title">Add Contacts</div>
                <div class="page_btn_subtitle">Enter contacts one at a time. Include name, email, and other details.</div>
            </button>
            
            <button onclick="window.location.href='./paste'">
                <div class="page_btn_title">Type or paste multiple contacts</div>
                <div class="page_btn_subtitle">Type or paste in email addresses and names for several contacts at once.</div>
            </button>
            
            <button onclick="window.location.href='./upload'">
                <div class="page_btn_title">Upload from file</div>
                <div class="page_btn_subtitle">We'll pull in your contacts and other details from a spreadsheet or file.</div>
            </button>
        
      
        </div>

    </div>
 
</div>

</body>
</html>