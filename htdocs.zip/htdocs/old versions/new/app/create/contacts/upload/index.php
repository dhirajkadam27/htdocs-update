<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle | Email Marketing Software</title>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,300,0,0" />


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">


<link rel="stylesheet" href="../../../components/nav/index.css">
<link rel="stylesheet" href="../../../components/menu/index.css">


    <style>
        body{
            margin: 0;
            padding: 0;
            font-family: "Outfit", sans-serif;
            font-optical-sizing: auto;
            font-weight: 400;
            font-style: normal;
            color: #1c1c1c;
        }


button {
    border: none;
    font-family: "Outfit", sans-serif;
    background: #f8f5f2;
    font-size: 15px;
    font-weight: 500;
    cursor: pointer;
}

.menu button:nth-child(1){
    background-color: #0a80800a;
    border-right: 3px solid #0a8080;
    color: #0a8080;
}

.main {
    display: flex;
    height: calc(100vh - 80px);
    margin-top: 80px;
}
.page{
    width: calc(100% - 300px);
    overflow: scroll;
    padding: 40px 40px;
}

.page_title {
    font-size: 32px;
    font-weight: 500;
}

.page_subtitle {
    font-size: 16px;
    font-weight: 400;
    color: #525257;
    margin-bottom: 30px;
}
.page_tabs {border-bottom: 1px solid #eaeaea;margin-bottom: 40px;}

.page_tabs button {
    padding: 20px 10px;
    margin: 0px;
    background: none;
    border-bottom: 5px solid none;
    color: #6c6c72;
}
.page_tabs .button_active {
    border-bottom: 5px solid #f45d48;
    color:#1c1c1c
}


button.page_back {
    background: none;
    margin-bottom: 20px;
    font-size: 20px;
    display: flex;
    justify-content: center;
    color: #525257;
}

button.page_back i {
    margin-right: 10px;
}
.page label {
    display: block;
    font-size: 15px;
    font-weight: 500;
    margin-top: 20px;
    margin-bottom: 5px;
}



    </style>
</head>
<body>
<?php
  include '../../../components/nav/index.php';
?>
    <div class="main">
        <?php
        include '../../../components/menu/index.html';
      ?>


    <div class="page">

    <button onclick="history.back()" class="page_back"><i class="bi bi-arrow-left"></i>back</button>
    
        <div class="page_title">Upload from file</div>
        <div class="page_subtitle">We'll merge contacts in your file with existing contacts if they have the same email address.</div>
    
<div id="upload_more_contact">
    
    <div class="add_contacts_title">Upload your file</div>
    <div class="add_contacts_forms">



        <div id="message"></div>

        <div class="row" id="upload_area">
            <form method="post" onsubmit="inputfileform(this)" enctype="multipart/form-data">

            <div class="select_flex">

<div class="select_box">
    
<label>Select Audience</label>
<select name="auidence_id">
    <option>Default</option>
    <option>Create new</option>
</select>

</div>

<div class="select_box">
    
    <label>Select tag</label>
    <select name="tag_id">
        <option>Default</option>
        <option>Create new</option>
</select>

    </div>
</div>


                <input type="file" name="file" id="csv_file" />
                <input type="submit" name="upload_file" id="upload_file" value="Upload" />
            </form>
            
          </div>

                <div class="table-responsive" id="process_area">

                </div>

    </div>

</div>
  

    </div>
 
</div>

<script>


function inputfileform(div){
        event.preventDefault();
    $.ajax({
      url:"upload.php",
      method:"POST",
      data:new FormData(div),
      dataType:'json',
      contentType:false,
      cache:false,
      processData:false,
      success:function(data)
      {
        if(data.error != '')
        {
          $('#message').html('<div class="alert alert-danger">'+data.error+'</div>');
        }
        else
        {
          $('#process_area').html(data.output);
          $('#upload_area').css('display', 'none');
        }
      }
    });
      }

      
  var total_selection = 0;

var first_name = 0;

var last_name = 0;

var email = 0;

var column_data = [];

$(document).on('change', '.set_column_data', function(){

  var column_name = $(this).val();

  var column_number = $(this).data('column_number');

  if(column_name in column_data)
  {
    alert('You have already define '+column_name+ ' column');

    $(this).val('');

    return false;
  }

  if(column_name != '')
  {
    column_data[column_name] = column_number;
  }
  else
  {
    const entries = Object.entries(column_data);

    for(const [key, value] of entries)
    {
      if(value == column_number)
      {
        delete column_data[key];
      }
    }
  }

  total_selection = Object.keys(column_data).length;

  if(total_selection == 3)
  {
    $('#import').attr('disabled', false);

    first_name = column_data.first_name;

    last_name = column_data.last_name;

    email = column_data.email;
  }
  else
  {
    $('#import').attr('disabled', 'disabled');
  }

});

$(document).on('click', '#import', function(event){

  event.preventDefault();

  $.ajax({
    url:"import.php",
    method:"POST",
    data:{first_name:first_name, last_name:last_name, email:email},
    beforeSend:function(){
      $('#import').attr('disabled', 'disabled');
      $('#import').text('Importing...');
    },
    success:function(data)
    {
      $('#import').attr('disabled', false);
      $('#import').text('Import');
      $('#process_area').css('display', 'none');
      $('#upload_area').css('display', 'block');
    //   $('#upload_form')[0].reset();
      $('#message').html("<div class='alert alert-success'>"+data+"</div>");
    }
  })

});

    </script>
</body>
</html>