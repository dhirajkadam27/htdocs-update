<?php
session_start();
// Replace with your database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "toggle";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get values from POST request
$data = $_POST['data'];

// Split data into individual records
$records = explode("\n", $data);

// Process each record
foreach ($records as $record) {
  $details = explode(" ", $record);

// Validate minimum data (email)
if (empty($details[0])) {
    echo "Invalid record: $record (missing email)<br>";
    continue;
  }

  $email = $details[0];
  $firstName = isset($details[1]) ? $details[1] : null;
  $lastName = isset($details[2]) ? $details[2] : null;

  
$companyid = $_SESSION['companyid'];
$userid = $_SESSION['userid'];


$tag_id = $_POST['tag_id'];
$auidence_id = $_POST['auidence_id'];


  // Insert record into database
  $sql = "INSERT INTO contacts (mail, firstname, lastname,tag_id,auidence_id,userid,companyid) VALUES ('$email', '$firstName', '$lastName','$tag_id','$auidence_id','$userid','$companyid')";
  if ($conn->query($sql) === TRUE) {
    echo "Record added successfully<br>";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error . "<br>";
  }
}

$conn->close();
?>
