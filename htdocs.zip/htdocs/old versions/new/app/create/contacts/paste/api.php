<?php

session_start();
// Replace with your database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "toggle";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get values from POST request
$emails = $_POST['email'];
$firstNames = $_POST['firstName'];
$lastNames = $_POST['lastName'];


$companyid = $_SESSION['companyid'];
$userid = $_SESSION['userid'];


$tag_id = $_POST['tag_id'];
$auidence_id = $_POST['auidence_id'];

// Filter out empty values
$filtered = array_filter(array_map(function ($email, $firstName, $lastName) {
  return !empty($email) && !empty($firstName) && !empty($lastName) ? [$email, $firstName, $lastName] : null;
}, $emails, $firstNames, $lastNames));

$emails = array_column($filtered, 0);
$firstNames = array_column($filtered, 1);
$lastNames = array_column($filtered, 2);

// Insert records into database
foreach ($emails as $i => $email) {
  $sql = "INSERT INTO contacts (mail, firstname, lastname,tag_id,auidence_id,userid,companyid) VALUES ('$email', '$firstNames[$i]', '$lastNames[$i]','$tag_id','$auidence_id','$userid','$companyid')";
  if ($conn->query($sql) === TRUE) {
    echo "Record added successfully<br>";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
}

$conn->close();
?>
