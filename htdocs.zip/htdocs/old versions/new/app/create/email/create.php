<?php

session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "toggle";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create a DateTime object from the date string
$date = new DateTime();

// Format the date according to the desired format
$date = $date->format("M d, Y \a\\t g:ia T");

$companyid = $_SESSION['companyid'];
$userid = $_SESSION['userid'];

if(isset($_POST['name']) && !empty($_POST['name'])){
    $name = $_POST['name'];
    
      // Prepare and execute the SQL query to insert the name
      $sql = "INSERT INTO campaigns (companyid,userid,type,name,created,status) VALUES ('$companyid','$userid','email','$name','$date','draft')";
      if ($conn->query($sql) === TRUE) {
          // Name inserted successfully, retrieve the ID
          $lastInsertId = $conn->insert_id;
          echo $lastInsertId;
      } else {
          // Set HTTP response code 500 (Internal Server Error) for database error
          http_response_code(500);
      }

}
else{
    http_response_code(400);
    die("Please fill out all fields.");
}

        // Close connection
        $conn->close();
?>