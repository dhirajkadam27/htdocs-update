<?php
session_start();
$id="";
if(isset($_GET['id'])){
    $id = $_GET['id'];
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "toggle";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$campaignname = "";
$campaignaudience = "";
$campaignsend = "";
$campaigndontsend = "";
$campaignemailname = "";
$campaignemail = "";
$campaignsubject = "";
$campaignpreviewtext = "";

$campaign_sql = "SELECT * FROM campaigns WHERE campaignid='$id'";
$campaign_result = $conn->query($campaign_sql);

if ($campaign_result->num_rows > 0) {
    // output data of each row
        while ($campaign_row = $campaign_result->fetch_assoc()) {
          $campaignname = $campaign_row['name'];
          $campaignaudience = $campaign_row['audience'];
          $campaignsend = $campaign_row['send'];
          $campaigndontsend = $campaign_row['dontsend'];
          $campaignemailname = $campaign_row['emailname'];
          $campaignemail = $campaign_row['email'];
          $campaignsubject = $campaign_row['subject'];
          $campaignpreviewtext = $campaign_row['previewtext'];
        }
      }else{
        echo "user not found";
      }

    
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle | Email Marketing Software</title>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&display=swap" rel="stylesheet">

    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,300,0,0" />


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">


    <link rel="stylesheet" href="../../components/nav/index.css">
    <link rel="stylesheet" href="../../components/menu/index.css">


    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: "Outfit", sans-serif;
            font-optical-sizing: auto;
            font-weight: 400;
            font-style: normal;
            color: #1c1c1c;
        }


        button {
            border: none;
            font-family: "Outfit", sans-serif;
            background: #f8f5f2;
            font-size: 15px;
            font-weight: 500;
            cursor: pointer;
        }

        .menu button:nth-child(1) {
            background-color: #0a80800a;
            border-right: 3px solid #0a8080;
            color: #0a8080;
        }

        .main {
            display: flex;
            height: calc(100vh - 80px);
            margin-top: 80px;
        }

        .page {
            width: calc(100% - 300px);
            overflow: scroll;
            padding: 40px 40px;
        }

        .page_title {
            font-size: 32px;
            font-weight: 500;
        }

        .page_subtitle {
            font-size: 16px;
            font-weight: 400;
            color: #0a8080;
            margin-bottom: 10px;
        }

        .page_nav {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .page_nav .right button {
            padding: 12px 20px;
            margin: 0px 10px;
            border-radius: 5px;
            background: #f8f5f2;
        }

        .page_nav .right button:nth-child(2) {
            background: #0a8080;
            color: white;
        }


        .send_email_page {
            display: flex;
            justify-content: start;
            margin-top: 50px;
        }

        .send_email_page .left {
            width: 50%;
        }

        .send_email_page .left .box {
            display: block;
            border: 1px solid #d0d0d0;
            padding: 15px 20px;
            cursor: pointer;
        }

        .box_header {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .box .collapse {
            margin-top: 20px;
        }

        .send_email_page .left .box .box_left {
            display: block;
        }

        .send_email_page .left .box .box_left .box_title {
            font-size: 18px;
            font-weight: 500;
        }

        .send_email_page .left .box .box_left .box_subtitle {
            font-size: 15px;
            font-weight: 400;
            color: #525257;
            margin-top: 5px;
        }

        .send_email_page .left .box button {
            padding: 5px 15px;
            font-size: 15px;
            color: white;
            background: #0a8080;
            border-radius: 4px;
        }
        .send_email_page .left .box button i {
            font-size:22px
        }
        .send_email_page .left .box button:has(i){
            padding: 0px 16px;
            background: #17b75e;
        }

        .send_email_page .right {
            width: 40%;
            height: 500px;
            margin-left: 3%;
            background: #e7e7e7;
        }

        button.page_back {
            background: none;
            margin-bottom: 20px;
            font-size: 20px;
            display: flex;
            justify-content: center;
            color: #525257;
        }

        button.page_back i {
            margin-right: 10px;
        }

        .collapse_section {
    display: block;
}

.collapse_section .txt {
    display: block;
    font-size: 12px;
    font-weight: 400;
}

.collapse_section select {background: #f4f4f3;font-size: 18px;font-weight: 400;width: 40%;font-family: "Outfit", sans-serif;padding: 7px 15px;border-radius: 5px;border: 1px solid #e5e5e5;outline-color: #0a8080;display: block;margin: 10px 0px;}

.collapse_section label {
    display: block;
    font-size: 12px;
    font-weight: 400;
}

.collapse_section input {
    background: #f4f4f3;
    font-size: 18px;
    font-weight: 400;
    width: 40%;
    font-family: "Outfit", sans-serif;
    padding: 7px 15px;
    border-radius: 5px;
    border: 1px solid #e5e5e5;
    outline-color: #0a8080;
    display: block;
    margin: 10px 0px;
}

.collapse_section button {
    padding: 5px 15px;
    font-size: 15px;
    color: #0a8080;
    border-radius: 4px;
    margin-right: 10px;
}

.collapse_section .btns button:nth-child(1) {
    background: #f45d48;
    color: white !important;
}
.collapse_section .btns button:nth-child(2) {
    background: #f8f5f2;
    color: #1c1c1c;
}

.collapse_section .btns {
    display: flex;
    align-items: center;
    margin-top: 15px;
}
    </style>
</head>

<body>

    <?php
  include '../../components/nav/index.php';
?>
    <div class="main">
        <?php
        include '../../components/menu/index.html';
      ?>

        <div class="page">

            <button onclick="history.back()" class="page_back"><i class="bi bi-arrow-left"></i>back</button>

            <div class="page_nav">
                <div class="page_left">
                    <div class="page_title"><?php echo $campaignname; ?></div>
                    <div class="page_subtitle">Edit name</div>
                </div>
                <div class="right">
                    <button>Finish Later</button>
                    <button>Send</button>
                </div>
            </div>

            <div class="send_email_page">

                <div class="left" id="accordionFlushExample">
                    <div class="box">
                        <div class="box_header">
                            <div class="box_left">
                                <div class="box_title">To</div>
                                <div class="box_subtitle">Who are you sending this email to?</div>
                            </div>
                            <button id="tobtn" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne">
                            <?php 
                                if(empty($campaignaudience) || empty($campaignsend) || empty($campaigndontsend)){
                                echo 'Add';
                                }else{
                                echo '<i class="bi bi-check-all"></i>';
                                }
                                ?>
                            </button>
                        </div>

                        <div id="flush-collapseOne" class="collapse" data-bs-parent="#accordionFlushExample">
                            <div class="collapse_section">
                                <form id="updatetosection" action="./to.php" method="POST">
                                <div class="txt">Audience</div>
                                <select name="audience" required value="<?php echo $campaignaudience; ?>">
                                    <option>Mobile</option>
                                    <option>Grocery</option>
                                </select>
                                <label>Send to</label>
                                <input type="hidden" name="campaignid" value="<?php echo $id; ?>">
                                <input name="send" required type="text" value="<?php echo $campaignsend; ?>">
                                <label>Do not send to (optional)</label>
                                <input name="dontsend" required type="text" value="<?php echo $campaigndontsend; ?>">
                                <div class="btns">
                                    <button data-bs-toggle="collapse" data-bs-target="#flush-collapseOne">Save</button>
                                </form>
                                    <button data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" onclick="event.preventDefault()">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="box">
                        <div class="box_header">
                            <div class="box_left">
                                <div class="box_title">From</div>
                                <div class="box_subtitle">Who is sending this email?</div>
                            </div>
                            <button id="frombtn" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo">
                                <?php 
                                if(empty($campaignemailname) || empty($campaignemail)){
                                echo 'Add';
                                }else{
                                echo '<i class="bi bi-check-all"></i>';
                                }
                                ?>
                            </button>
                        </div>

                        <div id="flush-collapseTwo" class="collapse" data-bs-parent="#accordionFlushExample">
                            <div class="collapse_section">
                                <form id="updatefromsection" action="./from.php" method="POST">
                                    <label>Name</label>
                                    <input name="name" required type="text" value="<?php echo $campaignemailname; ?>">
                                <div class="txt">Email</div>
                                <input type="hidden" name="campaignid" value="<?php echo $id; ?>">
                                <select name="email" required value="<?php echo $campaignemail; ?>">
                                    <option>dhirajkadam.official@gmail.com</option>
                                    <option>dhirajkadam.official@gmail.com</option>
                                </select>
                                <div class="btns">
                                    <button data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo">Save</button>
                                </form>
                                    <button data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" onclick="event.preventDefault()">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="box">
                        <div class="box_header">
                            <div class="box_left">
                                <div class="box_title">Subject</div>
                                <div class="box_subtitle">What's the subject line for this email?</div>
                            </div>
                            <button id="subjectbtn" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree">
                            <?php 
                                if(empty($campaignsubject) || empty($campaignpreviewtext)){
                                echo 'Add';
                                }else{
                                echo '<i class="bi bi-check-all"></i>';
                                }
                                ?>
                            </button>
                        </div>

                        <div id="flush-collapseThree" class="collapse" data-bs-parent="#accordionFlushExample">
                            <div class="collapse_section">
                                <form id="updatesubjectsection" action="./from.php" method="POST">
                                <label>Subject</label>
                                <input type="hidden" name="campaignid" value="<?php echo $id; ?>">
                                <input type="text" required name="subject" value="<?php echo $campaignsubject; ?>">
                                <label>Perview Text</label>
                                <input type="text" required name="previewtext" value="<?php echo $campaignpreviewtext; ?>">
                                <div class="btns">
                                    <button data-bs-toggle="collapse" data-bs-target="#flush-collapseThree">Save</button>
                                </form>
                                    <button data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" onclick="event.preventDefault()">Close</button>
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="box">
                        <div class="box_header">
                            <div class="box_left">
                                <div class="box_title">Design</div>
                                <div class="box_subtitle">Design the Content for your email.</div>
                            </div>
                            <button onclick="window.location.href='./templates'">Add</button>
                        </div>
                    </div>


                </div>
                <div class="right">

                </div>
            </div>



        </div>

    </div>

    <script>

document.getElementById("updatetosection").addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent the form from submitting traditionally

        var formData = new FormData(this); // Get the form data

        // Create a new XMLHttpRequest object
        var xhr = new XMLHttpRequest();

        // Configure the request
        xhr.open("POST", "./to.php", true);

        // Set up a handler for when the request finishes
        xhr.onload = function() {
            if (xhr.status >= 200 && xhr.status < 300) {
                // Request was successful
                document.getElementById('tobtn').innerHTML = '<i class="bi bi-check-all"></i>';
            } else {
                // Request failed
                console.error(xhr.statusText);
            }
        };

        // Set up a handler for network errors
        xhr.onerror = function() {
            console.error("Request failed");
        };

        // Send the request
        xhr.send(formData);
    });

    
document.getElementById("updatefromsection").addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent the form from submitting traditionally

        var formData = new FormData(this); // Get the form data

        // Create a new XMLHttpRequest object
        var xhr = new XMLHttpRequest();

        // Configure the request
        xhr.open("POST", "./from.php", true);

        // Set up a handler for when the request finishes
        xhr.onload = function() {
            if (xhr.status >= 200 && xhr.status < 300) {
                // Request was successful
                document.getElementById('frombtn').innerHTML = '<i class="bi bi-check-all"></i>';
            } else {
                // Request failed
                console.error(xhr.statusText);
            }
        };

        // Set up a handler for network errors
        xhr.onerror = function() {
            console.error("Request failed");
        };

        // Send the request
        xhr.send(formData);
    });

      
document.getElementById("updatesubjectsection").addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent the form from submitting traditionally

        var formData = new FormData(this); // Get the form data

        // Create a new XMLHttpRequest object
        var xhr = new XMLHttpRequest();

        // Configure the request
        xhr.open("POST", "./subject.php", true);

        // Set up a handler for when the request finishes
        xhr.onload = function() {
            if (xhr.status >= 200 && xhr.status < 300) {
                // Request was successful
                document.getElementById('subjectbtn').innerHTML = '<i class="bi bi-check-all"></i>';
            } else {
                // Request failed
                console.error(xhr.statusText);
            }
        };

        // Set up a handler for network errors
        xhr.onerror = function() {
            console.error("Request failed");
        };

        // Send the request
        xhr.send(formData);
    });
    </script>
</body>

</html>