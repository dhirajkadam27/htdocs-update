<?php

session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "toggle";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if(isset($_POST['campaignid']) && !empty($_POST['campaignid']) && isset($_POST['subject']) && !empty($_POST['subject']) && isset($_POST['previewtext']) && !empty($_POST['previewtext'])){
    $campaignid = $_POST['campaignid'];
    $subject = $_POST['subject'];
    $previewtext = $_POST['previewtext'];
    
      // Prepare and execute the SQL query to insert the name
      $sql = "UPDATE campaigns SET subject='$subject',previewtext='$previewtext' WHERE campaignid=$campaignid";
      if ($conn->query($sql) === TRUE) {
          echo "Name updated successfully.";
      } else {
          // Set HTTP response code 500 (Internal Server Error) for database error
          http_response_code(500);
          echo "Error updating name: " . $conn->error;
      }

}
else{
    http_response_code(400);
    die("Please fill out all fields.");
}

        // Close connection
        $conn->close();
?>