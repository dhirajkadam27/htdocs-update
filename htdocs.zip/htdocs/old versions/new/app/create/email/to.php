<?php

session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "toggle";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if(isset($_POST['campaignid']) && !empty($_POST['campaignid']) && isset($_POST['audience']) && !empty($_POST['audience']) && isset($_POST['send']) && !empty($_POST['send']) && isset($_POST['dontsend']) && !empty($_POST['dontsend'])){
    $campaignid = $_POST['campaignid'];
    $audience = $_POST['audience'];
    $send = $_POST['send'];
    $dontsend = $_POST['dontsend'];
    
      // Prepare and execute the SQL query to insert the name
      $sql = "UPDATE campaigns SET audience='$audience',send='$send',dontsend='$dontsend' WHERE campaignid=$campaignid";
      if ($conn->query($sql) === TRUE) {
          echo "Name updated successfully.";
      } else {
          // Set HTTP response code 500 (Internal Server Error) for database error
          http_response_code(500);
          echo "Error updating name: " . $conn->error;
      }

}
else{
    http_response_code(400);
    die("Please fill out all fields.");
}

        // Close connection
        $conn->close();
?>