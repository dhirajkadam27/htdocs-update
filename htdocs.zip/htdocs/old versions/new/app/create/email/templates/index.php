<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle | Email Marketing Software</title>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,300,0,0" />


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">


<link rel="stylesheet" href="../../../components/nav/index.css">
<link rel="stylesheet" href="../../../components/menu/index.css">

    <style>
        body{
            margin: 0;
            padding: 0;
            font-family: "Outfit", sans-serif;
            font-optical-sizing: auto;
            font-weight: 400;
            font-style: normal;
            color: #1c1c1c;
        }


button {
    border: none;
    font-family: "Outfit", sans-serif;
    background: #f8f5f2;
    font-size: 15px;
    font-weight: 500;
    cursor: pointer;
}

.menu button:nth-child(1){
    background-color: #0a80800a;
    border-right: 3px solid #0a8080;
    color: #0a8080;
}
.main {
    display: flex;
    height: calc(100vh - 80px);
    margin-top: 80px;
}
.page{
    width: calc(100% - 300px);
    overflow: scroll;
    padding: 40px 40px;
}


.page_title {
    font-size: 32px;
    font-weight: 500;
}

.page_subtitle {
    font-size: 16px;
    font-weight: 400;
    color: #525257;
    margin-bottom: 10px;
}

.page_btns {
    display: flex;
    width: 100%;
    flex-wrap: wrap;
}

.page_btns button {
    border: 1px solid #dcdcdc;
    border-radius: 4px;
    box-shadow: 0 0 2px rgba(28,28,28,.1), 0 4px 6px rgba(28,28,28,.04), 0 8px 16px rgba(28,28,28,.04), 0 10px 20px 2px rgba(28,28,28,.02);
    background: white;
    margin-right: 40px;
    margin-bottom: 50px;
}
.page_btns button:hover{
    border: 1px solid #0a8080;
}

.page_btns button img {    width: 220px;
    height: 250px;
}

.page_btns button .page_btn_title {
    padding: 10px 0px;
}

.page_tabs {border-bottom: 1px solid #eaeaea;margin-bottom: 40px;}

.page_tabs button {
    padding: 20px 10px;
    margin: 0px;
    background: none;
    border-bottom: 5px solid none;
    color: #6c6c72;
}
.page_tabs .button_active {
    border-bottom: 5px solid #f45d48;
    color:#1c1c1c
}

#saved_templates{
    display: none;
}
    </style>
</head>
<body>

<?php
  include '../../../components/nav/index.php';
?>
    <div class="main">
        <?php
        include '../../../components/menu/index.html';
      ?>

    <div class="page">

        <div class="page_title">Select a template</div>
        <div class="page_subtitle">Each template is fully customizable, easy to edit, and mobile responsive.</div>

        <div class="page_tabs">
            <button class="button_active">Toggle templates</button>
            <button>Saved templates</button>
        </div>

        
        <div id="toggle_templates">
            <div class="page_btns">
                <button>
                    <img src="https://cdn-images.mailchimp.com/template_images/email/thumbnails/2x/Bold.jpg">
                    <div class="page_btn_title">Bold</div>
                </button>
                <button>
                    <img src="https://cdn-images.mailchimp.com/template_images/email/thumbnails/2x/Minimal.jpg">
                    <div class="page_btn_title">Minimal</div>
                </button>
                <button>
                    <img src="https://cdn-images.mailchimp.com/template_images/email/thumbnails/2x/Bold.jpg">
                    <div class="page_btn_title">Bold</div>
                </button>
                <button>
                    <img src="https://cdn-images.mailchimp.com/template_images/email/thumbnails/2x/Natural.jpg">
                    <div class="page_btn_title">Natural</div>
                </button>
                <button>
                    <img src="https://cdn-images.mailchimp.com/template_images/email/thumbnails/2x/Gallery.jpg">
                    <div class="page_btn_title">Gallery</div>
                </button>
                <button>
                    <img src="https://cdn-images.mailchimp.com/template_images/email/thumbnails/2x/Survey.jpg">
                    <div class="page_btn_title">Survey</div>
                </button>
                
            </div>
        </div>

             
        <div id="saved_templates">
            <div class="page_btns">
                <button>
                    <img src="https://cdn-images.mailchimp.com/template_images/email/thumbnails/2x/Bold.jpg">
                    <div class="page_btn_title">Bold</div>
                </button>
                <button>
                    <img src="https://cdn-images.mailchimp.com/template_images/email/thumbnails/2x/Minimal.jpg">
                    <div class="page_btn_title">Minimal</div>
                </button>
                <button>
                    <img src="https://cdn-images.mailchimp.com/template_images/email/thumbnails/2x/Bold.jpg">
                    <div class="page_btn_title">Bold</div>
                </button>
                <button>
                    <img src="https://cdn-images.mailchimp.com/template_images/email/thumbnails/2x/Natural.jpg">
                    <div class="page_btn_title">Natural</div>
                </button>
                <button>
                    <img src="https://cdn-images.mailchimp.com/template_images/email/thumbnails/2x/Gallery.jpg">
                    <div class="page_btn_title">Gallery</div>
                </button>
                <button>
                    <img src="https://cdn-images.mailchimp.com/template_images/email/thumbnails/2x/Survey.jpg">
                    <div class="page_btn_title">Survey</div>
                </button>
                
            </div>
        </div>

    

    </div>
 

</div>

</body>
</html>