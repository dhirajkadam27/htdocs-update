<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "toggle";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$templateid = $_GET['id'];

    $temeplate_sql = "SELECT title,emailformatjson,emailformathtml FROM templates WHERE templateid='$templateid'";
    $temeplate_result = $conn->query($temeplate_sql);

    if ($temeplate_result->num_rows > 0) {
        // output data of each row
            while ($temeplate_row = $temeplate_result->fetch_assoc()) {
                
//                 $response = array(
//                     'title' => $temeplate_row['title'],
//                     'json' => $temeplate_row['emailformatjson'],
//                     'html' => $temeplate_row['emailformathtml']
//                 );

//                 $json_response = json_encode($response);

// // Output JSON
// echo $json_response;

// echo $temeplate_row['emailformatjson'];

$json_response = json_encode($temeplate_row['emailformatjson']);

// Output JSON
echo $json_response;
            }

        } else {
            echo "sds";
        }

        ?>