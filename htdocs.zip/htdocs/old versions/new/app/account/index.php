<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle | Email Marketing Software</title>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,300,0,0" />


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">


<link rel="stylesheet" href="../components/nav/index.css">
<link rel="stylesheet" href="../components/menu/index.css">


    <style>
        body{
            margin: 0;
            padding: 0;
            font-family: "Outfit", sans-serif;
            font-optical-sizing: auto;
            font-weight: 400;
            font-style: normal;
            color: #1c1c1c;
        }


button {
    border: none;
    font-family: "Outfit", sans-serif;
    background: #f8f5f2;
    font-size: 15px;
    font-weight: 500;
    cursor: pointer;
}

.main {
    display: flex;
    height: calc(100vh - 80px);
    margin-top: 80px;
}
.page{
    width: calc(100% - 300px);
    overflow: scroll;
    padding: 40px 40px;
}

.page_title {
    font-size: 32px;
    font-weight: 500;
}

.page_subtitle {
    font-size: 16px;
    font-weight: 400;
    color: #525257;
    margin-bottom: 10px;
}
.page_nav {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.page_nav .right button {
    padding: 12px 20px;
    margin: 0px 10px;
    border-radius: 5px;
    background: #f8f5f2;
}

.page_nav .right button:nth-child(2) {
    background: #0a8080;
    color: white;
}

.page_tabs {border-bottom: 1px solid #eaeaea;margin-bottom: 40px;}

.page_tabs button {
    padding: 20px 10px;
    margin: 0px;
    background: none;
    border-bottom: 5px solid none;
    color: #6c6c72;
}
.page_tabs .button_active {
    border-bottom: 5px solid #f45d48;
    color:#1c1c1c
}

.page table {
    width: 100%;
}

.page th {
    background: #fbfafa;
    color: #6c6c72;
    padding: 10px 10px;
    border-bottom: 1px solid #eaeaea;
}
.page td {
    background: white;
    color: #1c1c1c;
    padding: 20px 10px;
    border-bottom: 1px solid #eaeaea;
}
.page td a {
    color: #0a8080;
}

.page td .table_content {
    display: block;
}

.page td .table_content .date {
    font-size: 15px;
    font-weight: 400;
    margin-top: 8px;
    color: #525257;
}

.campaign_btn {
    display: flex;
    justify-content: right;
}

.campaign_btn button {
    padding: 8px 20px;
    background: #f8f5f2;
    border-radius: 5px 0px 0px 5px;
}


.btn-group button {
    border-radius: 0px 5px 5px 0px;
    margin-left: 2px;
}

.page_form label {
    display: block;
    font-size: 15px;
    font-weight: 500;
    margin-top: 20px;
    margin-bottom: 5px;
}

.page_form input {
    background: #f4f4f3;
    font-size: 18px;
    font-weight: 400;
    width: 300px;
    font-family: "Outfit", sans-serif;
    padding: 7px 15px;
    border-radius: 5px;
    border: 1px solid #e5e5e5;
    outline-color: #0a8080;
}

.page_form button {
    background: #0a8080;
    color: white;
    padding: 10px 15px;
    width: 100px;
    margin-top: 20px;
    border-radius: 5px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 17px;
    font-weight: 500;
}
.page_form button:hover{
    background-color: #005961;
}
.page_form {
    margin-bottom: 40px;
}


    </style>
</head>
<body>

<?php
  include '../components/nav/index.php';
?>
    <div class="main">
        <?php
        include '../components/menu/index.html';
      ?>

    <div class="page">

        <div class="page_nav">
            <div class="page_left">
                <div class="page_title">Account</div>
                <div class="page_subtitle">Your audience has 2 contacts. 1 of these is subscribed.</div>
            </div>
        </div>    

        <div class="page_tabs">
            <button class="button_active">My Profile</button>
            <button onclick="window.location.href='./company'">Company</button>
            <button onclick="window.location.href='./users'">Users</button>
        </div>

        
        <div class="page_subtitle">Basic Information</div>
<div class="page_form">
<label>Username</label>
            <input type="text" value="<?php echo $username;?>">
<label>First Name</label>
            <input type="text" value="<?php echo $firstname;?>">
<label>Last Name</label>
            <input type="text" value="<?php echo $lastname;?>">
<label>Email address</label>
            <input type="text" value="<?php echo $email;?>">
    <button>Save</button>
</div>

        <div class="page_subtitle">Change password</div>

        <div class="page_form">
<label>Verify current password</label>
            <input type="text">
<label>New password</label>
            <input type="text">
<label>Confirm new password</label>
            <input type="text">
    <button>Save</button>
</div>


    </div>

</div>
 
</body>
</html>