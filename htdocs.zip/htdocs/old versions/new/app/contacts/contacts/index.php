<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle | Email Marketing Software</title>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,300,0,0" />


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">


<link rel="stylesheet" href="../../components/nav/index.css">
<link rel="stylesheet" href="../../components/menu/index.css">


    <style>
        body{
            margin: 0;
            padding: 0;
            font-family: "Outfit", sans-serif;
            font-optical-sizing: auto;
            font-weight: 400;
            font-style: normal;
            color: #1c1c1c;
        }


button {
    border: none;
    font-family: "Outfit", sans-serif;
    background: #f8f5f2;
    font-size: 15px;
    font-weight: 500;
    cursor: pointer;
}


.menu button:nth-child(4){
    background-color: #0a80800a;
    border-right: 3px solid #0a8080;
    color: #0a8080;
}
.main {
    display: flex;
    height: calc(100vh - 80px);
    margin-top: 80px;
}
.page{
    width: calc(100% - 300px);
    overflow: scroll;
    padding: 40px 40px;
}

.page_title {
    font-size: 32px;
    font-weight: 500;
}

.page_subtitle {
    font-size: 16px;
    font-weight: 400;
    color: #525257;
    margin-bottom: 10px;
}
.page_nav {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.page_nav .right button {
    padding: 12px 20px;
    margin: 0px 10px;
    border-radius: 5px;
    background: #f8f5f2;
}

.page_nav .right button:nth-child(1) {
    background: #0a8080;
    color: white;
}

.page_tabs {border-bottom: 1px solid #eaeaea;margin-bottom: 40px;}

.page_tabs button {
    padding: 20px 10px;
    margin: 0px;
    background: none;
    border-bottom: 5px solid none;
    color: #6c6c72;
}
.page_tabs .button_active {
    border-bottom: 5px solid #f45d48;
    color:#1c1c1c
}


.page_btns {
    display: flex;
    width: 100%;
    flex-wrap: wrap;
}

.page_btns button {
    border: 1px solid #dcdcdc;
    border-radius: 4px;
    background: #f7fcfc;
    margin-right: 40px;
    margin-bottom: 50px;
    text-align: left;
    padding: 20px 20px;
    width: 230px;
}
.page_btns button:hover{
    border: 1px solid #0a8080;
}

.page_btns button img {
    width: 40px;
    margin-bottom: 15px;
}
.page_btns button .page_btn_title {
    font-size: 15px;
    font-weight: 400;
    color: #6C6C72;
    margin-bottom: -7px;
}
.page_btns button .page_btn_subtitle {
    font-size: 40px;
    font-weight: 500;
}

.page table {
    width: 100%;
}

.page th {
    background: #fbfafa;
    color: #6c6c72;
    padding: 10px 10px;
    border-bottom: 1px solid #eaeaea;
}
.page td {
    background: white;
    color: #1c1c1c;
    padding: 20px 10px;
    border-bottom: 1px solid #eaeaea;
}
.page td a {
    color: #0a8080;
}


    </style>
</head>
<body>

<?php
  include '../../components/nav/index.php';
?>
    <div class="main">
        <?php
        include '../../components/menu/index.html';
      ?>

    <div class="page">

        <div class="page_nav">
            <div class="page_left">
                <div class="page_title">Contacts</div>
                <div class="page_subtitle">Your audience has 2 contacts. 1 of these is subscribed.</div>
            </div>
            <div class="right">
                <button>Add Contact</button>
            </div>
        </div>    

        <div class="page_tabs">
            <button onclick="window.location.href='../'">Audience</button>
            <button onclick="window.location.href='../tags'">Tags</button>
            <button class="button_active">Contacts</button>
        </div>

        
        <div class="page_subtitle">Insights</div>
    
        <div class="page_btns">
            <button>
                <img src="https://app.gusto.com/assets/packs/gusto-workbench/619883d5e0f18f1b.svg">
                <div class="page_btn_title">Subscribed</div>
                <div class="page_btn_subtitle">100</div>
            </button>
            
            <button>
                <img src="https://app.gusto.com/assets/packs/gusto-workbench/619883d5e0f18f1b.svg">
                <div class="page_btn_title">New subscribers (30 days)</div>
                <div class="page_btn_subtitle">100</div>
            </button>
            
            <button>
                <img src="https://app.gusto.com/assets/packs/gusto-workbench/619883d5e0f18f1b.svg">
                <div class="page_btn_title">Subscriber growth (30 days)</div>
                <div class="page_btn_subtitle">100%</div>
            </button>  

            <button>
                <img src="https://app.gusto.com/assets/packs/gusto-workbench/619883d5e0f18f1b.svg">
                <div class="page_btn_title">Unsubscribed</div>
                <div class="page_btn_subtitle">0</div>
            </button>
    
        </div>

        <table>
            <tr>
              <th>Email address</th>
              <th>First name</th>
              <th>Last name</th>
              <th>Company name</th>
              <th>Email status</th>
              <th>Source</th>
              <th>Date added</th>
              <th></th>
            </tr>
            <tr>
              <td><a href="">dhirajkadam@gmail.com</a></td>
              <td>Dhiraj</td>
              <td>Kadam</td>
              <td>Aadharpay</td>
              <td>Subscribed</td>
              <td>Added by you</td>
              <td>Feb 27, 2024</td>
              <td><i class="bi bi-three-dots"></i></td>
            </tr>
            <tr>
            <tr>
              <td><a href="">dhirajkadam@gmail.com</a></td>
              <td>Dhiraj</td>
              <td>Kadam</td>
              <td>Aadharpay</td>
              <td>Subscribed</td>
              <td>Added by you</td>
              <td>Feb 27, 2024</td>
              <td><i class="bi bi-three-dots"></i></td>
            </tr>
          </table>

    </div>

</div>
 
</body>
</html>