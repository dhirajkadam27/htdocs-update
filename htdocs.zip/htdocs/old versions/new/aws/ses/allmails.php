<?php
require 'vendor/autoload.php';

use Aws\Ses\SesClient;


// Initialize SES client
$sesClient = new SesClient([
    'version' => 'latest',
    'region' => 'eu-north-1', // e.g., 'us-east-1'
    'credentials' => [
        'key' => 'AKIA6ODU7TL7BZX2TMCR',
        'secret' => 'WjfYQjkPx8I05rogBrIrekyY+Tc2jC65UP172zzz',
    ],
]);



// Function to retrieve list of emails with IDs
function getEmailList($sesClient) {
    try {
        $result = $sesClient->listCustomVerificationEmailTemplates();
        
        return $result->get('CustomVerificationEmailTemplates');
    } catch (AwsException $e) {
        echo $e->getMessage();
        return [];
    }
}

// Example usage
$emailList = getEmailList($sesClient);

// Output the list of emails with IDs
foreach ($emailList as $email) {
    echo "Email: " . $email['TemplateName'] . ", ID: " . $email['TemplateId'] . "<br>";
}
?>