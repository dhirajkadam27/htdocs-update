<?php

// Include the AWS SDK for SES
require 'vendor/autoload.php';

use Aws\Ses\SesClient;
use Aws\Exception\AwsException;

// Initialize AWS SES client
$sesClient = new SesClient([
    'version' => 'latest',
    'region' => 'eu-north-1', // e.g., 'us-east-1'
    'credentials' => [
        'key' => 'AKIA6ODU7TL7BZX2TMCR',
        'secret' => 'WjfYQjkPx8I05rogBrIrekyY+Tc2jC65UP172zzz',
    ],
]);

// Sender's email address
$senderEmail = 'abcdwebtesting@gmail.com';

// Email subject
$subject = 'Your Email Subject';

// Email HTML template
$htmlBody = '<html>
<head></head>
<body>
    <h1>Your Email Heading</h1>
    <p>Your email content goes here.</p>
</body>
</html>';

// List of recipient email addresses
$recipientEmails = ['dhirajkadam.official@gmail.com'];

// Send email to each recipient
foreach ($recipientEmails as $recipientEmail) {
    try {
        $result = $sesClient->sendEmail([
            'Destination' => [
                'ToAddresses' => [
                    $recipientEmail,
                ],
            ],
            'Message' => [
                'Body' => [
                    'Html' => [
                        'Charset' => 'UTF-8',
                        'Data' => $htmlBody,
                    ],
                ],
                'Subject' => [
                    'Charset' => 'UTF-8',
                    'Data' => $subject,
                ],
            ],
            'Source' => $senderEmail,
        ]);

        
        echo "Email sent to $recipientEmail\n";
    } catch (AwsException $e) {
        echo $e->getMessage() . "\n";
    }
}
?>
