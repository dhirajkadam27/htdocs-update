<?php

// Replace with your details
$hostname = '{imap.gmail.com:993/imap/ssl}'; // e.g., '{imap.gmail.com:993/imap/ssl}'
$username = 'abcdwebtesting@gmail.com';
$password = 'firgfzvglkasidzf';
$message_number = 120; // Replace with the desired email sequence number

$inbox = imap_open($hostname, $username, $password) or die("can't connect: " . imap_last_error());

// Check if message number exists
$num_messages = imap_num_msg($inbox);
if ($message_number > $num_messages) {
  die("Error: Message number $message_number does not exist.");
}

// Fetch complete email structure (headers and body)
$structure = imap_fetchstructure($inbox, $message_number);

// Get text body (plain text if possible)
$body = get_imap_body($inbox, $message_number, $structure);

// Alternatively, get HTML body (if available)
// $body = get_imap_html_body($inbox, $message_number, $structure);

// Function to extract plain text body
function get_imap_body($inbox, $message_number, $structure) {
  $text = "";
  if ($structure->type == TYPEMULTIPART) {
    foreach ($structure->parts as $part) {
      if ($part->subtype == "PLAIN") {
        print_r($part);
        $text = imap_fetchbody($inbox, $message_number, $part->number);
        // Decode message body (optional based on encoding)
        $text = imap_qprint($text);
        break;
      }
    }
  } else {
    // Handle non-multipart messages
    $text = imap_fetchbody($inbox, $message_number, 1);
    // Decode message body (optional based on encoding)
    $text = imap_qprint($text);
  }
  return $text;
}

// Function to extract HTML body (if multipart/alternative exists)
function get_imap_html_body($inbox, $message_number, $structure) {
  $html = "";
  if ($structure->type == TYPEMULTIPART) {
    foreach ($structure->parts as $part) {
      if ($part->subtype == "HTML") {
        $html = imap_fetchbody($inbox, $message_number, $part->number);
        break;
      }
    }
  }
  return $html;
}

// Display email body
echo "Email Body:\n";
echo $body;

// Close connection
imap_close($inbox);

?>
