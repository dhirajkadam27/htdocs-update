<?php

use Aws\Ses\SesClient;

// Replace with your credentials (store securely)
$accessKeyId = "AKIA6ODU7TL7PLQ6T4HM";
// $accessKeyId = "ses-smtp-user.20240408-154750";
$secretAccessKey = "BMcbBUm/qsJo1G+NlzQPcn6VM3u7O7wfRO8sbigqqXk0";
$region = "us-east-1"; // Replace with your desired region

$ses = new SesClient([
    'version' => 'latest',
    'region' => $region,
    'credentials' => [
        'key' => $accessKeyId,
        'secret' => $secretAccessKey
    ]
]);


?>