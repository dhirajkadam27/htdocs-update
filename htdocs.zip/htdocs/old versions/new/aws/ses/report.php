<?php

require 'vendor/autoload.php';

use Aws\Ses\SesClient;
use Aws\Exception\AwsException;

// Initialize SES client
$client = new SesClient([
    'version' => 'latest',
    'region' => 'eu-north-1', // e.g., 'us-east-1'
    'credentials' => [
        'key' => 'AKIA6ODU7TL7BZX2TMCR',
        'secret' => 'WjfYQjkPx8I05rogBrIrekyY+Tc2jC65UP172zzz',
    ],
]);

// Get delivery statistics
try {
    $result = $client->getSendStatistics();
    
    // Extract relevant data from the result
    $statistics = $result['SendDataPoints'];

     print_r($result);
    // Display the statistics in HTML
    echo "<h1>Email Delivery Statistics</h1>";
    echo "<table border='1'>";
    echo "<tr><th>Date</th><th>Delivery Attempts</th><th>Rejects</th><th>Bounces</th><th>Complaints</th></tr>";
    foreach ($statistics as $dataPoint) {
        echo "<tr>";
        echo "<td>{$dataPoint['Timestamp']}</td>";
        echo "<td>{$dataPoint['DeliveryAttempts']}</td>";
        echo "<td>{$dataPoint['Rejects']}</td>";
        echo "<td>{$dataPoint['Bounces']}</td>";
        echo "<td>{$dataPoint['Complaints']}</td>";
        echo "</tr>";
    }
    echo "</table>";
} catch (AwsException $e) {
    echo $e->getMessage();
}

?>


