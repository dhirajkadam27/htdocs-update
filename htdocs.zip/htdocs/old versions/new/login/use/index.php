<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "toggle";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$wrong = false;
$done = false;
$create = false;
$field = false;


if (
    isset($_POST["email"]) &&
    isset($_POST["password"]) &&
    !empty($_POST["email"]) &&
    !empty($_POST["password"])
) {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $user_sql = "SELECT userid, password FROM user WHERE email='$email'";
    $user_result = $conn->query($user_sql);

    if ($user_result->num_rows > 0) {
        // output data of each row
            while ($user_row = $user_result->fetch_assoc()) {
        if($user_row["password"]==$password){

            $company_sql = "SELECT recordid,userid, companyid FROM users WHERE email='$email'";
    $company_result = $conn->query($company_sql);

    if ($company_result->num_rows > 0) {
        // output data of each row
            while ($company_row = $company_result->fetch_assoc()) {
                

            $_SESSION['userid'] = $user_row["userid"];
            $_SESSION['recordid'] = $company_row['recordid'];
            $_SESSION['companyid'] = $company_row['companyid'];
            $done = true;
            }

        } else {
            $create = true;
        }


        }else{
            $wrong = true;
        }
    }
    } else {
      
            $create = true;
    }
    $conn->close();
} else {
    $field = true;
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle | Account Setting Up</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&display=swap" rel="stylesheet">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&display=swap" rel="stylesheet">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400..800;1,400..800&display=swap" rel="stylesheet">

    <style>
           body{
            margin: 0;
            padding: 0;
            font-family: "Outfit", sans-serif;
            font-optical-sizing: auto;
            font-weight: 400;
            font-style: normal;
            color: #222525;
        }
        .garamond {
        font-family: "EB Garamond", serif;
        font-optical-sizing: auto;
        font-weight: 300;
        font-style: normal;
        }


button {
    border: none;
    font-family: "Outfit", sans-serif;
    background: #f8f5f2;
    font-size: 15px;
    font-weight: 500;
    cursor: pointer;
}
button:active{
    transform: scale(0.9);
}

img {
    width: 300px;
    margin: 20px auto;
    display: block;
}
 .title {
    font-size: 48px;
    font-weight: 500;
    text-align: center;
    margin: 5px auto;
    line-height: normal;
    width: 60%;
}

 .subtitle {
    font-size: 18px;
    font-weight: 400;
    text-align: center;
    width: 55%;
    margin: 25px auto;
    line-height: 35px;
    margin-top: 20px;
}
.red{
    color: #ff5c5c;
}

button#restart {
    display: block;
    padding: 12px 20px;
    margin: 30px auto;
    border-radius: 5px;
    background: #f45d48;
    color: white;
}
button#restart:hover {
    background: #f66753;
}

    </style>
</head>
<body>



<?php
        if($done){
            echo '
            <img src="https://cdn.dribbble.com/users/826577/screenshots/3146242/piggy-walking-with-umbrella-whitebg-3.gif">
                <div class="title garamond" id="title">Setting up your Toggle account</div>
                <div class="subtitle" id="subtitle">Setting up your Toggle account Setting up your Toggle account</div>
                <script>
                setTimeout(() => {
                    window.location.href="../../app";
                }, 1000);
                </script>
                ';
        }

        
        if($wrong){
            echo ' <img src="https://cdn.dribbble.com/users/1201194/screenshots/17332931/media/065f72f156b25dc71536197f0cfdf597.gif">
            <div class="title garamond red" id="title">Wrong Credientials</div>
            <div class="subtitle" id="subtitle">Setting up your Toggle account Setting up your Toggle account</div>
            <button id="restart" onclick="window.location.href='."'".'../'."'".'">Restart</button>';
        }
        
        if($field){
            echo ' <img src="https://cdn.dribbble.com/users/1201194/screenshots/17332931/media/065f72f156b25dc71536197f0cfdf597.gif">
            <div class="title garamond red" id="title">Some Fields are empty</div>
            <div class="subtitle" id="subtitle">Setting up your Toggle account Setting up your Toggle account</div>
            <button id="restart" onclick="window.location.href='."'".'../'."'".'">Restart</button>';
        }

        
        if($create){
            echo '<img src="https://cdn.dribbble.com/users/1201194/screenshots/17189908/media/db730d7e70e70462d70fcbdc2de9a9d7.gif">
            <div class="title garamond" id="title">Account not exists</div>
            <div class="subtitle" id="subtitle">Setting up your Toggle account Setting up your Toggle account</div>
            <button id="restart" onclick="window.location.href='."'".'../../invite/company'."'".'">Create new account</button>';
        }
        ?>

    
    
    

</body>
</html>