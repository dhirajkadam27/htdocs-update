<?php

session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "toggle";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = false;
$done = false;
$present = false;
$field = false;


function generateUniqueUsername($firstName) {
    // Convert the first name to lowercase
    $username = strtolower($firstName);

    // Append a random number to the username to make it unique
    $username .= rand(1000, 9999);

    return $username;
}

if(isset($_POST['firstname']) && !empty($_POST['firstname']) && isset($_POST['lastname']) && !empty($_POST['lastname']) && isset($_POST['email']) && !empty($_POST['email']) && isset($_POST['password']) && !empty($_POST['password']) && isset($_POST['companyname']) && !empty($_POST['companyname'])){
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $username = generateUniqueUsername($firstname);
    $password = $_POST['password'];
    $companyname = $_POST['companyname'];

        // Start transaction
        $conn->begin_transaction();

        try {
            // Check if email already exists in users table
            $check_email_query = "SELECT * FROM user WHERE email = '$email'";
            $result = $conn->query($check_email_query);
    
            if ($result->num_rows == 0) {
                // Insert user
                $insert_user_query = "INSERT INTO user (firstname, lastname, email,username,password) VALUES ('$firstname','$lastname', '$email','$username','$password')";
                $conn->query($insert_user_query);
    
    
                // Retrieve inserted user ID
                $userid = $conn->insert_id;
    
                // Insert organization
                $insert_company_query = "INSERT INTO company (name) VALUES ('$companyname')";
                $conn->query($insert_company_query);
                
                // Retrieve inserted user ID
                $companyid = $conn->insert_id;
    
                 // Insert organization
                 $insert_users_query = "INSERT INTO users (userid,companyid,firstname,lastname,email,status,role) VALUES ('$userid','$companyid','$firstname','$lastname','$email','Active','Owner')";
                 $conn->query($insert_users_query);
                 
                 // Retrieve inserted user ID
                 $recordid = $conn->insert_id;
    
                // Commit transaction
                $conn->commit();
    
                $_SESSION['userid'] = $userid;
                $_SESSION['companyid'] = $companyid;
                $_SESSION['recordid'] = $recordid;
                $done = true;
            } else {
               $present = true;
            }
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            echo $e;
            $error = true;
        }
    
        // Close connection
        $conn->close();

}else{
    $field = true;
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle | Account Setting Up</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&display=swap" rel="stylesheet">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400..700&display=swap" rel="stylesheet">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400..800;1,400..800&display=swap" rel="stylesheet">

    <style>
           body{
            margin: 0;
            padding: 0;
            font-family: "Outfit", sans-serif;
            font-optical-sizing: auto;
            font-weight: 400;
            font-style: normal;
            color: #222525;
        }
        .garamond {
        font-family: "EB Garamond", serif;
        font-optical-sizing: auto;
        font-weight: 300;
        font-style: normal;
        }


button {
    border: none;
    font-family: "Outfit", sans-serif;
    background: #f8f5f2;
    font-size: 15px;
    font-weight: 500;
    cursor: pointer;
}
button:active{
    transform: scale(0.9);
}

img {
    width: 300px;
    margin: 20px auto;
    display: block;
}
 .title {
    font-size: 48px;
    font-weight: 500;
    text-align: center;
    margin: 5px auto;
    line-height: normal;
    width: 60%;
}

 .subtitle {
    font-size: 18px;
    font-weight: 400;
    text-align: center;
    width: 55%;
    margin: 25px auto;
    line-height: 35px;
    margin-top: 20px;
}
.red{
    color: #ff5c5c;
}

button#restart {
    display: block;
    padding: 12px 20px;
    margin: 30px auto;
    border-radius: 5px;
    background: #f45d48;
    color: white;
}
button#restart:hover {
    background: #f66753;
}

    </style>
</head>
<body>



<?php
        if($done){
            echo '
            <img src="https://cdn.dribbble.com/users/826577/screenshots/3146242/piggy-walking-with-umbrella-whitebg-3.gif">
                <div class="title garamond" id="title">Setting up your Toggle account</div>
                <div class="subtitle" id="subtitle">Setting up your Toggle account Setting up your Toggle account</div>
                <script>
                setTimeout(() => {
                    window.location.href="../../../app";
                }, 1000);
                </script>
                ';
        }

        
        if($error){
            echo ' <img src="https://cdn.dribbble.com/users/1201194/screenshots/17332931/media/065f72f156b25dc71536197f0cfdf597.gif">
            <div class="title garamond red" id="title">Something went Wrong</div>
            <div class="subtitle" id="subtitle">Setting up your Toggle account Setting up your Toggle account</div>
            <button id="restart" onclick="window.location.href='."'".'../'."'".'">Restart</button>';
        }
        
        if($field){
            echo ' <img src="https://cdn.dribbble.com/users/1201194/screenshots/17332931/media/065f72f156b25dc71536197f0cfdf597.gif">
            <div class="title garamond red" id="title">Some Fields are empty</div>
            <div class="subtitle" id="subtitle">Setting up your Toggle account Setting up your Toggle account</div>
            <button id="restart" onclick="window.location.href='."'".'../'."'".'">Restart</button>';
        }

        
        if($present){
            echo '<img src="https://cdn.dribbble.com/users/1201194/screenshots/17189908/media/db730d7e70e70462d70fcbdc2de9a9d7.gif">
            <div class="title garamond" id="title">User Aready Created</div>
            <div class="subtitle" id="subtitle">Setting up your Toggle account Setting up your Toggle account</div>
            <button id="restart" onclick="window.location.href='."'".'../../../login'."'".'">Login</button>';
        }
        ?>

    
    
    

</body>
</html>