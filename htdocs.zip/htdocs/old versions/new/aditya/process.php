<?php
// Check if file is uploaded successfully
if ($_FILES['excelFile']['error'] == UPLOAD_ERR_OK && is_uploaded_file($_FILES['excelFile']['tmp_name'])) {
    // Get file details
    $fileTmpPath = $_FILES['excelFile']['tmp_name'];
    $fileName = $_FILES['excelFile']['name'];

    // Check if it's an Excel file
    $allowedExtensions = array("xls", "xlsx");
    $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    if (in_array($fileExtension, $allowedExtensions)) {
        // Open the Excel file for reading
        $excelReader = fopen($fileTmpPath, "r");

        // Placeholder to store data
        $data = array();

        // Read the file line by line
        while (($row = fgetcsv($excelReader)) !== false) {
            // Add each row to the data array
            $data[] = $row;
        }

        fclose($excelReader);

        // Output data in text format
        $response = "Excel File: $fileName\n\n";
        // Data
        foreach ($data as $row) {
            foreach ($row as $cell) {
                $response .= $cell . "\t";
            }
            $response .= "\n";
        }
    } else {
        $response = "Error: Invalid file format. Please upload an Excel file.";
    }
} else {
    $response = "Error uploading file.";
}

// Set content type for text
header('Content-Type: text/plain');

// Output response
echo $response;
?>
