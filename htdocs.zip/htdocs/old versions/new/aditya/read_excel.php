<?php
$excelFile = 'data.xlsx'; // Change this to your Excel file name
if (file_exists($excelFile)) {
    $excelData = [];
    if (($handle = fopen($excelFile, "r")) !== false) {
        while (($data = fgetcsv($handle, 1000, ",")) !== false) {
            $excelData[] = $data;
        }
        fclose($handle);
    }
    foreach ($excelData as $row) {
        echo "<tr>";
        foreach ($row as $cell) {
            echo "<td>$cell</td>";
        }
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='3'>File not found.</td></tr>";
}
?>
