<?php

session_start();
include "config.php";

// Set the default timezone
date_default_timezone_set('UTC');

// Get the current timestamp
$current_timestamp = time();
$current_timestamp = date("Y-m-d H:i:s", $current_timestamp);

if (
    isset($_POST["email"]) &&
    isset($_POST["name"]) &&
    isset($_POST["organization"]) &&
    !empty($_POST["email"]) &&
    !empty($_POST["name"]) &&
    !empty($_POST["organization"])
) {
    $email = $_POST["email"];
    $name = $_POST["name"];
    $organization = $_POST["organization"];

    // Start transaction
    $conn->begin_transaction();

    try {
        // Check if email already exists in users table
        $check_email_query = "SELECT * FROM users WHERE email = '$email'";
        $result = $conn->query($check_email_query);

        if ($result->num_rows == 0) {
            // Insert user
            $insert_user_query = "INSERT INTO users (name, email) VALUES ('$name', '$email')";
            $conn->query($insert_user_query);


            // Retrieve inserted user ID
            $userid = $conn->insert_id;

            // Insert organization
            $insert_org_query = "INSERT INTO organizations (name) VALUES ('$organization')";
            $conn->query($insert_org_query);
            
            // Retrieve inserted user ID
            $orgid = $conn->insert_id;

             // Insert organization
             $insert_roles_query = "INSERT INTO manageroles (data) VALUES ('sd')";
             $conn->query($insert_roles_query);
             
             // Retrieve inserted user ID
             $manageroleid = $conn->insert_id;

            // Insert organization
            $insert_musers_query = "INSERT INTO manageusers (userid,organizationid,name,email,status,roleid,lastlogin,created) VALUES ('$userid','$orgid','$name','$email','Active','$manageroleid','$current_timestamp','$current_timestamp')";
            $conn->query($insert_musers_query);
            
            // Retrieve inserted user ID
            $manageuserid = $conn->insert_id;

            // Commit transaction
            $conn->commit();

            $_SESSION['userid'] = $userid;
            $_SESSION['orgid'] = $orgid;
            $_SESSION['muser'] = $manageuserid;
            $_SESSION['roleid'] = $manageroleid;
            $response = [
                "status" => "true",
                "data" => "user and organization created successfully",
                "statuscode" => "DJS"
            ];
        } else {
            $response = [
                "status" => "false",
                "data" => "user already present",
                "statuscode" => "SDSD"
            ];
        }
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        $response = [
            "status" => "false",
            "data" => "Unable to create users",
            "statuscode" => "LKKM"
        ];
    }

    // Close connection
    $conn->close();
} else {
    $response = [
        "status" => "false",
        "data" => "Some Fields are empty",
        "statuscode" => "POOOK"
    ];
}

// Convert the array to JSON format
$json_response = json_encode($response);

// Echo the JSON response
echo $json_response;

?>
