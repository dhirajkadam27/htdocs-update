<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include "config.php";

$userid = $_SESSION['userid'];
$sql = "SELECT name,username,email FROM users WHERE userid=$userid";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $name = $row['name'];
    $u_username = $row['username'];
    $email = $row['email'];
  }
} else {
  echo "0 results";
}
$conn->close();

?>
