<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include "config.php";

$organizationid = $_SESSION['orgid'];
$sql = "SELECT organizationid,name,phone,country,state,address1,address2,code,town FROM organizations WHERE organizationid=$organizationid";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $org_name = $row['name'];
    $org_phone = $row['phone'];
    $org_country = $row['country'];
    $org_state = $row['state'];
    $org_address1 = $row['address1'];
    $org_address2 = $row['address2'];
    $org_code = $row['code'];
    $org_town = $row['town'];
  }
} else {
  echo "0 results";
}
$conn->close();

?>
