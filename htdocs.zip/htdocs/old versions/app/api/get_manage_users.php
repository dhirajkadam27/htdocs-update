<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include "config.php";

$organizationid = $_SESSION['orgid'];
$mn_sql = "SELECT userid,name,email,status,roleid,lastlogin,created FROM manageusers WHERE organizationid=$organizationid";
$mn_result = $conn->query($mn_sql);


$conn->close();

?>
