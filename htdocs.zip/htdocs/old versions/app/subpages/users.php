<?php
   include "../api/get_manage_users.php";
?>
<div class="users_nav">
    <div class="txt">Manage users</div>
    <button onclick="invite_user_popup()">Add users</button>
</div>

<table class="users">
    <tr>
      <th>Name</th>
      <th>Email</th>
      <th>Status</th>
      <th>User Role</th>
      <th>Last Login</th>
      <th></th>
    </tr>
    <?php
if ($mn_result->num_rows > 0) {
  // output data of each row
  while($mn_row = $mn_result->fetch_assoc()) {

    echo ' <tr>
    <td>'.$mn_row['name'].'</td>
    <td>'.$mn_row['email'].'</td>
    <td>'.$mn_row['status'].'</td>
    <td>'.$mn_row['roleid'].'</td>
    <td>'.$mn_row['lastlogin'].'	</td>
    <td><span class="material-symbols-outlined">
      more_vert
      </span></td>
  </tr>';
  }
} else {
  echo "0 results";
}

?>
   
  </table>