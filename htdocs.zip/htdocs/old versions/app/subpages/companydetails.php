<?php
   include "../api/get_org.php";
?>
<div class="companydetails_nav">
    <div class="txt">Details</div>
</div>

<div class="companydetails_form">
    <div class="label">Business name</div>
    <input type="text" value="<?php echo $org_name ?>">
    <div class="label">Business Phone number</div>
    <input type="text" value="<?php echo $org_phone ?>">
    <button>Save</button>
</div>

<div class="companydetails_nav">
    <div class="txt">Address</div>
</div>

<div class="companydetails_form">
    <div class="label">Country</div>
    <input type="text" value="<?php echo $org_country ?>">
    <div class="label">State/province</div>
    <input type="text" value="<?php echo $org_state ?>">
    <div class="label">Street address</div>
    <input type="text" value="<?php echo $org_address1 ?>">
    <div class="label">Address line 2</div>
    <input type="text" value="<?php echo $org_address2 ?>">
    <div class="label">Zip code</div>
    <input type="text" value="<?php echo $org_code ?>">
    <div class="label">city town</div>
    <input type="text" value="<?php echo $org_town ?>">
    <button>Save</button>
</div>
