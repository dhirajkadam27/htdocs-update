<?php
   include "../api/get_user.php";
?>
<div class="myprofile_nav">
    <div class="txt">Basic Information</div>
</div>

<div class="myprofile_form">
    <div class="label">Username</div>
    <input type="text" value="<?php echo $u_username ?>">
    <div class="label">Full Name</div>
    <input type="text" value="<?php echo $name ?>">
    <div class="label">Email address</div>
    <input type="text" value="<?php echo $email ?>">
    <button>Save</button>
</div>

<div class="myprofile_nav">
    <div class="txt">Change password</div>
</div>

<div class="myprofile_form">
    <div class="label">Verify current password</div>
    <input type="text">
    <div class="label">New password</div>
    <input type="text">
    <div class="label">Confirm new password</div>
    <input type="text">
    <button>Save</button>
</div>