<?php
   include "api/get_user.php";
   include "api/get_org.php";
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    
    <script src="http://code.jquery.com/jquery.js"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="/app/css/home.css">
    <link rel="stylesheet" href="/app/css/Campaigns.css">
    <link rel="stylesheet" href="/app/css/contact.css">
    <link rel="stylesheet" href="/app/css/lists.css">
    <link rel="stylesheet" href="/app/css/tags.css">
    <link rel="stylesheet" href="/app/css/contacts.css">
    <link rel="stylesheet" href="/app/css/reports.css">
    <link rel="stylesheet" href="/app/css/account.css">
    <link rel="stylesheet" href="/app/css/myprofile.css">
    <link rel="stylesheet" href="/app/css/companydetails.css">
    <link rel="stylesheet" href="/app/css/users.css">
    <link rel="stylesheet" href="/app/css/roles.css">
    <link rel="stylesheet" href="/app/css/popups.css">
   <style>
      body {
        font-family: "Outfit", sans-serif;
        margin: 0;
        padding: 0;
        display: flex;
        color: #232323;
      }

      button:active {
        transform: scale(0.9);
      }

      .material-symbols-outlined {
        font-variation-settings:
          'FILL'0,
          'wght'300,
          'GRAD'0,
          'opsz'24
      }

      .left_slider {
        width: 200px;
        height: 100vh;
        border-left: 10px solid #E87B2C;
        background: #fdfdfd;
    border-right: 1px solid #dbdbdb;
      }

      .right_body {
        width: -webkit-fill-available;
        height: 100vh;
        overflow: hidden;
        position: relative;
      }

      .top_nav {
        width: 100%;
        height: 50px;
        border-bottom: 1px solid #EFEFEF;
        display: flex;
        align-items: center;
        justify-content: space-between;
      }

      .left_slider .menu {
        border: none;
        margin: 20px 10px;
        background: none;
        border-radius: 100px;
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        color: #232323;
      }

      .left_slider .menu:hover {
        background: #ffebd9;
      }

      .left_slider .links {
        display: flex;
        align-items: center;
        margin: 10px 10px;
        width: -webkit-fill-available;
        border: none;
        background: none;
        cursor: pointer;
        padding: 10px;
        color: #3D3D3D;
        font-family: "Outfit", sans-serif;
        border-radius: 5px;
      }

      #active_link {
        font-weight: 600;
        background: #fff2e8;
      }

      #active_link .material-symbols-outlined {
        font-variation-settings:
          'FILL'1,
          'wght'300,
          'GRAD'0,
          'opsz'24
      }

      .left_slider .links:hover {
        background: #ffebd9;
      }

      .left_slider .links .txt {
        margin-left: 10px;
      }

      .top_nav .logo {
        font-size: 20px;
        font-weight: 500;
        margin-left: 20px;
        cursor: pointer;
      }

      .top_nav .actions {
        margin-right: 20px;
        display: flex;
        align-items: center;
      }

      .top_nav .actions button {
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0px 10px;
        border-radius: 100px;
        background: none;
        border: 2px solid #E87B2C;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
      }

      .top_nav .actions button span {
        font-size: 20px;
      }

      .top_nav .actions button:nth-child(2) {
        background: #E87B2C;
        color: white;
      }

      .top_nav .actions button:hover {
        opacity: 0.9
      }

      .top_nav .actions button:nth-child(1):hover {
        background: #fff4ea
      }

      .src-popup-container {
        position: absolute;
        bottom: -120vh;
        height: 100vh;
        left: 0;
        width: calc(100% - 40px);
        background-color: white;
        padding: 20px;
        box-shadow: 0px -5px 15px rgba(0, 0, 0, 0.1);
        /* Box shadow to give a raised effect */
        transition: bottom 0.5s ease;
      }

      .profile-popup-container {
        position: absolute;
        top: -340px;
        right: 40px;
        width: 300px;
        background-color: white;
        padding: 15px 0px;
        box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
        transition: bottom 0.5s ease;
        border-radius: 5px;
        border: 1px solid #EFEFEF;
        overflow: hidden;
      }

      .src-nav {
        display: flex;
        align-items: center;
        justify-content: space-between;
      }

      .src-nav .txt {
        font-size: 20px;
        font-weight: 500;
      }

      .src-nav button {
        border: none;
        background: none;
        border-radius: 100px;
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        color: #232323;
      }

      .src-nav button:hover {
        background: #ffebd9;
      }

      .src-popup-container-box {
        display: flex;
        align-items: center;
        padding: 5px 10px;
        border: 1px solid #d8d8d8;
        width: 80%;
        border-radius: 5px;
        margin-top: 15px;
      }

      .src-popup-container-box input {
        width: -webkit-fill-available;
        font-size: 15px;
        font-family: "Outfit", sans-serif;
        border: none;
        color: #232323;
        margin-left: 5px;
        outline: none;
      }

      .profile_info {
        display: flex;
        align-items: center;
        padding: 10px 15px;
      }

      .profile_info .profile_avt {
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: grey;
        background: #E87B2C;
        color: white;
        border-radius: 100px;
        margin-right: 10px;
      }

      .profile_info .profile_data {
        display: block;
      }

      .profile_info .profile_data .txt {
        font-size: 15px;
        font-weight: 500;
        display: block;
        color: #232323;
        text-decoration: none;
      }

      .profile_info .profile_data .com {
        font-size: 12px;
        font-weight: 400;
        display: block;
        color: #232323;
        text-decoration: none;
      }

      .profile_info .profile_data .txt:hover {
        text-decoration: underline;
      }

      .profile_info .profile_data .com:hover {
        text-decoration: underline;
      }

      .profile-popup-container button {
        width: 100%;
        margin: 5px 0px;
        text-align: left;
        font-family: "Outfit", sans-serif;
        font-size: 15px;
        font-weight: 300;
        background: none;
        border: none;
        padding: 7px 15px;
        cursor: pointer;
      }

      .profile-popup-container button:hover {
        background: #ffebd9;
        font-weight: 400;
      }

      .profile_info button {
        position: absolute;
        right: 10px;
        top: 2px;
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 100px;
        margin-left: auto;
      }

      .profile-popup-container button:active {
        transform: scale(1.04);
      }
      #frame {
    width: 100%;
    height: -webkit-fill-available;
    overflow: auto;
    padding-bottom: 100px;
}

#backdrop {
    width: 100%;
    height: 100vh;
    background: #00000008;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 9;
    display: none;
}


div#loader {
  position: absolute;
    top: 50px;
    left: 0;
    width: 100%;
    height: calc(100vh - 50px);
    background: #00000033;
    display: flex;
    align-items: center;
    justify-content: center;
}

div#loader img {
    width: 30px;
}

    </style>
  </head>
  <body onload="loader_hide()">
 
    <div id="left_slider_menu" class="left_slider">
      <button onclick="left_slider_menu()" class="menu">
        <span class="material-symbols-outlined"> menu </span>
      </button>
      <button onclick="left_slider_menu_btns(this,'pages/home.html'),change_url('home',null)" class="links" id="active_link">
        <span class="material-symbols-outlined"> home </span>
        <div class="txt">Home</div>
      </button>
      <button onclick="left_slider_menu_btns(this,'pages/Campaigns.html'),change_url('campaigns',null)" class="links">
        <span class="material-symbols-outlined"> campaign </span>
        <div class="txt">Campaigns</div>
      </button>
      <button onclick="left_slider_menu_btns(this,'pages/contact.html'),change_url('contact','lists');" class="links">
        <span class="material-symbols-outlined"> import_contacts </span>
        <div class="txt">Contact</div>
      </button>
      <button onclick="left_slider_menu_btns(this,'pages/reports.html'),change_url('reports',null)" class="links">
        <span class="material-symbols-outlined"> analytics </span>
        <div class="txt">Reports</div>
      </button>
    </div>
    <div class="right_body">
      <div class="top_nav">
        <div class="logo">Toggle</div>
        <div class="actions">
          <button onclick="srctogglePopup()">
            <span class="material-symbols-outlined"> search </span>
          </button>
          <button onclick="profiletogglePopup()">D</button>
        </div>
      </div>
      <div class="src-popup-container" id="srcpopup">
        <div class="src-nav">
          <div class="txt">Search</div>
          <button onclick="srctogglePopup()">
            <span class="material-symbols-outlined"> close </span>
          </button>
        </div>
        <div class="src-popup-container-box">
          <span class="material-symbols-outlined"> search </span>
          <input type="text" placeholder="Search your query here">
        </div>
      </div>

      <div class="profile-popup-container" id="profilepopup">
        <div class="profile_info">
          <div class="profile_avt"><?php echo $name[0]; ?></div>
          <div class="profile_data">
            <a href="#" class="txt"><?php echo $u_username; ?></a>
            <a href="#" class="com"><?php echo $org_name; ?></a>
          </div>
          <button onclick="profiletogglePopup()">
            <span class="material-symbols-outlined"> close </span>
          </button>
        </div>
        <button onclick="profile_button_menu('pages/account.html','subpages/myprofile.php');change_url('account','profile');">Profile</button>
        <button onclick="profile_button_menu('pages/account.html','subpages/companydetails.php');change_url('account','company');">Account</button>
        <button>Pricing Plans</button>
        <button>Logout</button>
      </div>
      <div id="loader">
      <img src="/loader.gif">
    </div>
      <div id="frame">

      </div>

      <div id="popups">

      </div>

      <div id="backdrop">

      </div>

    </div>
    <script>
      function left_slider_menu() {
        var leftSliderMenu = document.getElementById("left_slider_menu");
        if (leftSliderMenu) {
          var width = leftSliderMenu.offsetWidth;
          if (width <= 100) {
            document.getElementById('left_slider_menu').style.width = '200px';
            document.querySelectorAll("#left_slider_menu .txt").forEach(function(element) {
              element.style.display = "block";
            });
          } else {
            document.getElementById('left_slider_menu').style.width = '70px';
            document.querySelectorAll("#left_slider_menu .txt").forEach(function(element) {
              element.style.display = "none";
            });
          }
        } else {
          console.log("#left_slider_menu not found.");
        }
      }

      function srctogglePopup() {
        var srcpopup = document.getElementById("srcpopup");
        if (srcpopup.style.bottom === "-40px") {
          srcpopup.style.bottom = "-120vh";
        } else {
          srcpopup.style.bottom = "-40px";
        }
      }


      function profiletogglePopup() {
        var profilepopup = document.getElementById("profilepopup");
        if (profilepopup.style.top === "40px") {
          profilepopup.style.top = "-340px";
        } else {
          profilepopup.style.top = "40px";
        }
      }
   
      function generateRandomString(length) {
  var result = '';
  var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  
  return result;
}

      function left_slider_menu_btns(this_btn,url){
        loader_show();
        if(document.getElementById("active_link")){
        document.getElementById("active_link").removeAttribute("id");
        }
        this_btn.setAttribute('id', 'active_link');

        fetch(url+"?q="+generateRandomString(10))
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.text();
      })
      .then(html => {
        console.log('HTML code of the page:', html);
        document.getElementById("frame").innerHTML = html;

        if(url=="pages/contact.html"){
      
      $('.contact_links button').eq(0).click();
          }


          loader_hide()
        // You can further process the HTML code here as needed
      })
      .catch(error => {
        console.error('Error fetching page code:', error);
          loader_hide()
      });

       



      }
  
      function profile_button_menu(url,url2){
        loader_show();
        if(document.getElementById("active_link")){
        document.getElementById("active_link").removeAttribute("id");
        }

        fetch(url+"?q="+generateRandomString(10))
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.text();
      })
      .then(html => {
        console.log('HTML code of the page:', html);
        document.getElementById("frame").innerHTML = html;
        if(url2=="subpages/myprofile.php"){
  $('.account_links button').eq(0).click();
      }else if(url2=="subpages/companydetails.php"){
  $('.account_links button').eq(1).click();
      }
      loader_hide();
        // You can further process the HTML code here as needed
      })
      .catch(error => {
        console.error('Error fetching page code:', error);
      loader_hide();
      });

   

      profiletogglePopup();

      }
  
      function account_button_frame(div, url){
        loader_show();
        if(document.getElementById("active_acccount_link")){
        document.getElementById("active_acccount_link").removeAttribute("id");
        }
        
        
        div.setAttribute('id', 'active_acccount_link');
        
        fetch(url+"?q="+generateRandomString(10))
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.text();
      })
      .then(html => {
        console.log('HTML code of the page:', html);
        document.getElementById("account_frame").innerHTML = html;
        loader_hide()
        // You can further process the HTML code here as needed
      })
      .catch(error => {
        console.error('Error fetching page code:', error);
        loader_hide()
      });

      }

      function contact_button_frame(div,url){
        loader_show();
        if(document.getElementById("active_contact_link")){
        document.getElementById("active_contact_link").removeAttribute("id");
        }
        
        
        div.setAttribute('id', 'active_contact_link');

        fetch(url+"?q="+generateRandomString(10))
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.text();
      })
      .then(html => {
        console.log('HTML code of the page:', html);
        document.getElementById("contact_frame").innerHTML = html;
        loader_hide();
        // You can further process the HTML code here as needed
      })
      .catch(error => {
        console.error('Error fetching page code:', error);
          loader_hide()
      });

      if(url=="subpages/lists.html"){
        document.getElementById('contact_nav_btn_1').style.display = "block";
        document.getElementById('contact_nav_btn_2').style.display = "none";
      }else if(url=="subpages/tags.html"){
        document.getElementById('contact_nav_btn_1').style.display = "none";
        document.getElementById('contact_nav_btn_2').style.display = "block";
      }else{
        document.getElementById('contact_nav_btn_1').style.display = "none";
        document.getElementById('contact_nav_btn_2').style.display = "none";
      }

      }


      fetch("popups/popups.html?q="+generateRandomString(10))
      .then(response => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.text();
      })
      .then(html => {
        console.log('HTML code of the page:', html);
        document.getElementById("popups").innerHTML = html;
        // You can further process the HTML code here as needed
      })
      .catch(error => {
        console.error('Error fetching page code:', error);
      });


      
      function addcontact_popup() {
        var add_contacts_popup = document.getElementById("add_contacts_popup");
        if (add_contacts_popup.style.bottom === "15vh") {
          add_contacts_popup.style.bottom = "-120vh";
        } else {
          add_contacts_popup.style.bottom = "15vh";
        }

        if (document.getElementById("backdrop").style.display === "block") {
          document.getElementById("backdrop").style.display = "none";
        }else{
          document.getElementById("backdrop").style.display = "block";
        }
      }
      
      function addcontact_close(div){
        document.getElementById(div).style.display = "none";
        document.getElementById("add_contacts-popup_frame").style.display = "block";
        addcontact_popup();
      }


      function addcontact_button(div){
        document.getElementById(div).style.display = "block";
        document.getElementById("add_contacts-popup_frame").style.display = "none";

        addRows(10);
      }

      
      function create_campaign_popup_container() {
        var create_campaign_popup_container = document.getElementById("create_campaign_popup_container");
        if (create_campaign_popup_container.style.bottom === "15vh") {
          create_campaign_popup_container.style.bottom = "-120vh";
        } else {
          create_campaign_popup_container.style.bottom = "15vh";
        }

        if (document.getElementById("backdrop").style.display === "block") {
          document.getElementById("backdrop").style.display = "none";
        }else{
          document.getElementById("backdrop").style.display = "block";
        }
      }

      function create_campaign_popup_container_close(){
        document.getElementById("campaign_frame_1").style.display = "block";
        document.getElementById("campaign_frame_2").style.display = "none";
        create_campaign_popup_container();
      }

      function create_campaign_popup_container_btn(){
        document.getElementById("campaign_frame_1").style.display = "none";
        document.getElementById("campaign_frame_2").style.display = "block";
      }



      function create_list_popup() {
        var create_list_popup = document.getElementById("create_list_popup");
        if (create_list_popup.style.bottom === "15vh") {
          create_list_popup.style.bottom = "-120vh";
        } else {
          create_list_popup.style.bottom = "15vh";
        }

        if (document.getElementById("backdrop").style.display === "block") {
          document.getElementById("backdrop").style.display = "none";
        }else{
          document.getElementById("backdrop").style.display = "block";
        }
      }

function create_tag_popup() {
  var create_tag_popup = document.getElementById("create_tag_popup");
  if (create_tag_popup.style.bottom === "15vh") {
    create_tag_popup.style.bottom = "-120vh";
  } else {
    create_tag_popup.style.bottom = "15vh";
  }

  if (document.getElementById("backdrop").style.display === "block") {
    document.getElementById("backdrop").style.display = "none";
  }else{
    document.getElementById("backdrop").style.display = "block";
  }
}


    function addRows(numRows) {
        var tbody = document.getElementById('tbody');
        for (var i = 0; i < numRows; i++) {
            var row = document.createElement('tr');
            var emailCell = document.createElement('td');
            var firstNameCell = document.createElement('td');
            var lastNameCell = document.createElement('td');

            var emailInput = document.createElement('input');
            emailInput.setAttribute('type', 'text');
            emailCell.appendChild(emailInput);

            var firstNameInput = document.createElement('input');
            firstNameInput.setAttribute('type', 'text');
            firstNameCell.appendChild(firstNameInput);

            var lastNameInput = document.createElement('input');
            lastNameInput.setAttribute('type', 'text');
            lastNameCell.appendChild(lastNameInput);

            row.appendChild(emailCell);
            row.appendChild(firstNameCell);
            row.appendChild(lastNameCell);

            tbody.appendChild(row);
        }
    }

    function saveData() {
        // Implement save functionality here
        alert('Data saved successfully!');
    }

    function cancel() {
        // Implement cancel functionality here
        alert('Operation cancelled!');
    }
    
    function add_contacts_link(div,div1,div2){
      if(document.getElementById("active_contact_link_1")){
        document.getElementById("active_contact_link_1").removeAttribute("id");
        }
        
        
        div.setAttribute('id', 'active_contact_link_1');

    document.getElementById(div1).style.display = "block";
    document.getElementById(div2).style.display = "none";
    }

    
    function invite_user_popup() {
        var invite_user_popup = document.getElementById("invite_user_popup");
        if (invite_user_popup.style.bottom === "15vh") {
          invite_user_popup.style.bottom = "-120vh";
        } else {
          invite_user_popup.style.bottom = "15vh";
        }

        if (document.getElementById("backdrop").style.display === "block") {
          document.getElementById("backdrop").style.display = "none";
        }else{
          document.getElementById("backdrop").style.display = "block";
        }
      }

      function add_role_popup(){
        var add_role_popup = document.getElementById("add_role_popup");
        if (add_role_popup.style.bottom === "15vh") {
          add_role_popup.style.bottom = "-120vh";
        } else {
          add_role_popup.style.bottom = "15vh";
        }

        if (document.getElementById("backdrop").style.display === "block") {
          document.getElementById("backdrop").style.display = "none";
        }else{
          document.getElementById("backdrop").style.display = "block";
        }
      }

      function inputfileform(div){
        event.preventDefault();
    $.ajax({
      url:"upload.php",
      method:"POST",
      data:new FormData(div),
      dataType:'json',
      contentType:false,
      cache:false,
      processData:false,
      success:function(data)
      {
        if(data.error != '')
        {
          $('#message').html('<div class="alert alert-danger">'+data.error+'</div>');
        }
        else
        {
          $('#process_area').html(data.output);
          $('#upload_area').css('display', 'none');
        }
      }
    });
      }

      
  var total_selection = 0;

var first_name = 0;

var last_name = 0;

var email = 0;

var column_data = [];

$(document).on('change', '.set_column_data', function(){

  var column_name = $(this).val();

  var column_number = $(this).data('column_number');

  if(column_name in column_data)
  {
    alert('You have already define '+column_name+ ' column');

    $(this).val('');

    return false;
  }

  if(column_name != '')
  {
    column_data[column_name] = column_number;
  }
  else
  {
    const entries = Object.entries(column_data);

    for(const [key, value] of entries)
    {
      if(value == column_number)
      {
        delete column_data[key];
      }
    }
  }

  total_selection = Object.keys(column_data).length;

  if(total_selection == 3)
  {
    $('#import').attr('disabled', false);

    first_name = column_data.first_name;

    last_name = column_data.last_name;

    email = column_data.email;
  }
  else
  {
    $('#import').attr('disabled', 'disabled');
  }

});

$(document).on('click', '#import', function(event){

  event.preventDefault();

  $.ajax({
    url:"import.php",
    method:"POST",
    data:{first_name:first_name, last_name:last_name, email:email},
    beforeSend:function(){
      $('#import').attr('disabled', 'disabled');
      $('#import').text('Importing...');
    },
    success:function(data)
    {
      $('#import').attr('disabled', false);
      $('#import').text('Import');
      $('#process_area').css('display', 'none');
      $('#upload_area').css('display', 'block');
      $('#upload_form')[0].reset();
      $('#message').html("<div class='alert alert-success'>"+data+"</div>");
    }
  })

});

function create_email_campaign(){
  window.location.href = "/app/email"
}

function check_url(){

     // Get the search parameters from the URL
var currentURLparameters = new URLSearchParams(window.location.search);

// Get the value of the 'name' parameter
var pageParameter = currentURLparameters.get('page');
var subpageParameter = currentURLparameters.get('subpage');

// Check if the 'name' parameter exists
if (pageParameter !== null) {
  if(pageParameter=="home"){
  $('#left_slider_menu button').eq(1).click();
  }else if(pageParameter=="campaigns"){
$('#left_slider_menu button').eq(2).click();
  }else if(pageParameter=="contact"){
         // Select the element to observe
var frame = document.getElementById('frame');

// Create a new MutationObserver
var observer = new MutationObserver(function(mutations) {
    // Check if the content has changed
    if(subpageParameter=="lists"){
  $('.contact_links button').eq(0).click();
  observer.disconnect();
    }else if(subpageParameter=="tags"){
  $('.contact_links button').eq(1).click();
  observer.disconnect();
    }else if(subpageParameter=="contacts"){
  $('.contact_links button').eq(2).click();
  observer.disconnect();
    }
});

// Configure the observer to watch for changes in the subtree
var config = { childList: true, subtree: true };

// Start observing the target node for configured mutations
observer.observe(frame, config);

  $('#left_slider_menu button').eq(3).click();
  }else if(pageParameter=="reports"){
  $('#left_slider_menu button').eq(4).click();
  }else if(pageParameter=="account"){

            // Select the element to observe
var frame = document.getElementById('frame');

// Create a new MutationObserver
var observer = new MutationObserver(function(mutations) {

    // Check if the content has changed
    if(subpageParameter=="profile"){
  $('.account_links button').eq(0).click();
  observer.disconnect();
    }else if(subpageParameter=="company"){
  $('.account_links button').eq(1).click();
  observer.disconnect();
    }else if(subpageParameter=="users"){
  $('.account_links button').eq(2).click();
  observer.disconnect();
    }else if(subpageParameter=="roles"){
  $('.account_links button').eq(3).click();
  observer.disconnect();
    }
});

// Configure the observer to watch for changes in the subtree
var config = { childList: true, subtree: true };

// Start observing the target node for configured mutations
observer.observe(frame, config);


    profile_button_menu('pages/account.html',null);
    profiletogglePopup();
  }
} else {
    window.location.href = 'http://localhost/app/?page=home';
}
}
check_url();

function change_url(page,subpage){
// Get the current URL
var currentUrl = window.location.href;
    
    // Create a URLSearchParams object to manipulate query parameters
    var urlParams = new URLSearchParams(window.location.search);

    // Check if the parameter already exists
    if (urlParams.has('page')) {
        // If it exists, update its value
        urlParams.set('page', page);
    } else {
        // If it doesn't exist, add it
        urlParams.append('page', page);
    }

    if(subpage==null){
      urlParams.delete('subpage');
    }else{
       // Check if the parameter already exists
    if (urlParams.has('subpage')) {
        // If it exists, update its value
        urlParams.set('subpage', subpage);
    } else {
        // If it doesn't exist, add it
        urlParams.append('subpage', subpage);
    }
    }

    // Construct the new URL with the updated parameters
    var newUrl = currentUrl.split('?')[0] + '?' + urlParams.toString();

    // Update the URL without reloading the page
    history.pushState({}, '', newUrl);

}

function loader_show(){
        $('#loader').show();
        setTimeout(() => {
          loader_hide();
        }, 10000);
      }
      function loader_hide(){
        $('#loader').hide();
      }
  </script>
  </body>
</html>
