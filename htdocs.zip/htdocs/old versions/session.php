<?php
session_start();
echo $_SESSION['userid'];
echo $_SESSION['orgid'];
echo $_SESSION['muser'];
echo $_SESSION['roleid'];
?>