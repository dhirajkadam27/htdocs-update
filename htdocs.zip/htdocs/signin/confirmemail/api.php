<?php
session_start();
// Include database connection
include '../config.php';

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the email address from the request

    $postData = file_get_contents("php://input");

    // Decode the JSON data
    $requestData = json_decode($postData, true);

    if(isset($requestData['token']) && $requestData['code']){

        $token = $requestData['token'];
        $code = $requestData['code'];

        
         // Check if the email exists in the user_emails table
    $query = "SELECT * FROM emailverificationtoken WHERE token = '$token' AND code = '$code'";
    $result = mysqli_query($connection, $query);

    if(mysqli_num_rows($result) > 0) {
        // Email already exists

        while ($row = mysqli_fetch_assoc($result)) {
            $_SESSION['userid'] = $row['userid'];
        }

         // Perform the delete operation
         $query = "DELETE FROM emailverificationtoken WHERE token = '$token'";
          mysqli_query($connection, $query);

        $response = array('status' => 'success', 'message' => 'done');
        echo json_encode($response);
    } else {
       
        // Prepare response
        $response = array('status' => 'wrong', 'message' => 'Sorry, the email verification code you entered is incorrect.');
        echo json_encode($response);
    }
    }else{
        echo json_encode(array('status' => 'error', 'message' => 'Please enter the email verification code.'));
    }
} else {
    // Method not allowed
    http_response_code(405); // Method Not Allowed
    echo json_encode(array('status' => 'error', 'message' => 'Oops! Something went wrong.'));
}

// Close database connection
mysqli_close($connection);

?>
