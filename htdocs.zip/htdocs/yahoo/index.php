<?php

// Replace these values with your actual client credentials
$client_id = 'dj0yJmk9ZVlmMkZjaWprOU9iJmQ9WVdrOVkyOVhWVVY1YjBRbWNHbzlNQT09JnM9Y29uc3VtZXJzZWNyZXQmc3Y9MCZ4PWNj';
$client_secret = '049ac18345a8bc49de1ae22bb1631af7c11a2fb1';
$redirect_uri = 'https://localhost/yahoo/';
$scope = 'openid email';

// Step 1: Get Authorization Code
if (!isset($_GET['code'])) {
    $authorize_url = 'https://api.login.yahoo.com/oauth2/request_auth?' . http_build_query([
        'client_id' => $client_id,
        'redirect_uri' => $redirect_uri,
        'response_type' => 'code',
        'scope' => $scope,
    ]);

    header('Location: ' . $authorize_url);
    exit();
}

// Step 2: Exchange Authorization Code for Access Token
$token_url = 'https://api.login.yahoo.com/oauth2/get_token';
$params = [
    'code' => $_GET['code'],
    'client_id' => $client_id,
    'client_secret' => $client_secret,
    'redirect_uri' => $redirect_uri,
    'grant_type' => 'authorization_code',
];

$curl = curl_init($token_url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($params));
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($curl);
$result = json_decode($response, true);

if (isset($result['access_token'])) {
    // Step 3: Use Access Token to Access Yahoo Mail API
    $access_token = $result['access_token'];

    // Example API URL for accessing Yahoo Mail message headers
    $api_url = 'https://api.mail.yahoo.com/ws/v3/batch?&crumb=test';
    $request_body = json_encode([
        'requests' => [
            [
                'id' => '1',
                'method' => 'GET',
                'url' => '/ws/v3/batch?X-Yahoo-Client-Request-Id=sample&X-Yahoo-Client-Request-Uri=/v1/messageHeaders/fetchMessages'
            ]
        ]
    ]);

    $curl = curl_init($api_url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $access_token,
        'Content-Type: application/json',
    ]);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $request_body);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($curl);
    $message_headers = json_decode($response, true);
    print_r($response);

    // Process message headers
    if (isset($message_headers['responses'][0]['body']['headers'])) {
        foreach ($message_headers['responses'][0]['body']['headers'] as $header) {
            // Do something with each message header
            echo 'From: ' . $header['From'] . '<br>';
            echo 'Subject: ' . $header['Subject'] . '<br>';
            echo '<hr>';
        }
    } else {
        echo 'No message headers found.';
    }
} else {
    echo 'Failed to obtain access token.';
}
