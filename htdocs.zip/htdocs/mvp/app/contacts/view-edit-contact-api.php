<?php
session_start(); // Start session

// Check if user is logged in
if (!isset($_SESSION['userid']) || !isset($_SESSION['companyid'])) {
    echo "logout";
    exit();
}

$companyid = $_SESSION['companyid'];

// Establish database connection (replace with your database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mvp";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$contactId = $_GET['id'];

$contact_sql = "SELECT * FROM contact WHERE contactid = ?"; // Assuming you want to fetch a campaign for the logged-in user and company
$contact_stmt = $conn->prepare($contact_sql);
$contact_stmt->bind_param("i", $contactId);
$contact_stmt->execute();
$contact_result = $contact_stmt->get_result();

if ($contact_result->num_rows == 1) {
    // Campaign found, fetch campaign data
    $contact = $contact_result->fetch_assoc();
    // Now $campaign variable contains the fetched campaign data
    // print_r($campaign);

    echo '<sl-input value="'.$contact['email'].'" label="Email"></sl-input>
    <sl-input value="'.$contact['firstname'].'" label="First Name"></sl-input>
    <sl-input value="'.$contact['lastname'].'" label="Last Name"></sl-input>
    <sl-select label="Select Audience" value="'.$contact['audienceid'].'">';

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "mvp";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    
    $sql = "SELECT * FROM audience WHERE companyid=$companyid";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
      // output data of each row
      while($row = $result->fetch_assoc()) {
        echo '<sl-option value="'.$row['audienceid'].'">'.$row['name'].'</sl-option>';
      }
    } else {
      echo "0 results";
    }
      echo '</sl-select>
    <sl-button variant="primary">Save</sl-button>';
} else {
    echo "contact not found.";
}

// Close database connection
$conn->close();
?>