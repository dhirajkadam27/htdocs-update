<?php
session_start(); // Start session

// Check if user is logged in
if (!isset($_SESSION['userid']) || !isset($_SESSION['companyid'])) {
    echo "logout";
    exit();
}

// Establish database connection (replace with your database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mvp";

$date = new DateTime();
$formatted_date = $date->format('Y-m-d\TH:i:sO');

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to create a campaign
function createContact($conn, $name, $userId, $companyId) {
    $stmt = $conn->prepare("INSERT INTO audience (name, userid, companyid) VALUES (?, ?, ?)");
    $stmt->bind_param("sii", $name, $userId, $companyId);
    $stmt->execute();
}

// Main logic for campaign creation
if (isset($_GET['name'])) {
    $name = $_GET['name'];
    $userId = $_SESSION['userid'];
    $companyId = $_SESSION['companyid'];
    
    createContact($conn, $name, $userId, $companyId);
    
    echo "done";
} else {
    echo "not";
}

$conn->close();
?>
