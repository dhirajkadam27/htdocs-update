<?php
session_start(); // Start session

// Check if user is logged in
if (!isset($_SESSION['userid']) || !isset($_SESSION['companyid'])) {
    echo "logout";
    exit();
}

// Establish database connection (replace with your database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mvp";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$audienceId = $_GET['id'];
$audiencename = "";

$audience_sql = "SELECT * FROM audience WHERE audienceid = ?"; // Assuming you want to fetch a campaign for the logged-in user and company
$audience_stmt = $conn->prepare($audience_sql);
$audience_stmt->bind_param("i", $audienceId);
$audience_stmt->execute();
$audience_result = $audience_stmt->get_result();

if ($audience_result->num_rows == 1) {
    // Campaign found, fetch campaign data
    $audience = $audience_result->fetch_assoc();
    // Now $campaign variable contains the fetched campaign data
    // print_r($campaign);

    $audiencename = $audience['name'];

} else {
    echo "audience not found.";
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle | App Page</title>
    <!-- open sans google fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap"
        rel="stylesheet">


       
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@shoelace-style/shoelace@2.15.0/cdn/themes/light.css" />
<script type="module" src="https://cdn.jsdelivr.net/npm/@shoelace-style/shoelace@2.15.0/cdn/shoelace-autoloader.js"></script>


<script>

    const ImgToSvg= async (img) => {
      const s = document.createElement('div');
      s.innerHTML = await (await fetch(img.src)).text();
      s.firstChild.classList = img.classList;
      img.replaceWith(s.firstChild)
    }
  </script>

    <style>
        body{
            margin: 0;
            padding: 0;
  font-family: "Open Sans", sans-serif;
  font-size: 15px;
  font-weight: 500;
  width: 100%;
  height: 100vh;
  color: #3E3E3E;
        }
        button{
  font-family: "Open Sans", sans-serif;
  cursor: pointer;
  border: none;
  padding: 0;
  margin: 0;
  background: none;
        } 
        input{
  font-family: "Open Sans", sans-serif;
  cursor: pointer;
  outline-color: #3E3E3E;
  color: #3E3E3E;
        }
        button:hover{
            filter: brightness(0.9);
        }
        button:active{
            transform: scale(0.9);
        }

        .top-nav {
            width: calc(100% - 40px);
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #DBDBDB;
    padding: 0px 20px;
}

.company-logo {
    height: 30px;
    margin: 0px;
    cursor: pointer;
}
.profile-info {
    display: flex;
    align-items: center;
}
.profile-info sl-icon {
    font-size: 25px;
    margin: 0px 10px;
}
.profile-info .txt {
    margin-right: 15px;
}
.profile-info .txt .name {
    font-size: 15px;
    font-weight: 500;
}
.profile-info .txt .email {
    font-size: 13px;
    font-weight: 400;
}

.audience{
    display: flex;
}
.side-nav {
    width: 90px;
    height: calc(100vh - 60px);
    border-right: 1px solid #DBDBDB;
    text-align: center;
}
.side-nav svg{
    width: 30px;
}
.side-nav .active{
    color: #2859C5;
}
.side-nav .active .txt{
    font-weight: 600 !important;
}
.side-nav .active svg{
    fill: #2859c533;
    width: 35px;
}
.side-nav .active svg path{
    stroke: #2859C5;
}
.side-nav button {
    background: white;
    width: 70px;
    height: 70px;
    margin: 10px 0px;
    border-radius: 10px;
}

.side-nav button .txt {
    font-size: 10px;
    font-weight: 500;
}

.audience-main-screen {
    width: calc(100% - 90px);
    height: calc(100vh - 60px);
}


.audience-main-screen sl-breadcrumb {
    display: flex;
    margin: 10px 20px;
}


.audience-back {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 10px auto;
    margin-top: 40px;
    width: 80%;
}

.audience-back  .left{
    display: flex;
    align-items: center;
}

.audience-back .left img {
    height: 25px;
    margin-right: 15px;
}

.audience-back .left .txt {
    display: block;
}
.audience-back .left .txt {
    display: block;
}


.audience-back  .left .name {
    font-size: 15px;
    text-decoration: none;
    font-weight: 600;
    color: #3E3E3E;
}
.audience-back .left .name:hover{
    text-decoration: underline;
    color: #007CC2 !important;
}
.audience-back .left .date {
    font-size: 12px;
    font-weight: 400;
    margin-top: 5px;
}

.audience-back button {
    padding: 10px 15px;
    background: #007CC2;
    font-size: 15px;
    font-weight: 500;
    color: white;
    border-radius: 5px;
}

.section {
    margin: 10px auto;
    margin-top: 40px;
    width: 80%;
    padding-bottom: 50px;
}

.section .title {
    font-size: 15px;
    font-weight: 600;
    margin-bottom: 10px;
}


.section .row {
    display: flex;
    align-items: center;
    margin: 10px auto;
    width: 95%;
    margin-top: 20px;
}

.section .row label {
    width: 200px;
    font-size: 15px;
    font-weight: 500;
}

.section .row input {
    width: 500px;
    padding: 10px 20px;
    font-size: 15px;
    border: 1px solid #DBDBDB;
}

.section .row select {
    width: 500px;
    padding: 10px 20px;
    font-size: 15px;
    border: 1px solid #DBDBDB;
}


.section .row1 {
    display: flex;
    align-items: start;
    margin: 10px auto;
    width: 95%;
    margin-top: 20px;
}

.section .row1 label {
    width: 200px;
    font-size: 15px;
    font-weight: 500;
}

.section .row1 .checkbox {
    display: flex;
    align-items: center;
    margin-bottom: 15px;
}

.section .row1 .checkbox label {
    font-size: 15px;
    font-weight: 500;
    margin-left: 10px;
}

.section .create-template {
    text-align: center;
    margin-top: 30px;
}

.section .create-template img {
    height: 200px;
}

.section .create-template button {
    padding: 10px 15px;
    background: #007CC2;
    font-size: 15px;
    font-weight: 500;
    color: white;
    border-radius: 5px;
    display: block;
    margin: 10px auto;
    margin-top: 20px;
}



#all-contacts-table {
  font-family: "Open Sans", sans-serif;
  border-collapse: collapse;
  width: 90%;
  margin: 20px auto;
  margin-top: 50px;
}

#all-contacts-table td, #all-contacts-table th {
    padding: 15px 10px;
}

#all-contacts-table tr:hover {background-color: #ECEFF1;}

#all-contacts-table th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #ECEFF1;
}
#all-contacts-table tr {
    border: 1px solid #CFD8DC;
    cursor: pointer;
}

#all-contacts-table tr td:nth-child(6){
    width: 30px;
}
#all-contacts-table td img {
    width: 20px;
    display: none;
}
#all-contacts-table tr:hover > td img{
    display: block;
}

#all-contacts-table tr td:nth-child(1):hover{
    color: #007CC2;
    text-decoration: underline;
}


.drawer-scrolling1 label {
    margin-top: 19px !important;
    display: block;
    font-size: 12px;
    font-weight: 500;
}

.drawer-scrolling1 .value {
    font-size: 17px;
    font-weight: 500;
    margin-top: 5px;
}
.drawer-scrolling2 sl-input {
    margin-bottom: 20px;
}
.drawer-scrolling2 sl-select {
    margin-bottom: 20px;
}



    </style>
</head>

<body>

    <div class="top-nav">
        <sl-dropdown>
            <img slot="trigger" class="company-logo" src="../../../home-assets/company-logo.png" alt="Company Profile">
          <sl-menu>
            <sl-menu-item value="cut">Account</sl-menu-item>
            <sl-menu-item value="copy">Settings</sl-menu-item>
            <sl-menu-item value="copy">Invite Users</sl-menu-item>
          </sl-menu>
        </sl-dropdown>

      
    
    <sl-dropdown>
          <sl-icon-button slot="trigger" variant="default" src="../../../home-assets/user-logo.svg" style="font-size: 30px;"></sl-icon-button>
        <sl-menu>
            <div class="profile-info">
                <sl-icon name="person" style="font-size: 20px;"></sl-icon>
                <div class="txt">
                    <div class="name">Dhiraj Kadam</div>
                    <div class="email">dhirajkadam@gmail.com</div>
                </div>
            </div>
            <sl-divider></sl-divider>
            <sl-menu-item value="profile">Profile</sl-menu-item>
          <sl-menu-item value="logout">Logout</sl-menu-item>
        </sl-menu>
      </sl-dropdown>
    </div>

    <div class="audience">

        <div class="side-nav">
            <button onclick="window.location.href='../../../'"><img onload="ImgToSvg(this)" src="../../../home-assets/home-icon.svg" alt="Dashboard Page"><div class="txt">Dashboard</div></button>
            <button onclick="window.location.href='../../../campaign'"><img onload="ImgToSvg(this)" src="../../../home-assets/campaign-icon.svg" alt="Campaigns page"><div class="txt">Campaigns</div></button>
            <button class="active"><img onload="ImgToSvg(this)" src="../../../home-assets/contact-icon.svg" alt="Contacts Page"><div class="txt">Contacts</div></button>
            <button onclick="window.location.href='../../../reports'"><img onload="ImgToSvg(this)" src="../../../home-assets/report-icon.svg" alt="Reports Page"><div class="txt">Reports</div></button>
        </div>
    
        <div class="audience-main-screen">

            <sl-breadcrumb>
                <sl-breadcrumb-item href="./">Home</sl-breadcrumb-item>
                <sl-breadcrumb-item href="./">Contacts</sl-breadcrumb-item>
                <sl-breadcrumb-item href="./">View Audience</sl-breadcrumb-item>
              </sl-breadcrumb>

          <div class="audience-back">
            <div class="left">
                    <sl-icon-button onclick="history.back()" name="arrow-left-short" label="back" style="font-size: 30px;"></sl-icon-button>
                <div class="txt">
                        <a class="name"><?php echo $audiencename; ?></a>
                        <div class="date">Created on - Apr 24, 2024 12:09 AM</div>
                </div>
            </div>
          </div>

          <table id="all-contacts-table">
            <tr>
              <th>Email address</th>
              <th>First name</th>
              <th>Last name</th>
              <th>Source</th>
              <th>Date added</th>
              <th></th>
            </tr>
            <tr>
                <td onclick="view()">dhirajkadam@gmail.com</td>
                <td>Dhiraj</td>
                <td>Kadam</td>
                <td>Added by admin</td>
                <td>Feb 27, 2023</td>
                <td>  
                    <sl-button onclick="edit()" variant="default" size="small" circle>
                    <sl-icon name="three-dots-vertical" label="options"></sl-icon>
                  </sl-button>
                </td>
            </tr>
            <tr>
                <td onclick="view()">dhirajkadam@gmail.com</td>
                <td>Dhiraj</td>
                <td>Kadam</td>
                <td>Added by admin</td>
                <td>Feb 27, 2023</td>
                <td>  
                    <sl-button onclick="edit()" variant="default" size="small" circle>
                    <sl-icon name="three-dots-vertical" label="options"></sl-icon>
                  </sl-button>
                </td>
            </tr>
            <tr>
                <td onclick="view()">dhirajkadam@gmail.com</td>
                <td>Dhiraj</td>
                <td>Kadam</td>
                <td>Added by admin</td>
                <td>Feb 27, 2023</td>
                <td>  
                    <sl-button onclick="edit()" variant="default" size="small" circle>
                    <sl-icon name="three-dots-vertical" label="options"></sl-icon>
                  </sl-button>
                </td>
            </tr>
            <tr>
                <td onclick="view()">dhirajkadam@gmail.com</td>
                <td>Dhiraj</td>
                <td>Kadam</td>
                <td>Added by admin</td>
                <td>Feb 27, 2023</td>
                <td>  
                    <sl-button onclick="edit()" variant="default" size="small" circle>
                    <sl-icon name="three-dots-vertical" label="options"></sl-icon>
                  </sl-button>
                </td>
            </tr>
          </table>
          
        
          <sl-drawer label="View Contact" class="drawer-scrolling1">
            <label>Email</label>
            <div class="value">dhirajkadam@gmail.com</div>
            <label>First Name</label>
            <div class="value">Dhiraj</div>
            <label>Last Name</label>
            <div class="value">Kadam</div>
            <label>Audience</label>
            <div class="value">Hiring q2112</div>
          </sl-drawer>
          <sl-drawer label="Edit Contact" class="drawer-scrolling2">
            <sl-input label="Email"></sl-input>
            <sl-input label="First Name"></sl-input>
            <sl-input label="Last Name"></sl-input><sl-select label="Select Audience" value="option-1">
                <sl-option value="option-1">Hiring 1212kk</sl-option>
                <sl-option value="option-2">Hiring 922j</sl-option>
                <sl-option value="option-3">Hiring 922j</sl-option>
              </sl-select>
            <sl-button variant="primary">Save</sl-button>
            
          </sl-drawer>

                 
          <script>
            

            function edit(){    
            const drawer = document.querySelector('.drawer-scrolling2');
            drawer.show()
            }
            function view(){    
            const drawer = document.querySelector('.drawer-scrolling1');
            drawer.show()
            }
          </script>

     
        </div>

    </div>


</body>

</html>