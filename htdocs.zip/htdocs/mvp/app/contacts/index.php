<?php
session_start(); // Start session

// Check if user is logged in
if (!isset($_SESSION['userid']) || !isset($_SESSION['companyid'])) {
    echo "logout";
    exit();
}
$companyid = $_SESSION['companyid'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle | App Page</title>
    <!-- open sans google fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap"
        rel="stylesheet">

        
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@shoelace-style/shoelace@2.15.0/cdn/themes/light.css" />
<script type="module" src="https://cdn.jsdelivr.net/npm/@shoelace-style/shoelace@2.15.0/cdn/shoelace-autoloader.js"></script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>

    const ImgToSvg= async (img) => {
      const s = document.createElement('div');
      s.innerHTML = await (await fetch(img.src)).text();
      s.firstChild.classList = img.classList;
      img.replaceWith(s.firstChild)
    }
  </script>

    <style>
        body{
            margin: 0;
            padding: 0;
  font-family: "Open Sans", sans-serif;
  font-size: 15px;
  font-weight: 500;
  width: 100%;
  height: 100vh;
  color: #3E3E3E;
        }
        button{
  font-family: "Open Sans", sans-serif;
  cursor: pointer;
  border: none;
  padding: 0;
  margin: 0;
  background: none;
        } 
        input{
  font-family: "Open Sans", sans-serif;
  cursor: pointer;
  outline-color: #3E3E3E;
  color: #3E3E3E;
        }
        button:hover{
            filter: brightness(0.9);
        }
        button:active{
            transform: scale(0.9);
        }


        .top-nav {
            width: calc(100% - 40px);
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #DBDBDB;
    padding: 0px 20px;
}

.company-logo {
    height: 30px;
    margin: 0px;
    cursor: pointer;
}
.profile-info {
    display: flex;
    align-items: center;
}
.profile-info sl-icon {
    font-size: 25px;
    margin: 0px 10px;
}
.profile-info .txt {
    margin-right: 15px;
}
.profile-info .txt .name {
    font-size: 15px;
    font-weight: 500;
}
.profile-info .txt .email {
    font-size: 13px;
    font-weight: 400;
}

.all-contacts{
    display: flex;
}
.side-nav {
    width: 90px;
    height: calc(100vh - 60px);
    border-right: 1px solid #DBDBDB;
    text-align: center;
}
.side-nav svg{
    width: 30px;
}
.side-nav .active{
    color: #2859C5;
}
.side-nav .active .txt{
    font-weight: 600 !important;
}
.side-nav .active svg{
    fill: #2859c533;
    width: 35px;
}
.side-nav .active svg path{
    stroke: #2859C5;
}
.side-nav button {
    background: white;
    width: 70px;
    height: 70px;
    margin: 10px 0px;
    border-radius: 10px;
}

.side-nav button .txt {
    font-size: 10px;
    font-weight: 500;
}

.all-contacts-main-screen {
    width: calc(100% - 90px);
    height: calc(100vh - 60px);
}



.create-btn {
    display: flex;
    align-items: center;
    justify-content: end;
    margin: 20px 50px;
    margin-top: 40px;
}

.all-contacts-main-screen sl-breadcrumb {
    display: flex;
    margin: 10px 20px;
}

#all-contacts-table {
  font-family: "Open Sans", sans-serif;
  border-collapse: collapse;
  width: 90%;
  margin: 20px auto;
  margin-top: 50px;
}

#all-contacts-table td, #all-contacts-table th {
    padding: 15px 10px;
}

#all-contacts-table tr:hover {background-color: #ECEFF1;}

#all-contacts-table th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #ECEFF1;
}
#all-contacts-table tr {
    border: 1px solid #CFD8DC;
    cursor: pointer;
}

#all-contacts-table tr td:nth-child(6){
    width: 30px;
}
#all-contacts-table td img {
    width: 20px;
    display: none;
}
#all-contacts-table tr:hover > td img{
    display: block;
}

#all-contacts-table tr td:nth-child(1):hover{
    color: #007CC2;
    text-decoration: underline;
}


.audience-lists {
    width: 90%;
    margin: 20px auto;
    display: block;
    margin-top: 40px;
    border-top: 1px solid #DBDBDB;
}

.audience-list {
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #DBDBDB;
    padding: 20px 15px;
}

.audience-list-txts {
    display: block;
}

.audience-list-txts .name {
    font-size: 15px;
    text-decoration: none;
    font-weight: 600;
    color: #3E3E3E;
}
.audience-list-txts .name:hover{
    text-decoration: underline;
    color: #007CC2 !important;
}

.audience-list-txts .date {
    font-size: 12px;
    font-weight: 400;
    margin-top: 5px;
}

.audience-list .imgs {
    display: flex;
    align-items: center;
}

.audience-list .imgs sl-icon-button {
    height: 25px;
    margin-right: 20px;
    display: none;
}
.audience-list .imgs sl-icon-button::part(base){
    padding: 0;
}

.audience-list .imgs sl-icon-button:nth-child(3) {
    height: 30px;
    margin: 0;
}

.audience-list:hover >.imgs sl-icon-button {
    display: block;
}

.drawer-scrolling1 label {
    margin-top: 19px !important;
    display: block;
    font-size: 12px;
    font-weight: 500;
}

.drawer-scrolling1 .value {
    font-size: 17px;
    font-weight: 500;
    margin-top: 5px;
}
.drawer-scrolling2 sl-input {
    margin-bottom: 20px;
}
.drawer-scrolling2 sl-select {
    margin-bottom: 20px;
}

.add-new-contact-dialog sl-input{
    margin-bottom: 30px;
}

    </style>
</head>

<body>

    <div class="top-nav">
        <sl-dropdown>
            <img slot="trigger" class="company-logo" src="../home-assets/company-logo.png" alt="Company Profile">
          <sl-menu>
            <sl-menu-item value="cut">Account</sl-menu-item>
            <sl-menu-item value="copy">Settings</sl-menu-item>
            <sl-menu-item value="copy">Invite Users</sl-menu-item>
          </sl-menu>
        </sl-dropdown>

      
    
    <sl-dropdown>
          <sl-icon-button slot="trigger" variant="default" src="../home-assets/user-logo.svg" style="font-size: 30px;"></sl-icon-button>
        <sl-menu>
            <div class="profile-info">
                <sl-icon name="person" style="font-size: 20px;"></sl-icon>
                <div class="txt">
                    <div class="name">Dhiraj Kadam</div>
                    <div class="email">dhirajkadam@gmail.com</div>
                </div>
            </div>
            <sl-divider></sl-divider>
            <sl-menu-item value="profile">Profile</sl-menu-item>
          <sl-menu-item value="logout">Logout</sl-menu-item>
        </sl-menu>
      </sl-dropdown>
    </div>

    <div class="all-contacts">

        <div class="side-nav">
            <button onclick="window.location.href='../'"><img onload="ImgToSvg(this)" src="../home-assets/home-icon.svg" alt="Dashboard Page"><div class="txt">Dashboard</div></button>
            <button onclick="window.location.href='../campaign'"><img onload="ImgToSvg(this)" src="../home-assets/campaign-icon.svg" alt="Campaigns page"><div class="txt">Campaigns</div></button>
            <button class="active"><img onload="ImgToSvg(this)" src="../home-assets/contact-icon.svg" alt="Contacts Page"><div class="txt">Contacts</div></button>
            <button onclick="window.location.href='../reports'"><img onload="ImgToSvg(this)" src="../home-assets/report-icon.svg" alt="Reports Page"><div class="txt">Reports</div></button>
        </div>
    
        <div class="all-contacts-main-screen">

            <sl-breadcrumb>
                <sl-breadcrumb-item href="./">Home</sl-breadcrumb-item>
                <sl-breadcrumb-item href="./">Contacts</sl-breadcrumb-item>
              </sl-breadcrumb>
            
            <sl-tab-group>
                <sl-tab slot="nav" panel="all-contacts">All contacts</sl-tab>
                <sl-tab slot="nav" panel="audience">Audience</sl-tab>
              

                <sl-tab-panel name="all-contacts">

                    <sl-dialog label="Add Contact" class="add-new-contact-dialog">
                        <sl-input id="contact-email" autofocus label="Email"></sl-input>
                        <sl-input id="contact-firstname" label="First Name"></sl-input>
                        <sl-input id="contact-lastname" label="Last Name"></sl-input> 
                        <sl-select id="contact-audience" label="Select Audience" value="option-1">
                            <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mvp";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM audience WHERE companyid=$companyid";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo '<sl-option value="'.$row['audienceid'].'">'.$row['name'].'</sl-option>';
  }
} else {
  echo "0 results";
}
$conn->close();
?>
                          </sl-select>
                        <sl-button onclick="create_new_contact()" slot="footer" variant="primary">Save</sl-button>
                      </sl-dialog>

                       <div class="create-btn">
                <sl-button variant="primary">Create a new Contact</sl-button>
              </div>

              <sl-dialog label="Error" class="error-message">
                Can't proccess your request.
                <sl-button onclick="reload_page()" slot="footer" variant="danger">Reload</sl-button>
              </sl-dialog>

              <script>
                const add_new_contact_dialog = document.querySelector('.add-new-contact-dialog');
                const add_new_contact_dialog_open_btn = add_new_contact_dialog.nextElementSibling;
              
                add_new_contact_dialog_open_btn.addEventListener('click', () => add_new_contact_dialog.show());

                const error_message = document.querySelector('.error-message');



function error(){
          error_message.show()
      }

      
      function reload_page(){
          location.reload();
      }
                
  function create_new_contact(){
     // Get login email
     var contact_email = $('#contact-email').val();
     var contact_firstname = $('#contact-firstname').val();
     var contact_lastname = $('#contact-lastname').val();
     var contact_audience = $('#contact-audience').val();
        
        // AJAX request
        $.ajax({
            type: 'GET',
            url: 'create-new-contact-api.php', // Your login process PHP file
            data: { email: contact_email, firstname: contact_firstname, lastname: contact_lastname, audience: contact_audience, }, // Send email as data
            success: function(response){
                // Handle successful response
                console.log(response);
                if(response=="logout"){
                    window.location.href="../../login";
                }if(response=="done"){
                    location.reload();
                }else if(response=="not"){
                    error();
                }else{
                    error();
                }
                // You can update UI or do other actions here
            },
            error: function(xhr, status, error){
                // Handle errors
                console.error(xhr.responseText);
                    error();
            }
        });
  }

              </script>

                    <table id="all-contacts-table">
                        <tr>
                          <th>Email address</th>
                          <th>First name</th>
                          <th>Last name</th>
                          <th>Source</th>
                          <th>Date added</th>
                          <th></th>
                        </tr>
                        
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mvp";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM contact";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo '<tr>
    <td onclick="view('.$row['contactid'].')">'.$row['email'].'</td>
    <td>'.$row['firstname'].'</td>
    <td>'.$row['lastname'].'</td>
    <td>Added by admin</td>
    <td>Feb 27, 2023</td>
    <td>  
        <sl-button onclick="edit('.$row['contactid'].')" variant="default" size="small" circle>
        <sl-icon name="three-dots-vertical" label="options"></sl-icon>
      </sl-button>
    </td>
</tr>';
  }
} else {
  echo "0 results";
}
$conn->close();
?>
                      
                      </table>
                      
                    
                      <sl-drawer label="View Contact" id="view-contact-container" class="drawer-scrolling1">
                       
                      </sl-drawer>
                      <sl-drawer label="Edit Contact" id="edit-contact-container" class="drawer-scrolling2">
                        
                      </sl-drawer>
        
                             
                      <script>

                        function view_contact(id){

                            $.ajax({
            type: 'GET',
            url: 'view-contact-api.php?id='+id, // Your login process PHP file
            success: function(response){
                $('#view-contact-container').html(response);
                // You can update UI or do other actions here
            },
            error: function(xhr, status, error){
                // Handle errors
                console.error(xhr.responseText);
                error1();
            }
        });

                        }

                        
                        function view_edit_contact(id){

$.ajax({
type: 'GET',
url: 'view-edit-contact-api.php?id='+id, // Your login process PHP file
success: function(response){
$('#edit-contact-container').html(response);
// You can update UI or do other actions here
},
error: function(xhr, status, error){
// Handle errors
console.error(xhr.responseText);
error1();
}
});

}
                        
        
                        function edit(id){    
                        const drawer = document.querySelector('.drawer-scrolling2');
                        drawer.show()
                        view_edit_contact(id);
                        }
                        function view(id){    
                        const drawer = document.querySelector('.drawer-scrolling1');
                        drawer.show()
                        view_contact(id);
                        }
                      </script>

                </sl-tab-panel>
                <sl-tab-panel name="audience">
                    
                    <sl-dialog label="Create Audience" class="add-new-audience-dialog">
                        <sl-input id="audience-name" autofocus label="Audience Name"></sl-input>
                        <sl-button onclick="create_new_audience()" slot="footer" variant="primary">Create</sl-button>
                      </sl-dialog>

                    <div class="create-btn">
                        <sl-button variant="primary">Create a new Audience</sl-button>
                      </div>



                      <sl-dialog label="Error" class="error-message1">
                        Can't proccess your request.
                        <sl-button onclick="reload_page1()" slot="footer" variant="danger">Reload</sl-button>
                      </sl-dialog>

                      <script>
                        const add_new_audience_dialog = document.querySelector('.add-new-audience-dialog');
                        const add_new_audience_dialog_open_btn = add_new_audience_dialog.nextElementSibling;
                      
                        add_new_audience_dialog_open_btn.addEventListener('click', () => add_new_audience_dialog.show());


                        const error_message1 = document.querySelector('.error-message1');



function error1(){
          error_message1.show()
      }

      
      function reload_page1(){
          location.reload();
      }
        


                        function create_new_audience(){
     // Get login email
     var audience_name = $('#audience-name').val();
        
        // AJAX request
        $.ajax({
            type: 'GET',
            url: 'create-new-audience-api.php', // Your login process PHP file
            data: { name: audience_name }, // Send email as data
            success: function(response){
                // Handle successful response
                console.log(response);
                if(response=="logout"){
                    window.location.href="../../login";
                }if(response=="done"){
                    location.reload();
                }else if(response=="not"){
                    error1();
                }else{
                    error1();
                }
                // You can update UI or do other actions here
            },
            error: function(xhr, status, error){
                // Handle errors
                console.error(xhr.responseText);
                error1();
            }
        });
  }

                      </script>

                    <div class="audience-lists">

                                            
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mvp";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM audience";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo '<div class="audience-list">
    <div class="audience-list-txts">
        <a href="./audience/view/?id='.$row['audienceid'].'" class="name">'.$row['name'].'</a>
        <div class="date">Created on - Apr 24, 2024 12:09 AM</div>
    </div>
    <div class="imgs">
        <sl-icon-button name="person-add" label="Add contact" style="font-size: 25px;"></sl-icon-button>
        <sl-icon-button name="send-plus" label="Send mail" style="font-size: 25px;"></sl-icon-button>
        <sl-dropdown>
            <sl-button slot="trigger" variant="default" size="small" circle>
                <sl-icon name="three-dots-vertical" label="options"></sl-icon>
              </sl-button>
            <sl-menu>
              <sl-menu-item value="cut">Clone</sl-menu-item>
              <sl-menu-item value="copy">Delete Campaign</sl-menu-item>
            </sl-menu>
          </sl-dropdown>
    </div>
</div>';
  }
} else {
  echo "0 results";
}
$conn->close();
?>

                      </div>
                </sl-tab-panel>
              </sl-tab-group>

              

        </div>

    </div>


</body>

</html>