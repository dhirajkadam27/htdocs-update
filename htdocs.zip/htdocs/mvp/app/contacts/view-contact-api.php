<?php
session_start(); // Start session

// Check if user is logged in
if (!isset($_SESSION['userid']) || !isset($_SESSION['companyid'])) {
    echo "logout";
    exit();
}

// Establish database connection (replace with your database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mvp";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$contactId = $_GET['id'];

$contact_sql = "SELECT * FROM contact WHERE contactid = ?"; // Assuming you want to fetch a campaign for the logged-in user and company
$contact_stmt = $conn->prepare($contact_sql);
$contact_stmt->bind_param("i", $contactId);
$contact_stmt->execute();
$contact_result = $contact_stmt->get_result();

if ($contact_result->num_rows == 1) {
    // Campaign found, fetch campaign data
    $contact = $contact_result->fetch_assoc();
    // Now $campaign variable contains the fetched campaign data
    // print_r($campaign);

    $audiencename = "";

$audience_sql = "SELECT * FROM audience WHERE audienceid = ?"; // Assuming you want to fetch a campaign for the logged-in user and company
$audience_stmt = $conn->prepare($audience_sql);
$audience_stmt->bind_param("i", $contact['audienceid']);
$audience_stmt->execute();
$audience_result = $audience_stmt->get_result();

if ($audience_result->num_rows == 1) {
    // Campaign found, fetch campaign data
    $audience = $audience_result->fetch_assoc();
    // Now $campaign variable contains the fetched campaign data
    // print_r($campaign);
    $audiencename = $audience['name'];
} else {
    echo "audience not found.";
}

    
    echo '<label>Email</label>
    <div class="value">'.$contact['email'].'</div>
    <label>First Name</label>
    <div class="value">'.$contact['firstname'].'</div>
    <label>Last Name</label>
    <div class="value">'.$contact['lastname'].'</div>
    <label>Audience</label>
    <div class="value">'.$audiencename.'</div>';
} else {
    echo "contact not found.";
}

// Close database connection
$conn->close();
?>