<?php
session_start(); // Start session

// Check if user is logged in
if (!isset($_SESSION['userid']) || !isset($_SESSION['companyid'])) {
    echo "logout";
    exit();
}

// Establish database connection (replace with your database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mvp";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to update campaign data
function updateCampaign($conn, $id, $subject, $sendername, $senderemail, $audience) {
    $stmt = $conn->prepare("UPDATE campaign SET subject = ?, sendername = ?, senderemail = ?,audience = ? WHERE campaignid = ?");
    $stmt->bind_param("ssssi",$subject,$sendername,$senderemail,$audience, $id);
    $stmt->execute();
    return $stmt->affected_rows; // Return the number of affected rows
}

// Main logic for updating campaign data
if (isset($_GET['id']) && isset($_GET['subject']) && isset($_GET['sendername']) && isset($_GET['senderemail']) && isset($_GET['audience'])) {
    $id = $_GET['id'];
    $subject = $_GET['subject'];
    $sendername = $_GET['sendername'];
    $senderemail = $_GET['senderemail'];
    $audience = $_GET['audience'];
    
    $affectedRows = updateCampaign($conn, $id, $subject, $sendername, $senderemail, $audience);
    
    if ($affectedRows > 0) {
        echo "done";
    } else {
        echo "failed";
    }
} else {
    echo "failed";
}

$conn->close();
?>
