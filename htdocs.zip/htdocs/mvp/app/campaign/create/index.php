<?php
session_start(); // Start session

// Check if user is logged in
if (!isset($_SESSION['userid']) || !isset($_SESSION['companyid'])) {
    // Redirect to login page or handle unauthorized access
    header("Location: ../../../login");
    exit();
}

// Establish database connection (replace with your database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mvp";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Main logic to fetch campaign data by campaign ID
$campaignId = $_GET['id']; // Assuming campaign ID is provided via GET parameter
$title = "";
$subject = "";
$sendername = "";
$senderemail = "";
$createon = "";
$templateId = "";
$sql = "SELECT * FROM campaign WHERE campaignid = ? AND userid = ? AND companyid = ?"; // Assuming you want to fetch a campaign for the logged-in user and company
$stmt = $conn->prepare($sql);
$stmt->bind_param("iii", $campaignId, $_SESSION['userid'], $_SESSION['companyid']);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 1) {
    // Campaign found, fetch campaign data
    $campaign = $result->fetch_assoc();
    // Now $campaign variable contains the fetched campaign data
    // print_r($campaign);
    $title = $campaign['title'];
    $subject = $campaign['subject'];
    $sendername = $campaign['sendername'];
    $senderemail = $campaign['senderemail'];
    $createon = $campaign['createon'];
    $templateId = $campaign['templateid'];
} else {
    echo "Campaign not found.";
}

$templateimg = "";

$template_sql = "SELECT * FROM template WHERE templateid = ?"; // Assuming you want to fetch a campaign for the logged-in user and company
$template_stmt = $conn->prepare($template_sql);
$template_stmt->bind_param("i", $templateId);
$template_stmt->execute();
$template_result = $template_stmt->get_result();

if ($template_result->num_rows == 1) {
    // Campaign found, fetch campaign data
    $template = $template_result->fetch_assoc();
    // Now $campaign variable contains the fetched campaign data
    // print_r($campaign);
    $templateimg = $template['img'];
} else {
    echo "template not found.";
}

// Close database connection
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle | App Page</title>
    <!-- open sans google fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap"
        rel="stylesheet">


    
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@shoelace-style/shoelace@2.15.0/cdn/themes/light.css" />
<script type="module" src="https://cdn.jsdelivr.net/npm/@shoelace-style/shoelace@2.15.0/cdn/shoelace-autoloader.js"></script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>

    const ImgToSvg= async (img) => {
      const s = document.createElement('div');
      s.innerHTML = await (await fetch(img.src)).text();
      s.firstChild.classList = img.classList;
      img.replaceWith(s.firstChild)
    }
  </script>

    <style>
        body{
            margin: 0;
            padding: 0;
  font-family: "Open Sans", sans-serif;
  font-size: 15px;
  font-weight: 500;
  width: 100%;
  height: 100vh;
  color: #3E3E3E;
        }
        button{
  font-family: "Open Sans", sans-serif;
  cursor: pointer;
  border: none;
  padding: 0;
  margin: 0;
  background: none;
        } 
        input{
  font-family: "Open Sans", sans-serif;
  cursor: pointer;
  outline-color: #3E3E3E;
  color: #3E3E3E;
        }
        button:hover{
            filter: brightness(0.9);
        }
        button:active{
            transform: scale(0.9);
        }


        .top-nav {
            width: calc(100% - 40px);
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #DBDBDB;
    padding: 0px 20px;
}

.company-logo {
    height: 30px;
    margin: 0px;
    cursor: pointer;
}
.profile-info {
    display: flex;
    align-items: center;
}
.profile-info sl-icon {
    font-size: 25px;
    margin: 0px 10px;
}
.profile-info .txt {
    margin-right: 15px;
}
.profile-info .txt .name {
    font-size: 15px;
    font-weight: 500;
}
.profile-info .txt .email {
    font-size: 13px;
    font-weight: 400;
}

.campaign{
    display: flex;
}
.side-nav {
    width: 90px;
    height: calc(100vh - 60px);
    border-right: 1px solid #DBDBDB;
    text-align: center;
}
.side-nav svg{
    width: 30px;
}
.side-nav .active{
    color: #2859C5;
}
.side-nav .active .txt{
    font-weight: 600 !important;
}
.side-nav .active svg{
    fill: #2859c533;
    width: 35px;
}
.side-nav .active svg path{
    stroke: #2859C5;
}
.side-nav button {
    background: white;
    width: 70px;
    height: 70px;
    margin: 10px 0px;
    border-radius: 10px;
}

.side-nav button img {
    width: 30px;
    margin-bottom: 5px;
}

.side-nav button .txt {
    font-size: 10px;
    font-weight: 500;
}

.campaign-main-screen {
    width: calc(100% - 90px);
    height: calc(100vh - 60px);
}

.campaign-main-screen sl-breadcrumb {
    display: flex;
    margin: 10px 20px;
}


.campaign-back {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 10px auto;
    margin-top: 40px;
    width: 80%;
}

.campaign-back  .left{
    display: flex;
    align-items: center;
}

.campaign-back .left .txt {
    display: block;
}

.campaign-back  .left .name {
    font-size: 15px;
    text-decoration: none;
    font-weight: 600;
    color: #3E3E3E;
}
.campaign-back .left .name:hover{
    text-decoration: underline;
    color: #007CC2 !important;
}
.campaign-back .left .date {
    font-size: 12px;
    font-weight: 400;
    margin-top: 5px;
}

.section {
    margin: 10px auto;
    margin-top: 40px;
    width: 80%;
    padding-bottom: 50px;
}

.section .title {
    font-size: 15px;
    font-weight: 600;
    margin-bottom: 10px;
}


.section .row {
    display: flex;
    align-items: center;
    margin: 10px auto;
    width: 95%;
    margin-top: 20px;
}

.section .row label {
    width: 200px;
    font-size: 15px;
    font-weight: 500;
}
.section .row sl-input {
    width: 500px;
}

.section .row sl-select {
    width: 500px;
}



.section .row1 {
    display: flex;
    align-items: start;
    margin: 10px auto;
    width: 95%;
    margin-top: 20px;
}

.section .row1 label {
    width: 200px;
    font-size: 15px;
    font-weight: 500;
}

.section .row1 .checkbox {
    display: flex;
    align-items: center;
    margin-bottom: 15px;
}

.section .row1 .checkbox label {
    font-size: 15px;
    font-weight: 500;
    margin-left: 10px;
}

.section .create-template {
    text-align: center;
    margin-top: 30px;
}

.section .create-template img {
    height: 200px;
}
.section .create-template sl-button {
    display: block;
    width: 100px;
    margin: 10px auto;
    margin-top: 30px;
}




    </style>
</head>

<body>

    <div class="top-nav">
        
        <sl-dropdown>
            <img slot="trigger" class="company-logo" src="../../home-assets/company-logo.png" alt="Company Profile">
          <sl-menu>
            <sl-menu-item value="cut">Account</sl-menu-item>
            <sl-menu-item value="copy">Settings</sl-menu-item>
            <sl-menu-item value="copy">Invite Users</sl-menu-item>
          </sl-menu>
        </sl-dropdown>

      
    
    <sl-dropdown>
          <sl-icon-button slot="trigger" variant="default" src="../../home-assets/user-logo.svg" style="font-size: 30px;"></sl-icon-button>
        <sl-menu>
            <div class="profile-info">
                <sl-icon name="person" style="font-size: 20px;"></sl-icon>
                <div class="txt">
                    <div class="name">Dhiraj Kadam</div>
                    <div class="email">dhirajkadam@gmail.com</div>
                </div>
            </div>
            <sl-divider></sl-divider>
            <sl-menu-item value="profile">Profile</sl-menu-item>
          <sl-menu-item value="logout">Logout</sl-menu-item>
        </sl-menu>
      </sl-dropdown>

      
    </div>

    </div>

    <div class="campaign">

        <div class="side-nav">
            <button onclick="window.location.href='../../'"><img onload="ImgToSvg(this)" src="../../home-assets/home-icon.svg" alt="Dashboard Page"><div class="txt">Dashboard</div></button>
            <button class="active"><img onload="ImgToSvg(this)" src="../../home-assets/campaign-icon.svg" alt="Campaigns page"><div class="txt">Campaigns</div></button>
            <button onclick="window.location.href='../../contacts'"><img onload="ImgToSvg(this)" src="../../home-assets/contact-icon.svg" alt="Contacts Page"><div class="txt">Contacts</div></button>
            <button onclick="window.location.href='../../reports'"><img onload="ImgToSvg(this)" src="../../home-assets/report-icon.svg" alt="campaign Page"><div class="txt">Reports</div></button>
        </div>
    
        <div class="campaign-main-screen">

            
            <sl-breadcrumb>
                <sl-breadcrumb-item href="./">Home</sl-breadcrumb-item>
                <sl-breadcrumb-item href="./">Campaigns</sl-breadcrumb-item>
                <sl-breadcrumb-item href="./">Create Campaign</sl-breadcrumb-item>
              </sl-breadcrumb>

          <div class="campaign-back">
            <div class="left">
                    <sl-icon-button onclick="history.back()" name="arrow-left-short" label="back" style="font-size: 30px;"></sl-icon-button>
                <div class="txt">
                        <a href="#" class="name"><?php echo $title ?></a>
                        <div class="date">Created <sl-relative-time date="<?php echo $createon ?>"></sl-relative-time></div>
                </div>
            </div>
            <div class="btns">
                <sl-button onclick="save_campaign()" variant="primary">Save & Exit</sl-button>
                <sl-button variant="primary">Send</sl-button>
            </div>
          </div>

          <div class="section">
            <div class="title">SUBJECT</div>
            <div class="row">
                <label>Subject</label>
                <sl-input id="subject" value="<?php echo $subject ?>"></sl-input>
            </div>
          </div>

          <div class="section">
            <div class="title">SENDER</div>
            <div class="row">
                <label>Sender name</label>
                <sl-input id="sendername" value="<?php echo $sendername ?>"></sl-input>
            </div>
            <div class="row">
                <label>Sender email</label>
                <sl-select id="senderemail" value="<?php echo $senderemail ?>">
                    <sl-option value="option-1">dhirajkadam@gmail.com</sl-option>
                    <sl-option value="option-2">dhirajkadam@gmail.com</sl-option>
                    <sl-option value="option-3">dhirajkadam@gmail.com</sl-option>
                  </sl-select>
            </div>
          </div>

          
          <div class="section">
            <div class="title">RECIPIENT</div>
            <div class="row1">
                <label>Select audience</label>
                <div class="checkboxs">
                    <div class="checkbox">
                        <sl-checkbox id="audience" size="medium">Hiring 121ASA</sl-checkbox>
                    </div>
                    <div class="checkbox">
                        <sl-checkbox id="audience" size="medium">Hiring 121ASA</sl-checkbox>
                    </div>
                </div>
            </div>
          </div>


          <div class="section">
            <div class="title">CONTENT</div>
            <div class="create-template">
                <?php

                if($templateimg==""){
                    echo '<img src="https://static.vecteezy.com/system/resources/previews/000/421/673/original/vector-email-icon.jpg">
                    <sl-button onclick="window.location.href='."'".'http://localhost:5173/email-builder-js/?id='.$templateId.'&name='.$title.'&camp='.$campaignId.';#sample/reset-password'."'".'" variant="primary">Create</sl-button>';
                }else{
                    echo '<img src="'.$templateimg.'">
                    <sl-button onclick="window.location.href='."'".'http://localhost:5173/email-builder-js/?id='.$templateId.'&name='.$title.'&camp='.$campaignId.';#sample/reset-password'."'".'" variant="primary">Edit</sl-button>';
                }

                ?>
            </div>
          </div>
            
        </div>

    </div>

                    
    <sl-dialog label="Error" class="error-message">
        Can't proccess your request.
        <sl-button onclick="reload_page()" slot="footer" variant="danger">Reload</sl-button>
      </sl-dialog>

    <script>


const error_message = document.querySelector('.error-message');

function error(){
            error_message.show()
        }

        
        function reload_page(){
            location.reload();
        }

function save_campaign(){
     // Get login email
     var id = <?php echo $campaignId; ?>;
     var title = $('#title').val();
     var subject = $('#subject').val();
     var sendername = $('#sendername').val();
     var senderemail = $('#senderemail').val();
     var audience = $('#audience').val();
        
        // AJAX request
        $.ajax({
            type: 'GET',
            url: 'save-campaign-api.php', // Your login process PHP file
            data: { id: id, title: title, subject: subject, sendername: sendername, senderemail: senderemail, audience: audience }, // Send email as data
            success: function(response){
                // Handle successful response
                console.log(response);
                if(response=="logout"){
                    window.location.href="../../../login";
                }else if(response=="done"){
                    window.location.href="../";
                }else if(response=="failed"){
                    error();
                }else{
                    error();
                }
                // You can update UI or do other actions here
            },
            error: function(xhr, status, error){
                // Handle errors
                console.error(xhr.responseText);
            }
        });
  }

        </script>

</body>

</html>