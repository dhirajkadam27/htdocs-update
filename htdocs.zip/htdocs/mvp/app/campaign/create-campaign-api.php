<?php
session_start(); // Start session

// Check if user is logged in
if (!isset($_SESSION['userid']) || !isset($_SESSION['companyid'])) {
    echo "logout";
    exit();
}

// Establish database connection (replace with your database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mvp";

$date = new DateTime();
$formatted_date = $date->format('Y-m-d\TH:i:sO');

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to create a campaign and a blank template
function createCampaign($conn, $name, $userId, $companyId, $formatted_date) {
    // Insert blank template
    $stmt_template = $conn->prepare("INSERT INTO template (json) VALUES ('')");
    $stmt_template->execute();
    $templateId = $stmt_template->insert_id;
    
    // Insert campaign
    $stmt_campaign = $conn->prepare("INSERT INTO campaign (title, type, userid, companyid, createon, templateid) VALUES (?, 'Draft', ?, ?, ?, ?)");
    $stmt_campaign->bind_param("sissi", $name, $userId, $companyId, $formatted_date, $templateId);
    $stmt_campaign->execute();
    return $stmt_campaign->insert_id; // Return the ID of the newly inserted campaign
}

// Main logic for campaign creation
if (isset($_GET['campaignname'])) {
    $campaignName = $_GET['campaignname'];
    $userId = $_SESSION['userid'];
    $companyId = $_SESSION['companyid'];
    
    $campaignId = createCampaign($conn, $campaignName, $userId, $companyId, $formatted_date);
    
    echo $campaignId;
} else {
    echo "not";
}

$conn->close();
?>
