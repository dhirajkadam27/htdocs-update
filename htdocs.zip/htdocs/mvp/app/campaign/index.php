<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toggle | App Page</title>
    <!-- open sans google fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap"
        rel="stylesheet">

        
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@shoelace-style/shoelace@2.15.0/cdn/themes/light.css" />
<script type="module" src="https://cdn.jsdelivr.net/npm/@shoelace-style/shoelace@2.15.0/cdn/shoelace-autoloader.js"></script>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>

    const ImgToSvg= async (img) => {
      const s = document.createElement('div');
      s.innerHTML = await (await fetch(img.src)).text();
      s.firstChild.classList = img.classList;
      img.replaceWith(s.firstChild)
    }
  </script>

    <style>
        body{
            margin: 0;
            padding: 0;
  font-family: "Open Sans", sans-serif;
  font-size: 15px;
  font-weight: 500;
  width: 100%;
  height: 100vh;
  color: #3E3E3E;
        }
        button{
  font-family: "Open Sans", sans-serif;
  cursor: pointer;
  border: none;
  padding: 0;
  margin: 0;
  background: none;
        } 
        input{
  font-family: "Open Sans", sans-serif;
  cursor: pointer;
  outline-color: #3E3E3E;
  color: #3E3E3E;
        }
        button:hover{
            filter: brightness(0.9);
        }
        button:active{
            transform: scale(0.9);
        }


        .top-nav {
            width: calc(100% - 40px);
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #DBDBDB;
    padding: 0px 20px;
}

.company-logo {
    height: 30px;
    margin: 0px;
    cursor: pointer;
}
.profile-info {
    display: flex;
    align-items: center;
}
.profile-info sl-icon {
    font-size: 25px;
    margin: 0px 10px;
}
.profile-info .txt {
    margin-right: 15px;
}
.profile-info .txt .name {
    font-size: 15px;
    font-weight: 500;
}
.profile-info .txt .email {
    font-size: 13px;
    font-weight: 400;
}

.campaigns{
    display: flex;
}
.side-nav {
    width: 90px;
    height: calc(100vh - 60px);
    border-right: 1px solid #DBDBDB;
    text-align: center;
}
.side-nav svg{
    width: 30px;
}
.side-nav .active{
    color: #2859C5;
}
.side-nav .active .txt{
    font-weight: 600 !important;
}
.side-nav .active svg{
    fill: #2859c533;
    width: 35px;
}
.side-nav .active svg path{
    stroke: #2859C5;
}
.side-nav button {
    background: white;
    width: 70px;
    height: 70px;
    margin: 10px 0px;
    border-radius: 10px;
}

.side-nav button .txt {
    font-size: 10px;
    font-weight: 500;
}

.campaigns-main-screen {
    width: calc(100% - 90px);
    height: calc(100vh - 60px);
}
.campaigns-main-screen sl-breadcrumb {
    display: flex;
    margin: 10px 20px;
}
.create-btn {
    display: flex;
    align-items: center;
    justify-content: end;
    margin: 20px 50px;
    margin-top: 40px;
}

.all-campaigns {
            display: flex;
            margin: 30px;
            flex-wrap: wrap;
        }
        
        .all-campaigns .campaign-container {
    margin: 10px 15px;
}
        
        .all-campaigns .campaign-container .img {
            width: 300px;
    height: 210px;
    background-size: cover !important;
    border: 1px solid #DBDBDB;
        }

.all-campaigns .campaign-container .campaign-info {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 15px 0px;
    margin-top: 21px;
}

.all-campaigns .campaign-container .campaign-info .txt {
    text-align: left;
}

.all-campaigns .campaign-container .campaign-info .txt .name {
    font-size: 15px;
    font-weight: 500;
}

.all-campaigns .campaign-container .campaign-info .txt .date {
    font-size: 11px;
    font-weight: 400;
    color: #a7a7a7;
    margin-top: 5px;
}





    </style>
</head>

<body>

    <div class="top-nav">
        <sl-dropdown>
            <img slot="trigger" class="company-logo" src="../home-assets/company-logo.png" alt="Company Profile">
          <sl-menu>
            <sl-menu-item value="cut">Account</sl-menu-item>
            <sl-menu-item value="copy">Settings</sl-menu-item>
            <sl-menu-item value="copy">Invite Users</sl-menu-item>
          </sl-menu>
        </sl-dropdown>

      
    
    <sl-dropdown>
          <sl-icon-button slot="trigger" variant="default" src="../home-assets/user-logo.svg" style="font-size: 30px;"></sl-icon-button>
        <sl-menu>
            <div class="profile-info">
                <sl-icon name="person" style="font-size: 20px;"></sl-icon>
                <div class="txt">
                    <div class="name">Dhiraj Kadam</div>
                    <div class="email">dhirajkadam@gmail.com</div>
                </div>
            </div>
            <sl-divider></sl-divider>
            <sl-menu-item value="profile">Profile</sl-menu-item>
          <sl-menu-item value="logout">Logout</sl-menu-item>
        </sl-menu>
      </sl-dropdown>
    </div>

    <div class="campaigns">

        <div class="side-nav">
            <button onclick="window.location.href='../'"><img onload="ImgToSvg(this)" src="../home-assets/home-icon.svg" alt="Dashboard Page"><div class="txt">Dashboard</div></button>
            <button class="active"><img onload="ImgToSvg(this)" src="../home-assets/campaign-icon.svg" alt="Campaigns page"><div class="txt">Campaigns</div></button>
            <button onclick="window.location.href='../contacts'"><img onload="ImgToSvg(this)" src="../home-assets/contact-icon.svg" alt="Contacts Page"><div class="txt">Contacts</div></button>
            <button onclick="window.location.href='../reports'"><img onload="ImgToSvg(this)" src="../home-assets/report-icon.svg" alt="Reports Page"><div class="txt">Reports</div></button>
        </div>
    
        <div class="campaigns-main-screen">

            <sl-breadcrumb>
                <sl-breadcrumb-item href="./">Home</sl-breadcrumb-item>
                <sl-breadcrumb-item href="./">Campaigns</sl-breadcrumb-item>
              </sl-breadcrumb>
              
              
              <sl-dialog label="Create campaign" class="create-camapign-dialog">
                <sl-input id="campaign-name" autofocus placeholder="Campaign"></sl-input>
                <sl-button onclick="create_campaign()" slot="footer" variant="primary">Create</sl-button>
              </sl-dialog>

              <div class="create-btn">
                <sl-button variant="primary">Create a new campaign</sl-button>
              </div>


                 
    <sl-dialog label="Error" class="error-message">
        Can't proccess your request.
        <sl-button onclick="reload_page()" slot="footer" variant="danger">Reload</sl-button>
      </sl-dialog>

<script>
  const create_camapign_dialog = document.querySelector('.create-camapign-dialog');
  const openButton = create_camapign_dialog.nextElementSibling;
        const error_message = document.querySelector('.error-message');

  openButton.addEventListener('click', () => create_camapign_dialog.show());


  
  function error(){
            error_message.show()
        }

        
        function reload_page(){
            location.reload();
        }

  function create_campaign(){
     // Get login email
     var campaign_name = $('#campaign-name').val();
        
        // AJAX request
        $.ajax({
            type: 'GET',
            url: 'create-campaign-api.php', // Your login process PHP file
            data: { campaignname: campaign_name }, // Send email as data
            success: function(response){
                // Handle successful response
                console.log(response);
                if(response=="logout"){
                    window.location.href="../../login";
                }else if(response=="not"){
                    error();
                }else{
                    window.location.href = "./create/?id="+ response;
                }
                // You can update UI or do other actions here
            },
            error: function(xhr, status, error){
                // Handle errors
                console.error(xhr.responseText);
            }
        });
  }
</script>


            <div class="all-campaigns">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mvp";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM campaign";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


    $templateimg = "background: url(https://static.vecteezy.com/system/resources/previews/000/421/673/original/vector-email-icon.jpg);";

$template_sql = "SELECT * FROM template WHERE templateid = ?"; // Assuming you want to fetch a campaign for the logged-in user and company
$template_stmt = $conn->prepare($template_sql);
$template_stmt->bind_param("i", $row['templateid']);
$template_stmt->execute();
$template_result = $template_stmt->get_result();

if ($template_result->num_rows == 1) {
    // Campaign found, fetch campaign data
    $template = $template_result->fetch_assoc();
    // Now $campaign variable contains the fetched campaign data
    // print_r($campaign);
    if($template['img']!=""){
        $templateimg = "background: url(".$template['img'].")";
    }

} else {
    echo "template not found.";
}

    echo '<div class="campaign-container">
    ';
        if($row['type']=="draft"){
            echo '<button style="'.$templateimg.'" onclick="window.location.href='."'".'./create?id='.$row['campaignid'].''."'".'" class="img"></button>';  
        }else if($row['type']=="Ongoing"){
            echo '<button style="'.$templateimg.'" onclick="window.location.href='."'".'./view?id='.$row['campaignid'].''."'".'" class="img"></button>'; 
        }else if($row['type']=="Completed"){ 
            echo '<button style="'.$templateimg.'" onclick="window.location.href='."'".'./view?id='.$row['campaignid'].''."'".'" class="img"></button>'; 
        }else{
            echo '<button style="'.$templateimg.'" onclick="window.location.href='."'".'./create?id='.$row['campaignid'].''."'".'" class="img"></button>';  
        }
            echo '

    <div class="campaign-info">
        <div class="txt">
        ';
        if($row['type']=="draft"){
            echo '<div class="name">'.$row['title'].' <sl-badge variant="neutral">'.$row['type'].'</sl-badge></div>';  
        }else if($row['type']=="Ongoing"){
            echo '<div class="name">'.$row['title'].' <sl-badge variant="primary">'.$row['type'].'</sl-badge></div>';  
        }else if($row['type']=="Completed"){
            echo '<div class="name">'.$row['title'].' <sl-badge variant="success">'.$row['type'].'</sl-badge></div>';  
        }else{
            echo '<div class="name">'.$row['title'].' <sl-badge variant="neutral">Draft</sl-badge></div>';  
        }
            echo '<div class="date">Created <sl-relative-time date="'.$row['createon'].'"></sl-relative-time></div>
        </div>
        <sl-dropdown>
          <sl-button slot="trigger" variant="default" size="small" circle>
              <sl-icon name="three-dots-vertical" label="options"></sl-icon>
            </sl-button>
          <sl-menu>
            <sl-menu-item value="cut">Clone</sl-menu-item>
            <sl-menu-item value="copy">Delete Campaign</sl-menu-item>
          </sl-menu>
        </sl-dropdown>
    </div>
</div>';
  }
} else {
  echo "0 results";
}
$conn->close();
?>
         
            </div>

        </div>

    </div>


</body>

</html>