<?php
// Allow requests from http://localhost:5173
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Headers: Content-Type"); // Allow Content-Type header
header("Content-Type: application/json"); // Set content type to JSON

$json = file_get_contents('php://input');
$data = json_decode($json, true);


// Establish database connection (replace with your database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mvp";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Example template ID and updated JSON template
$templateId = $data['id'];
$json = $data['data'];
$img = $data['img'];

// Prepare and execute UPDATE query
$stmt = $conn->prepare("UPDATE template SET json = ?,img = ? WHERE templateid = ?");
$stmt->bind_param("ssi", $json, $img, $templateId);
$stmt->execute();

// Check if the update was successful
if ($stmt->affected_rows > 0) {
    echo json_encode(array("status" => "success", "message" => "Template updated successfully."));
} else {
    echo json_encode(array("status" => "failed", "message" => "Failed to update template."));
}

$conn->close();
?>
