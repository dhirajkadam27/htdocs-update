<?php
// Allow requests from http://localhost:3000
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Content-Type: application/json"); // Set content type to JSON

// Establish database connection (replace with your database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mvp";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$templateid = $_GET['id'];
$name = $_GET['name'];

// Prepare and execute query to fetch templateid, name, and json_template
$sql = "SELECT * FROM template WHERE templateid = $templateid";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Initialize an array to store fetched data
    $templates = array();

    // Fetch and store each row of the result set
    while($row = $result->fetch_assoc()) {
        // Add fetched data to the templates array
        $template = array(
            "name" => $name,
            "json" => json_decode($row["json"]) // Decode JSON string to array
        );

        // Add template to the templates array
        $templates[] = $template;
    }

    // Output templates array in JSON format
    echo json_encode($templates);
} else {
    echo "No templates found.";
}

$conn->close();
?>
