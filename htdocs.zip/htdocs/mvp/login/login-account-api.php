<?php
session_start(); // Start session

// Establish database connection (replace with your database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mvp";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to check if email exists in the user table
function emailExists($conn, $email) {
    $stmt = $conn->prepare("SELECT * FROM user WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}

// Function to authenticate user
function authenticateUser($conn, $email, $password) {
    $stmt = $conn->prepare("SELECT * FROM user WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if ($password == $user['password']) {
            return $user; // Return user data if password matches
        }
    }
    return false; // Return false if email or password is incorrect
}

// Main logic for login
$email = $_GET['email']; // Assuming these values come from a form
$password = $_GET['password'];

if (emailExists($conn, $email)) {
    $user = authenticateUser($conn, $email, $password);
    if ($user) {
        // Authentication successful, create session variables
        $_SESSION['userid'] = $user['userid'];
        $_SESSION['companyid'] = $user['companyid'];
        echo "Loggedin";
    } else {
        echo "wrong";
    }
} else {
    echo "not";
}

$conn->close();
?>
