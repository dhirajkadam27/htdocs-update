<?php
// Establish database connection (replace with your database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mvp";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to check if email already exists in the user table
function emailExists($conn, $email) {
    $stmt = $conn->prepare("SELECT * FROM user WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}

// Function to create a new company
function createCompany($conn, $companyName) {
    $stmt = $conn->prepare("INSERT INTO company (name) VALUES (?)");
    $stmt->bind_param("s", $companyName);
    $stmt->execute();
    return $conn->insert_id; // Return the ID of the newly inserted company
}

// Function to create a new user
function createUser($conn, $name, $email, $password, $companyId) {
    $stmt = $conn->prepare("INSERT INTO user (name, email, password, companyid) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssi", $name, $email, $password, $companyId);
    $stmt->execute();
}

// Main logic to create account
$name = $_GET['name']; // Assuming these values come from a form
$email = $_GET['email'];
$password = $_GET['password'];
$companyName = $_GET['companyname'];

if (!emailExists($conn, $email)) {
    // Email doesn't exist, create new company
    $companyId = createCompany($conn, $companyName);
    // Create new user with the company ID
    $userId = createUser($conn, $name, $email, $password, $companyId);
    // Create session variables for user_id and company_id
    $_SESSION['userid'] = $userId;
    $_SESSION['companyid'] = $companyId;
    echo "created";
} else {
    echo "exists";
}

$conn->close();
?>
